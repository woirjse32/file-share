# datakommunikasjon

## protokoll

### Flere nivåer av kompleksitet
- hvordan skal maskinen oppføre seg?
- hvordan skal beskjeden finne veien frem?
- er det noen garantier for det?
- hvordan håndtere kø?

#### Protokoller er regler

### Protokoller og lag

- utfordringer
   - ulike enheter har ulike behov og kapasiteter
   - feil kan oppstå under overføring av data
   - sikkerhet og pålitelighet må ivaretas
- forenklinger
   - dele komplekse oppgaver i mindre deler
   - standardisere kommunikasjon mellom enheter
   - gjøre det mulig å bytte ut enkeltkomponenter
- eksempler
   - TCP/IP for Internett
   - HTTP for webtrafikk
   - Bluetooth for kortdistansekommunikasjon

#### Hvordan strukturere nettverkskommunikasjon?

Lagdeling:

- bestemme felles språk
- etablere tilkobling
- finne riktig prosess
- overføre og håndtere feil
- overføre mellom naboer
- bestemme fart
- finne mekanismer
- sette sammen data
- sende bits
- bestemme hastighet
- fikse feil
- velge hardware

#### Kommunikasjon mellom samme lag

- Hva definerer en protokoll?

| Protokoll definerer | Protokoll definerer ikke |
|---------------------|--------------------------|
| formaterer beskjeden og header (konvolutt) | tjeneste tilbudt til laget over (n+1) |
| rekkefølgen på beskjeder | tjeneste brukt i laget under (n-1) |
| utvekslingen av beskjeder mellom to eller flere kommunikasjonssystemer | |
| hva skal skje ved mottak eller sending av en beskjed | |

#### Referansemodellen for OSI

> ISO open systems interconnection, også kjent som OSI-modellen

- modellen for lagdelt kommunikasjon
- grunnleggende konsepter og terminologi
- definerer syv lag

#### Fem lag referansemodellen og OSI-modellen

- presentasjon, sesjon og applikasjon slås sammen til ett lag
- litt ut fra hvem du spør, så slås også transportlaget og det første laget sammen til ett lag kalt nettverksgrensesnittet

| Lag              | Beskrivelse                                              |
|------------------|----------------------------------------------------------|
| Applikasjon      | applikasjonstjenester, HTTP, mail                         |
| Transport        | kobler sammen systemene til ende-til-ende (TCP/UDP)       |
| Nettverk         | sender data mellom ende-til-ende systemer (IP)            |
| Link             | pålitelig overføring mellom noder (LAN, WiFi)            |
| Fysisk           | sender bits ut på mediet (kablet eller trådløst)          |

### Dataenheter i TCP/IP-modellen

#### Dataenheter har forskjellige navn avhengig av hvilket lag vi befinner oss i

- Segmenter brukes på transportlaget, kan inneholde fragmenter
- Pakker brukes på nettverkslaget
- Rammer brukes på linklaget
- Bits brukes på det fysiske laget

#### Datastrøm mellom to systemer uten direkte tilkobling

> Endesystem --> Endesystem

- forestill deg at datapakkene gjennomgår lagene på avsender-siden og oppover hos mottaker
- det fysiske laget håndterer selve sendingen til neste node

#### Ruting og ende-til-ende-kommunikasjon

- nettverksprotokollen IP tar hånd om ruting til endelig destinasjon
  - på hver ruter går pakken opp til nettverkslaget også
- transport og applikasjonskommunikasjon er ende-til-ende

#### Internett protokollstabell

- TCP er på transportlaget
- Applikasjonslaget: SMTP, HTTP, FTP, SSH, NFS, RTP
- IP er på nettverkslaget
- WAN, LAN, MAN
- linklaget og fysisk lag

#### Lagene i TCP/IP-modellen

- Internett har fem lag
  - lag 5, 6 og 7 fra OSI er implementert som ett applikasjonslag

- På Internett blir oftest lag 2 (nettverk) og lag 4 (transport) brukt
  - transportprotokoll: TCP eller UDP, og nettverksprotokoll: IP
  - kan i flere tilfeller være utfordringer å trekke klare linjer hvor TCP slutter og IP begynner

### Lag for lag

#### Transportlaget

Lag med tjenester for applikasjoner:
- nettlesere
- epost
- filoverføring
- P2P

##### Lag 4

TCP:
- oppsett av forbindelse (three-way handshake)
- garanterer at pakker leveres i riktig rekkefølge
- pålitelighet - pakker sendes på nytt hvis bekreftelse (ACK) ikke kommer frem

UDP:
- ingen tilkoblingsoppsett
- ingen garantier
- best effort levering av data

QUIC:
- forskjellig transportlag for HTTP, designet av Google
- bruker UDP som transport, men legger til lenkefølighet fra TCP
- krever kryptering (Transport Layer Security)

TCP: HTTP, epost, filoverføring, etc.
UDP: strømming av video og lyd

#### Lag 3: Nettverkslaget

- kobler sammen systemer ende-til-ende
- ruting
  - statisk, definert under tilkobling, eller dynamisk
  - metningskontroll for mange pakker på en sti
  - trafikklasse (QoS)
- en ruter jobber på lag 3
- eksempler
  - IP (tilkoblingsløst)

- det mest brukte nettverksprotokollen i dag er IP, og de mest brukte versjonene er IPv4

#### Lag 2: Linklaget

- pålitelig overføring mellom to enheter
  - pakker som overføres i linklaget kalles "frames"
  - feildeteksjon og retting innenfor en frame
- en switch jobber på lag 2

Det vanlige linkelaget er Ethernet og WiFi. Disse er ganske like, men har noen forskjeller:
- bruker en 5 bytes adresse (48 bit) som ofte er lagret i nettverkskortet
  - MAC-adresse brukes på WiFi og Ethernet
  - hvert byte representerer en heksadesimal verdi (eksempel på dette)

#### Lag 1: Fysisk lag

- signalering av bits
- sørger for at 1 bit blir mottatt som 1 bit og ikke som 0 bit
- mekanisk koblingstype, kabler og medium
- elektrisk spenning, bitlengde
- formelle regler for kommunikasjon
  - enveis (unidireksjonelt) eller full duplex
  - toveis (bidireksjonelt) full duplex
  - hva skal markere starten og slutten på overføringer

