# Introduksjon til datakommunikasjon

- Kommunikasjonsformer
- Komponenter
- Aksessmodeller i datakommunikasjon
- Forskjellige typer nettverk

- Nettverkshistorie
- Utfordringer
- Hva vi må løse i et datanettverk

---

## Grunnleggende kommunikasjonsformer

### 1. Telefonnettverk (circuit switching)

- Dedikert linje mellom sender og mottaker
- Reservert eksklusivt for hele samtalen (oppkoblingen)
- Kommunikasjon følger alltid samme vei
- Tre faser:
  1. **Tilkobling** (dial) — etablering av forbindelsen
  2. **Samtale** — dataoverføring skjer
  3. **Nedkobling** (avslutning) — frigjøring av ressurser
- Fysiske linjer er ofte ikke dedikerte, men ressurser (f.eks. tidsintervaller i TDM) reserveres
- Eksempel: Man kan reservere 64 kbit/s båndbredde mellom sender og mottaker

### 2. Pakkenettverk (packet switching)

- Beskjeden deles opp i mindre pakker som videresendes fra sender til mottaker
- Ingen dedikert linje mellom sender og mottaker
- **Tilkoblingsløs tjeneste:**
  - Forskjellige datapakker kan følge forskjellige stier gjennom nettverket
  - Eksempel: Ved kabelbrudd kan pakker omdirigeres langs en annen rute
- Pakkesvitsjing brukes i dagens internett
- Pakker er begrenset i størrelse (MTU) for å unngå forsinkelser og feil

#### Hvordan fungerer et pakkenettverk? (kommer på eksamen)

- Pakken inneholder: header (adrese, sekvensnummer, etc.) + nyttelast (data)
- Rutere på veien leser headeren og videresender pakken til riktig destinasjon
- Pakker kan ankomme i feil rekkefølge og settes sammen igjen ved mottaker

---

## Komponenter i et datanettverk

### Endesystemer (noder)

- **Tjener (server):** en kraftig maskin som kjører tjenester og leverer ressurser til klienter
- **Client:** en enhet (PC, mobil, etc.) som ber om og bruker tjenester fra en server

### Intermediate systems (mellomliggende systemer)

- **Ruter (router):** videreformidler pakker mellom ulike nettverk basert på IP-adresse
- **Switch:** forbinder enheter innenfor samme nettverk og videresender rammer basert på MAC-adresse
- **Gateway:** kobler sammen nettverk med ulike protokoller eller arkitekturer
- **Repeater (forsterker):** mottar et svakt signal og sender det forsterket videre for å øke rekkevidden
- **Bridge:** forbinder to nettverk på datalinkk-nivå og filtrerer trafikk basert på MAC-adresse

---

## Aksessmodeller i datanettverk

> Hvordan endesystemene kommuniserer med hverandre

### Client-tjener-modellen

- Client ber om en tjeneste (oppretter en forbindelse)
- Tjeneren leverer tjenesten (svarer på forespørselen)

### Peer-to-Peer (P2P)

- Alle noder er likeverdige — ingen fast server
- Alle noder kan både sende og motta data
- Eierskapet er distribuert (ingen sentral autoritet)

> **Noder** = endesystemene (clienter og tjenere)

---

## Punkt-Punkt og Broadcast

### Punkt-Punkt

Kommunikasjon mellom to bestemte noder:

- **DOCSIS** (Data Over Cable Service Interface Specification): standard for kabelmodem, bruker stjernetopologi
- **Ethernet:** kabelbasert nettverk, bruker stjerne- eller tretopologi

> Andre topologier: ring, full mesh, fat tree, torus

### Broadcast

En node sender, alle noder i nettverket mottar:

- **Radio**
  - AM/FM (analog kringkasting)
  - Wi-Fi (trådløst lokalnett, IEEE 802.11)
  - Mobiltelefoni (cellulære nett, f.eks. 4G/5G)
  - Satellitt

- **Egenskaper:**
  - Når en node sender, potensielt alle andre noder i nettverket hører
  - Kan bli kollisjoner hvis to noder sender samtidig
  - Kollisjonsdeteksjon er viktig for å oppdage og håndtere dette
  - Sendere bør koordineres (f.eks. ved bruk av CSMA/CD)


## Morse telegraf

- En knapp for å sende korte eller lange beskjeder
  - Punkt = ditto (dit)
  - Strek = dah
- Streker og punktum skrives på et papir hos mottaker

### Kan vi kalle dette et kommunikasjonsnettverk?
> Det er et punkt-til-punkt-nettverk

### Baudot-telegraf

**Baudot tidsmultipleksing**

- Forgjenger til teletypewriter (TTY)

#### Baudotkode
- Fast lengde: 5 bit kode
- Tillater 2^5 = 32 symboler
- Maksimum på 5 bit var grunnet hardware-begrensninger
  - Med bestemte koder kunne man skrive til alternative symboler, tabeller, tall og tegn
- Standarden fra CCITT (ITU-T)
  - International Telegraph Alphabet No. 1 (ITA1)
  - Forgjenger til ASCII-kode

#### Telefoni
- Sentralbord (switch) — kobler sammen samtaler

### Datamaskiner kobles sammen:

- Lastbalansering
  - Send både programmer og data for prosessering på annen maskin
  - Krevde helt identiske maskiner i nettverket
- Tjeneste for utveksling av data

- Dele data:
  - Sende programmer for prosessering på fjern-datamaskin

#### Arpanet

- Kjernekomponent nettverkstilkobling
  - 50 kbit/s full duplex leide telefonlinjer (AT&T)

### Standardisering

- Utfordringer
> Utvikling av kommunikasjonsprotokoller trenger standardisering
   - Forskjellige lokasjoner, industrier, produsenter, operatører
     - Trenger standarder
   - Virksomheter, applikasjoner
   - Internasjonell standardisering

### Request for Comments (RFC)

- Først memos, møtereferat, styrker — sendt per post, ikke elektronisk

### Hva er nettverksprotokoller?

> Et sett med regler som beskriver hvordan kommunikasjonen skal foregå.

#### Kan en protokol løse alt?

> Man har delt det opp, slik at noen protokoler løser noen problemer

## Utfordringer

- Finne vei mellom flere leverandører og nettverk
- Hvilket endesystem skal kontaktes?
- Hvilket program på endesystemet skal kontaktes?
- Hvordan finne veien tilbake?
- Sørge for at man kan snakke sammen
- Håndtere problemer i nettverket
- Ivareta personvern
- Ivareta sikkerhet
- Unngå forsinkelser

## Lagdelingsmodeller (OSI og TCP/IP)

### Lag OSI

| Lag | Navn | Funksjon |
|-----|------|----------|
| 7 | Application | Gir applikasjoner tilgang til nettverket (HTTP, FTP, SMTP) |
| 6 | Presentation | Formatering, kryptering, komprimering av data |
| 5 | Session | Administrerer sesjoner og dialoger mellom applikasjoner |
| 4 | Transport | Pålidelig dataoverføring med feilretting og flytkontroll (TCP/UDP) |
| 3 | Network | Adressering og ruting av pakker mellom ulike nettverk (IP) |
| 2 | Data Link | Feilsøking, tilgang til medium, MAC-adressering (Ethernet) |
| 1 | Physical | Overføring av rå bits over fysisk medium (kabel, radio) |

### Lag TCP/IP-modellen

| Lag | Navn | Funksjon |
|-----|------|----------|
| 5 | Application | Protokoller for applikasjoner (HTTP, FTP, DNS, SMTP) |
| 4 | Transport | Pålidelig (TCP) eller upålitelig (UDP) dataoverføring |
| 3 | Internet | Adressering og ruting av pakker (IP, ICMP, ARP) |
| 2 | Network Access | Tilgang til fysisk medium og feilsøking (Ethernet, Wi-Fi) |
| 1 | Physical | Fysisk overføring av bits (signaler, kabler, frekvenser) |

## Oppsumering

Det finnes to grunnleggende kommunikasjonsformer: **circuit switching** (dedikert linje, tre faser) og **packet switching** (pakker som kan følge forskjellige stier). Dagens internett bruker pakkesvitsjing.

Et datanettverk består av **endesystemer** (noder: klienter og tjenere) og **mellomliggende systemer** (rutere, switche, gateways, repetere, bruer). Noder kommuniserer enten via **client-tjener-modellen** (en fast tjener leverer tjenester) eller **Peer-to-Peer** (alle noder er likeverdige).

Kommunikasjon kan være **punkt-til-punkt** (to bestemte noder, f.eks. Ethernet eller DOCSIS) eller **broadcast** (en node sender, alle mottar — f.eks. Wi-Fi, radio). Broadcast-nettverk har kollisjonsproblemer og trenger kollisjonsdeteksjon (CSMA/CD).

Historisk gikk utviklingen fra **Morse-telegraf** (punkt-til-punkt) til **Baudot-telegraf** (5-bit kode, forgjenger til ASCII) til **telefoni** (sentralbord) til **datanettverk** (ARPANET, 50 kbit/s). **Standardisering** (RFC-dokumenter, CCITT/ITU-T) ble nødvendig for at ulike aktører kunne samarbeide.

**Nettverksprotokoller** er regler for hvordan kommunikasjon skal foregå. Ingen enkelt protokoll løser alt — derfor er oppgavene delt mellom lag i **lagdelingsmodeller**: OSI-modellen (7 lag) og TCP/IP-modellen (5 lag). Hver layer håndterer en spesifikk oppgave, fra fysisk bitoverføring nederst til applikasjonsprotokoller øverst.

**Utfordringer** i datanettverk inkluderer ruting, interoperabilitet, feilhåndtering, sikkerhet, personvern og forsinkelser.