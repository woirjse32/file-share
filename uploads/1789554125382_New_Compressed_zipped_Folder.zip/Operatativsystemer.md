# Operating Systems

## Setup

- Basic execution environment
- What is an OS?
- OS components and services

## Hardware

- Central processing units
  - CPU
  - GPU
- Memory
  - RAM
  - ROM
  - Flash
- I/O devices
  - Network cards, disks, CD, keyboard, mouse
- Links
  - Interconnections
  - Buses

## Why do we need an OS?

- Many concurrent processes
  - Performing different tasks
  - Using different parts of the machine
- Many concurrent users
- Concurrent access
- Protection
- Fairness

> Dette kommer av at man har mange forskjellige samtidige oppgaver som alle må klare å holde sin egen minne og tilgangsrestriksjon.
> Operativsystemet brukes for å håndtere ressurser og fordele tilgjengelige ressurser på en måte som gjør at alle klarer å bruke ressursene.

## What is an operating system?

> An operating system (OS) is a collection of programs that acts as an intermediary between the hardware and its users, providing a high-level interface to low-level hardware resources such as GPU, memory, and I/O. The OS provides various facilities and services that make the use of hardware convenient, efficient, and safe.

### The OS is a virtual machine

- Hides the messy details
- Presents a virtual machine that is easier to use

### The OS is a resource manager

- Each program gets time and space on the resource

## Where do we find OSes?

> OSes brukes overalt for å sikre at det er mer brukervennlig, slik at brukerne ikke må kode.
> Bilder har OS for å klare å fungere.

## Operating system categories

- Single-user, single task
  - Historic and rare; only a few old PDAs use this
- Single-user, multitasking
  - PCs and workstations may be configured like this (typically phones today)
- Multi-user, multitasking
  - Used on large, old mainframes, and on handhelds, PCs, workstations, and servers today
- Distributed OSes
  - Support for administration of distributed resources
- Real-time OSes
  - Support for systems with real-time requirements, like cars, nuclear reactors, etc.
- Embedded OSes
  - Built into a device to control a specific type of equipment, like cell phones, microwaves, and washing machines

> To do things the right and most efficient way, you need to know how the OS works.

## OS components

**User interface**
- Provides a mechanism for the user and applications to communicate with the OS and use the machine's resources

**File management**
- Provides a mechanism for the user to create, delete, modify, and manipulate files

**Process management**
- Provides a mechanism for the system to effectively and fairly manage the machine's CPU cycles for the running processes

**Memory management**
- Provides a mechanism for the system to efficiently manage the system's memory allocation to processes

**Communication**
- Provides a mechanism for the system to communicate with other processes on the same machine

**Device management**
- Controls the external keyboard, display, printer, and disk — the system's peripheral devices

## Device management

- OSes must be able to control peripheral devices such as disks, keyboards, network cards, screens, speakers, and mice
  - Large diversity
  - Very different devices
  - Different access modes

- The software that establishes control and sends commands is called a device driver
- A huge amount of code — 50–90% of OS code

## Interfaces

- The interface is the interconnection between the user and the computer
- The OS incorporates logic that supports interfaces with both hardware and applications
  - Graphical User Interface (GUI)
    - An interface consisting of windows, icons, menus, and pointers
    - Often not part of the OS, but a separate program
  - Command-line interface (CLI)
  - Application Programming Interface (API)
- Example: X, see `man x`
  - The X Window System is a network-transparent window system that runs on most ANSI C and POSIX-compatible, Unix-compatible operating systems
  - It provides inter-process communication to get input from the X server for various client programs
- Desktop window manager (e.g. Windows)

## UNIX interfaces

> Applications access hardware through APIs consisting of a set of routines, protocols, and other tools.
> A user can interact with the system through the application interface, or using a command-line process (a shell) — not really a part of the OS.

> A plain command-line interface can be hard to use, so many UNIX systems have a standard graphical interface, X Window, which can run on desktop systems.

### Programming: system calls

- The interface between the OS and the user is defined by a set of system calls
- Making a system call is similar to a procedure/function call, but system calls enter the kernel

### CPU scheduling

- A task is a schedulable entity that can run on the CPU (a process execution, a job, aka a user program)
- In a multitasking system, several tasks may wish to use the CPU simultaneously
- A scheduler decides which task may use the CPU, i.e. it determines the order in which requests are serviced, using a scheduling algorithm

- A variety of contradicting factors to consider:
  - Treat similar tasks in a similar way
  - No process should wait forever
  - Short response times
  - Maximize throughput
  - Maximize resource utilization — 100%
  - Minimizing overhead
  - Predictable access

- There are several ways to achieve these goals, but it is usually impossible to achieve all of them at once. Which criteria are most important and most reasonable depends on who you are, what the environment is, and what the use case of the system is.

### Priorities

- Assigning each process a priority
- Run the process with the highest priority in the ready queue first
- Multiple queues
  - Often round robin in each
- Advantages
  - Fairness
  - Different priorities according to importance
- Disadvantages
  - Starvation (so many use dynamic priorities)

### Memory hierarchies

- A process typically needs a lot of memory
  - We can't access the disk every time we need data
- Typical computer systems therefore have several different components where data may be stored
  - Different capacities
  - Different speeds
  - Less capacity gives faster access and higher cost per byte
- Lower levels have a copy of the data stored in higher levels
- A typical memory hierarchy:
  - Cache
  - Main memory
  - Secondary storage
  - Tertiary storage

### Memory management

- Memory management is concerned with managing the system's memory resources
  - Allocating space to processes
  - Protecting memory regions
  - Providing a virtual view of memory, giving the impression of having more than the number of available bytes
  - Controlling the different levels of memory in the hierarchy

### The challenge of multiprogramming

- Many tasks require memory
  - Several processes concurrently loaded into memory
  - Memory is needed for different tasks within a process
  - Process memory demand may change over time
- The OS must manage dynamic memory sharing

### User level vs. kernel level (protection)

- Many OSes distinguish user and kernel level, i.e. due to security and protection

- Usually applications and subsystems run in user mode, level 3
  - Protected mode
  - Not allowed to access hardware or device drivers directly, only through an API
  - Access to allocated memory only
  - Limited instruction set

- OSes run in kernel mode
  - (Under the virtual machine abstraction, level 0)
  - Real mode
  - Access to the entire memory
  - All instructions can be executed
  - Bypass security

### Oppsummering

Operativsystemet er en samling programmer som fungerer som et mellomledd mellom maskinvaren og brukerne. Det gir et høynivågrensesnitt mot lavnivåressurser som CPU, minne og I/O, og gjør bruken av maskinvaren enkel, effektiv og trygg.

- **Hvorfor trenger vi et OS?** For å håndtere mange samtidige prosesser og brukere, gi samtidig tilgang, beskyttelse og rettferdighet.
- **Maskinvare:** CPU/GPU, minne (RAM, ROM, flash), I/O-enheter og busser.
- **Kategorier:** enkeltbruker/enkeltoppgave, enkeltbruker/fleroppgave, flerbruker/fleroppgave, distribuerte, sanntids- og innebygde systemer.
- **Komponenter:** brukergrensesnitt, filhåndtering, prosesshåndtering, minnehåndtering, kommunikasjon og enhetshåndtering (device management).
- **Grensesnitt:** GUI, CLI og API — samt systemkall, som er grensesnittet mellom OS og bruker og som kjører i kjernen.
- **CPU-scheduling:** en scheduler bestemmer hvilken oppgave som får bruke CPU-en. Målene (rettferdighet, responstid, gjennomstrømning, utnyttelse, lav overhead) er motstridende, og hva som er viktigst avhenger av bruksområdet.
- **Minnehierarki:** cache, hovedminne, sekundærlager og tertiærlager — mindre kapasitet gir raskere tilgang og høyere pris per byte.
- **Minnehåndtering:** tildele plass til prosesser, beskytte minneområder, gi et virtuelt minne og styre nivåene i hierarkiet.
- **Beskyttelse:** brukermodus (level 3) har begrenset instruksjonssett og tilgang, mens kjernemodus (level 0) har full tilgang til maskinvaren.

