# Kryptografi

## Introduksjon

- Hvorfor trenger vi det?
- Hva er det?
- Hvordan knekke en kryptering?
- Hemmelig nøkkelstyring

---

## Trenger vi kryptografi?

### Radio

- WiFi (IEEE 802.11)
- Mobilnett: 2G, 4G, 5G
- Satellitter, Starlink, etc.

### Bruk basert på lagene

- **Applikasjonslaget:** HTTPS (Secure Socket Layer)
- **Nettlaget:** VPN kobler nettverk sammen
- **Linklaget:** WPA (WiFi Protected Access)

---

## Viktige definisjoner

### Beskjeder

- **Plaintext / klartekst:** Ubeskyttet data, ofte ikke kritisk
- **Ciphertext / kryptert tekst:** Kryptert data

### Ingredienser

- **Algoritmer (krypteringsalgoritmer):** beskriver hvordan krypteringen utføres
- **Nøkler:** brukes til å låse og låse opp krypteringsalgoritmen

---

## Hemmelige koder

### Cæsarchiffer

- Skyver bokstaver 3 ganger fremover
- Eksempel: VOZEN → GRCHQ

### Dekodingsringer

- Substituerer bokstaver n bokstaver videre (n = 1–25)
- Eksempel: HAL → IBM

### Monoalfabetisk chiffer

- Tilfeldig mapping (26! ≈ 4,03 × 10²⁶)
- Med 1 ms per forsøk → ≈ 1,3 × 10¹⁶ år, men bokstavfrekvensen er en svakhet

---

## Hvordan knekke en kryptering?

- Kun ciphertext / kryptert tekst
  - Prøve alle mulige nøkler (brute force)
- Deler av plaintext
  - Sammenlign ciphertext med forventede verdier
  - Brukt for å knekke Enigma
- Finne svakheter i krypteringsalgoritmen
- Finne svakheter i implementasjonen av algoritmen

---

## Kompleksitet

### Eksempel 1: 3 tall mellom 1 og 40 (10 sek per forsøk)

- 40³ = 64 000 kombinasjoner
- 64 000 × 10 sekunder = 640 000 sekunder ≈ 178 timer

### Eksempel 2: 4 tall mellom 1 og 40 (13 sek per forsøk)

- 40⁴ = 2 560 000 kombinasjoner
- 2 560 000 × 13 sekunder = 33 280 000 sekunder ≈ 9244 timer

---

## Hva er egentlig et godt passord?

### Mest vanlige passord (2024)

- 12345
- password
- 123456789

### Passordgeneratorer

- Bruk verktøy som 1Password

### Passphrase

- Bruk lange, minneverdige setninger i stedet for korte passord
- Eksempel: «laptop wrapped in keyboard»

---

## Sikkerhet i trådløse nettverk

### Svakheter i protokoller og algoritmer

- Implementasjonssvakheter: Key Reinstallation Attack (KRACK)

### Brute force

- Teste alle mulige kombinasjoner
- Ordbokangrep
- Moderne GPUer kan teste flere millioner passord per sekund

---

## Forskjellige typer kryptering

### Symmetrisk kryptering

- **Hemmelig nøkkelkryptering** – samme nøkkel brukes til kryptering og dekryptering
- Samme nøkkel må deles mellom sender og mottaker
- **Fremgangsmåte:** Sender bruker en felles hemmelig nøkkel til å kryptere meldingen, og mottakeren bruker samme nøkkel til å dekryptere den
- **Typer:**
  - Block cipher (DES, 3DES, AES)
  - Stream cipher (RC4)
- I dag er block cipher mest brukt, gjerne i blokker på 128 bits (AES)

**Anvendelse:**

- Kryptering av filer
- Kryptering av meldinger

**Sikkerhetsmål:**

| Mål | Ja/Nei |
|---|---|
| Konfidensialitet | Ja |
| Integritet | Nei |
| Autentisering av avsender | Ja |
| Autentisering av mottaker | Ja |

### Asymmetrisk kryptering

- **Offentlig nøkkelkryptering**
- To nøkler: privat og offentlig

### Kryptografiske hash-funksjoner

- Sjekker integritet / ikke-reversibel
- Kriterier for en god hash-algoritme

---

## Viktigheten av gode tilfeldige tall

- Brukes til å generere kryptografiske nøkler
- Gjør det vanskelig å gjette seg frem til kryptografiske nøkler
- Kan f.eks. brukes som salt når man genererer nøkler

---

## Hash-funksjoner for økt sikkerhet

- En hash-funksjon tar data som input og produserer en fast hash-verdi. Kryptografiske hash-funksjoner er enveis-funksjoner som ikke lar seg reversere, og brukes blant annet til å verifisere dataintegritet og lagre passord sikkert

- **Fremgangsmåte:** Bruk en hash-algoritme på data/melding for å generere en sjekksum (hash-verdi)

- **Anvendelse:**
  - Hashting av passord
  - Sammenligning av filer (sjekke integritet)
  - Integritetsjekk f.eks. av programvare (sjekksummer)
  - Dataintegritet for meldinger

- **Hvilke sikkerhetsmål kan ivaretas?**
  - Integritet til datameldingen? Ja
  - Konfidensialitet? Ja

- Svake algoritmer begrenser levetiden

---

## Asymmetrisk kryptering

- Offentlig nøkkelkryptering
- Bruker et stort tilfeldig tall sammen med en kode som genererer et nøkkelpar
- Nøkkelparet fungerer som et par – man kan ikke regne seg frem til den andre nøkkelen selv om man har den ene

- **Situasjon:** Du vil sende en melding. Du krypterer meldingen med mottakerens offentlige nøkkel, og mottakeren dekrypterer den med sin private nøkkel

- **Effektivitet:**
  - Asymmetriske krypteringsalgoritmer er mange ganger tregere enn symmetriske algoritmer

- **Løsning: hybrid modell**
  - Asymmetrisk kryptering brukes for å utveksle en midlertidig nøkkel
    - Den vanlige tilnærmingen er kjent som Diffie-Hellman nøkkelutveksling
  - Symmetrisk kryptering brukes videre under kommunikasjonen

- Så man bruker asymmetrisk kryptering for å overføre den symmetriske nøkkelen, og fortsetter kommunikasjonen gjennom den

---

## HTTPS med SSL/TLS og asymmetrisk kryptering

- Klienten ber om en sikker sesjon
  - Serveren svarer
  - Klienten responderer: genererer en symmetrisk nøkkel og krypterer den
  - Den krypterte symmetriske nøkkelen sendes til serveren
  - Serveren dekoder den symmetriske nøkkelen med sin private nøkkel
  - --- og så videre (fortsett her selv)

---

## Asymmetrisk kryptering for meldingsutveksling

- **Fremgangsmåte:**
  - Avsender krypterer meldingen med mottakerens offentlige nøkkel, og mottakeren dekrypterer den med sin private nøkkel

- **Anvendelse:**
  - Sikker overføring av datameldinger samt autentisering

## Digital signatur

- **Fremgangsmåte:** Avsender signerer en melding med sin private nøkkel. Mottakeren dekrypterer med avsenderens offentlige nøkkel og har dermed verifisert avsenderen

- **Anvendelse:**
  - Gir tillit til at meldinger kommer fra en verifisert avsender, samt autorisering

- **Hvilke sikkerhetsmål kan ivaretas?**

  | Mål | Ja/Nei |
  |---|---|
  | Konfidensialitet | Nei |
  | Integritet | Nei, men i praktisk bruk ja |
  | Autentisering av avsender | Ja |
  | Autentisering av mottaker | Nei |
  | Uavviselighet | Ja |

### Digital signatur: uavviselighet?

- Hvis en signert melding endres/modifiseres, vil signaturen ikke lenger stemme. Siden bare avsenderen besitter den private nøkkelen, kan avsenderen ikke nekte for å ha signert meldingen (uavviselighet)

---

## Oppsummering av all informasjon

Kryptografi beskytter informasjon ved å gjøre den uleselig for uautoriserte. Vi bruker den overalt: WiFi, mobilnett, HTTPS, VPN og WPA.

- **Symmetrisk kryptering** – samme nøkkel krypterer og dekrypterer. Rask og effektiv, men nøkkelen må deles sikkert. Gir konfidensialitet og autentisering, men ikke integritet
- **Asymmetrisk kryptering** – to nøkler: en offentlig og en privat. Tregere enn symmetrisk, oftest løst med en hybrid modell der asymmetrisk kryptering utveksler en symmetrisk nøkkel (f.eks. Diffie-Hellman)
- **Hash-funksjoner** – enveis-funksjoner som lager en sjekksum av data. Brukes til passordlsagring, integritetssjekk og verifisering, og er ikke-reversible
- **Digital signatur** – signerer en melding med den private nøkkelen og verifiseres med den offentlige. Gir autentisering og uavviselighet
- **Gode tilfeldige tall** – viktige for å generere nøkler og salt som ikke kan gjettes
- **Sikkerhet i praksis** – kryptering er bare så sterk som svakhetene i algoritme, implementasjon og nøkler. Gode passord og sterke algoritmer (f.eks. AES) er avgjørende