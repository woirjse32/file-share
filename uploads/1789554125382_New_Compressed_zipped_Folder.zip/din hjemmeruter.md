# din hjemmeruter in1020

lagene jobber sammen

## kringkasting (send til alle)

- en melding som sendes ut på en spesiell adresse.
- leveres til alle enheter som er koblet på samme LAN (nettverk)
  - linklaget (MAC): FF:FF:FF:FF:FF:FF
  - IP/nett: 255.255.255.255

  - for en masken på et subnett finner du kringkastingsadressen ved å gjøre en bitvis OR-operasjon mellom gitt IP-adresse og bitvis invers av nettverksmasken
    - eks IP-adresse: 192.168.1.5, nettverksmaske: 255.255.255.0
    - (192.168.1.5 OR (0.0.0.255) = 192.168.1.255)

## anatomien til et LAN – et typisk oppsett

- LAN-id (CIDR): 192.168.0.0/24
- kringkastingsadresse: 192.168.0.255

- tilgjengelige adresser: 192.168.0.1–192.168.0.254
  - 254 adresser
  - men 1 av disse settes typisk av til ruter om du skal koble LAN til internett
    - 192.168.0.1
    - ruteren fungerer ofte også som DHCP-tjener og DNS-cache i hjemmenettverk

### DHCP-utdeling av IP-adresser

> Automatisk utdeling av IP-adresser

**1. DHCP Discovery**
Klienten sender en broadcast på nettverket for å finne en DHCP-tjener. Den bruker kilde-IP 0.0.0.0 og mål-IP 255.255.255.255 fordi den ennå ikke har fått en IP-adresse.

**2. DHCP Offer**
DHCP-tjeneren svarer med et tilbud som inneholder en ledig IP-adresse, nettverksmaske, gateway og DHCP-leasetid. Dette sendes som en broadcast slik at klienten mottar det.

**3. DHCP Request**
Klienten godtar tilbudet og sender en broadcast for å bekrefte at den ønsker akkurat denne IP-adressen. Andre DHCP-tjenere på nettverket ser dette og kan gi bort sin tilbudte adresse til andre klienter.

**4. DHCP Acknowledge**
DHCP-tjeneren bekrefter tildelingen med en siste melding. Nå har klienten gyldig IP-konfigurasjon og kan kommunisere på nettverket.

### ARP-kobling mellom nettverk- og linklaget

> Address Resolution Protocol

ARP kobler sammen IP-adresser og MAC-adresser. Når en enhet kjenner en IP-adresse men ikke MAC-adressen, sender den en ARP-forespørsel for å finne ut hvilken MAC-adresse som tilhører denne IP-en.

### ARP-protokollen

| Enhet   | IP           | MAC               |
|---------|--------------|--------------------|
| ruter   | 192.168.0.1  | AA:BB:CC:DD:EE:01  |
| laptop  | 192.168.0.10 | AA:BB:CC:DD:EE:02  |
| laptop1 | 192.168.0.11 | AA:BB:CC:DD:EE:03  |
| maskin 1| 192.168.0.12 | AA:BB:CC:DD:EE:04  |

**ARP-forespørsel:**
- Kilde-IP: 192.168.0.10, Kilde-MAC: AA:BB:CC:DD:EE:02
- Mål-IP: 192.168.0.1, Mål-MAC: FF:FF:FF:FF:FF:FF (broadcast)

**ARP-svar:**
- "192.168.0.10 har MAC AA:BB:CC:DD:EE:02" sendes tilbake til avsenderen

## for store kringkastingsdomener

Hvis et kringkastingsdomene inneholder for mange enheter, kan det by på problemer:

- ARP-forespørsler går til alle maskiner i domenet. Hvis domenet er for stor kan dette gå utover ytelsen og skape unødvendig trafikk.
- DHCP-forespørsler går også til alle enheter i domenet.
- Flere ARP- og DHCP-meldinger kan føre til overbelastning i store nettverk.

### ARP kan også brukes til å avsløre feil

- Hvis to enheter bruker samme IP-adresse, kan en ARP-forespørsel avsløre konflikten. En enhet kan svare på en ARP-forespørsel for en IP den ikke eier, og dermed oppdages duplikat-IP-problemer.


### Porter og IP-adresser

- maks antall mulige IP-adresser på 32 bit er 2^32 = 4 294 967 296

#### NAT – Network Address Translation

> Dette gjør at en IP-adresse kan deles på flere maskiner.

### En IP-adresse, mange porter

IP: 192.168.1.5

> Transportprotokollene UDP og TCP implementerer porter som muliggjør til sammen 65 535 samtidige forbindelser på en IP-adresse.

## hvordan fungerer dette i praksis:

Når flere enheter på et hjemmenettverk (f.eks. 192.168.0.10, 192.168.0.11) skal ut på internett, har de bare én offentlig IP-adresse fra internettleverandøren. Ruteren bruker NAT til å oversette den interne IP-adressen og porten til den offentlige IP-adressen sin, og fører opp dette i en oversiktstabell. Når svar kommer tilbake, bruker ruteren denne tabellen til å videresende trafikken til riktig enhet på innsiden av nettverket.

## ulemper med NAT

- ekstra kompleksitet i nettverket
- ruteren må bevare tilstanden til forbindelsene
- nye forbindelser må initieres fra innsiden av NAT-nettverket
- gjør det vanskelig å koble til utenfra

  - Universal Plug and Play (UPnP)
    - enheter på LAN kan automatisk åpne opp porter for enheter utenfra
  - videresending av porter
  - demilitarized zone (DMZ): en enhet settes i DMZ og får all trafikk fra ruteren videresendt

## ruting i nettverk

- målet med ruting er å videresende en datapakke slik at den til slutt når måladressen sin
- en internett-leverandør (ISP) driver et nettverk og leverer datatransport til andre ISPer og sluttkunder
- ISP-peering: to ISPer inngår avtaler om å videresende hverandres trafikk uavhengig, og kan på denne måten bestemme hvordan trafikken flyter
- Border Gateway Protocol (BGP): brukes mellom AS-er (autonome systemer) for å utveksle ruteinformasjon og bestemme den beste veien gjennom internett
- Open Shortest Path First (OSPF): en inter routing-protokoll som bruker link-state-algoritmer for å finne korteste vei innenfor et enkelt AS

### traceroute viser deg hvor trafikken går

- kommandoene "traceroute" (Linux/Mac) og "tracert" (Windows) bruker protokollen ICMP (Internet Control Message Protocol) til å spore hvilke ruter datapakkene er innom på veien til målet.

## kryptering (/ sikkerhet i lagene)

- WiFi Protected Access (WPA): kryptering på trådløse nettverk som krypterer forbindelsen mellom deg og aksesspunkten / ruteren.

#### Applikasjonslaget, Transportlaget, IP/Internett, Linklaget, Fysiske lag

- **Fysiske lag**: fysisk overføring av bits over medium (kabel, radio, fiber)
- **Linklaget**: feilfri overføring mellom to noder på samme nettverk (Ethernet, MAC-adresser)
- **IP/Internett-laget**: adressering og ruting av pakker på tvers av nettverk (IP-adresser, rutere)
- **Transportlaget**: ende-til-ende-overføring og feilkontroll (TCP, UDP, porter)
- **Applikasjonslaget**: tjenester for applikasjoner (HTTP, DNS, SMTP)

**Sikkerhetsteknologier:**
- **TLS**: krypterer kommunikasjon mellom klient og server på applikasjonsnivå (HTTPS)
- **TCPCrypt**: krypterer TCP-forbindelser på transportlaget uten å endre applikasjoner
- **VPN**: oppretter en kryptert tunnel over et usikkert nettverk, ofte over IP-laget
- **WPA**: krypterer trådløs kommunikasjon på linklaget


