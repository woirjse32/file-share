# Hvordan hackes vi?
## Definisjoner

- Sårbarhet: En feil som kan benyttes for angrep.
- Nulldags-sårbarhet: En "feil" som noen har kunnskap om før leverandøren har.
- Sårbarhetsflate: Summen av (de potensielle) feilene (sårbarhetene) som er i et system.
- Skadevare: En vare som brukes for å skade et system (virus, trojanere).

## Skadevare

- Løsepengevirus (ransomware): brukes for å kryptere filer og kreve penger for at offeret ikke skal miste tilgangen til dem eller få dem delt ut.
- Dataorm: et program som sender seg selv, slik at det vokser til å infisere flere maskiner.
- Trojanere: apper som kan lese hele PCen, men som ikke viser dette til brukeren, slik at de kan være der lenge og finne ut mer info (bankinfo, ID, osv.).
- Bakdør: en ukjent / ubeskyttet vei inn i et system som lar aktører komme inn i systemet. (Disse kan bli plassert inn av snille aktører.)
- Spionvare: et program for å spionere på brukerne.
- Tastelogger (keylogger): en app som tar opp tastetrykk (keyboard inputs) for å finne sensitiv info.
- Rootkit: et verktøy for skadevare å få større tilgang, f.eks. ved å endre seg selv til "svchost.exe" i systemfiler slik at programmet starter med høyere privilegier.
- Exploit: en "bakdør" eller programfeil som kan benyttes for å bruke programmet / OS-et på en måte det ikke er ment å bli brukt på.

## Sikkerhetstiltak

### Hvordan beskytte info

- Lagret info:
   - Lagret info kan være lagret på flere måter (HDD, SSD, skyen):
- Riktig tilgangskontroll og autorisasjon
- Å kryptere dataene som ligger på enhetene, slik at de ikke kan fås uten passord.
- Sikkerhetskopiering.
- Gode retningslinjer for data: hvordan kvitte seg med fysiske enheter som inneholder data, uten å potensielt lekke data?

   #### Sikkerhetsutfordringer

    - Applikasjonssikkerhet
    - Systemsikkerhet

### Angrepsvektorer

  - Dialog med brukere
  - Behandling input fra brukere
  - I bakkant av applikasjon benyttes en database for lagring av informasjon.

## Cross site scripting (XSS)

  > Hvis nettstedet ikke sanitiserer brukerinput, kan brukere misbruke kommentarer / inputs for å manipulere nettstedets funksjoner.

