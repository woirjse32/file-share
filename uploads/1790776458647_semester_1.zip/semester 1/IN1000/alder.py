# oppgave: Gitt en tekstfil av typen vist under (anavn og alder)
# skriv et program som leser filen og skriver ut navenet op den elste 
# personeen i fila.

alder = open("alder.csv")

alderarr = []
navnarr = []
for i in alder:
    deler = i.split(":")
    alderarr.append(int(deler[1].strip()))
    navnarr.append(deler[0].strip())
alder.close()

maks = alderarr[0]
navn = navnarr[0]
count = 1
while count < len(alderarr):
    if alderarr[count] > maks:
        maks = alderarr[count]
        navn = navnarr[count]
    count = count + 1

print(navn)
    
    