
def ordlengde(ord):
    teller = 0
    for tegn in ord:
        teller = teller + 1
    return teller

def setningstilord(setning, ord):
    teller = 0
    arr = setning.slice()
    for i in arr:
        if str(ord).upper() == arr[i].upper():
            teller = teller + 1
    return teller

