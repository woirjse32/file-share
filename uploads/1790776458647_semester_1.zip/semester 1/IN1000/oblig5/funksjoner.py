# en funksjons som tar in 2 parametre (tall1 og tall2) og gir ut sum

def adding(tall1, tall2):
    sum = tall1 + tall2
    return sum

# call 1
tallnr1 = 2
tallnr2 = 3
sum = adding(tallnr1, tallnr2)
print("Jeg adder "+str(tallnr1)+" og "+str(tallnr2)+" som blir: "+str(sum))

# call 2
tallnr1 = 3
tallnr2 = 2
sum = adding(tallnr1, tallnr2)
print("Jeg adder "+str(tallnr1)+" og "+str(tallnr2)+" som blir: "+str(sum))

# spør brukeren for settning og bokstav
strengin = str(input("Skriv en settning. "))
bokstavin = str(input("gi meg en bokstav. "))


# lager en funksjon som tar in strengen og bokstaven og finner ut hvor mange / vis, -
# --> bokstaven har blitt neven it settningen og retuerner verdien.

def telling(streng, bokstav):
    if bokstav in streng:
        antall = 0
        for tegn in streng:
            if tegn == bokstav:
                antall = antall + 1
        print("Bokstaven "+bokstav+" er nevnt "+str(antall)+" ganger.")
        return antall
    else:
        print("Bokstaven "+bokstav+" er ikke nevnt i settningen.")
        return 0


#kjører funksjonen. (caller den).
telling(strengin, bokstavin)

# tar in parameterene og bruker upper for å skejkke om bokstav finnes i string.
def tell_forekomst(min_tekst, min_bokstav):
    antall = 0
    for tegn in min_tekst:
        if tegn.upper() == min_bokstav.upper():
            antall = antall + 1
    return antall

Oppgave:
"
(Obligatorisk) Oppgave 1: Parametre og returverdier 
Filnavn: funksjoner.py 
1. Skriv et program med en funksjon adder(tall1, tall2) som tar to heltall som 
parametere. Funksjonen skal summere tallene og returnere resultatet. Kall på 
funksjonen to ganger med argumenter du selv velger, og skriv ut resultatene med en 
passende tekst. 
2. Be så brukeren om å skrive inn en tekststreng, og deretter en bokstav. Programmet 
må skrive ut hvor mange ganger den oppgitte bokstaven forekommer i den oppgitte 
tekststrengen. Du skal ikke regne stor og liten bokstav som like (det vil for eksempel 
si at det er 0 forekomster av “E” i ordet “hei”). 
3. Skriv en funksjon tell_forekomst(min_tekst, min_bokstav). Funksjonen skal telle hvor 
mange ganger en bokstav min_bokstav forekommer i teksten min_tekst, og returnere 
dette tallet. Skriv deretter om kodelinjene fra punkt 2 til å benytte denne funksjonen, 
men sørg for at programmet fremstår helt likt for brukeren når det kjøres. Før du 
avslutter skriver du resultatene ut på terminal. 
Lever programmet slik det ser ut etter at du har gjort alle endringer (du trenger altså 
ikke å levere to versjoner av programmet).  
"
har ikke gjort nr 3:

