def spør():
    tern = input("hva fikk du? ")
    return tern

tall = []

count = 0
while count < 5:
    tern = spør()
    tall.append(tern)
    count = count + 1

print(tall)

antall = tall.count("4")

print(antall)

lengde = len(tall)
tall2 = []
count2 = 0
while count2 < lengde:
    tall2.append(tall[count2])
    count2 = count2 + 1

if len(tall2) == 1:
    print("3j3")