# IN1000 Obligatoriske innleveringer – Høst 2026

8 obligatoriske innleveringer totalt. De 3 første er hentet fra UiO sine nettsider (PDF).
Oppgave 4–8 er ikke publisert ennå (legges ut fortløpende hver uke).

---

## Oblig 1 – Frist: 25. august 2026 kl. 23:59

**Introduksjon**

Velkommen til første obligatoriske oppgave i IN1000! Oppgavene (og neste ukes undervisning) forutsetter at du har tatt forkurs (evt på egen hånd) og jobbet med ukens pensum til du har god kontroll på stoffet.

For å få godkjent denne obligatoriske oppgaven må du innen fristen:
1. Besvare quizen i Nettskjema. Det er ingen krav til antall rette.
2. I Devilry:
   - Levere skjermbilde (.jpg) av svarsiden i Nettskjema
   - Levere filer som angitt i oppgave 0, 1, og deloppgave 1-3 på oppgave 2

For hvert program du skriver, skal du legge inn en kommentar i toppen av filen som forklarer hva programmet gjør. Videre forventes det at du kommenterer koden underveis.

### Oppgave 0: Filsystem og kjøring av Python-programmer
Ta bilde av skjermen din som viser navigering i filsystemet i terminalen.
- Filnavn: `filsystem.jpg`
1. Åpne terminalen din og start i roten av filsystemet.
2. Finn frem til IN1000-mappen din ved hjelp av kommandoene `cd`, `ls` og `pwd`.
3. Bruk `ls`-kommandoen til å skrive ut innholdet i IN1000-mappen din.
4. Ta skjermbilde av terminalvinduet ditt, og lever skjermbildet.

### Oppgave 1: Utskrift og innlesing med variabler
- Filnavn: `variabler.py`
1. Lag en fil ved navn `variabler.py`.
2. Skriv et program som skriver ut teksten `"Hei Student!"` til terminalen.
3. Legg til kode slik at programmet ber brukeren om å oppgi et navn og ta vare på verdien i en variabel `navn`. Skriv så ut `"Hei "` og innholdet i variabelen `navn`.
4. Be brukeren om å skrive inn et nytt navn, og legg svaret i en ny variabel. Lag en variabel `sammen` med verdien av det første navnet etterfulgt av det andre navnet. Skriv ut `sammen` på en ny linje.
5. Endre verdien av `sammen` ved å slå sammen de to navnene med `"og"` mellom (f.eks. `"Ola og Kari"`). Utvid programmet ved å legge til en ny linje, ikke endre den opprinnelige.

### Oppgave 2: Problemløsning
- Filnavn: `meny.py`
1. Skriv ut en liten restaurantmeny med tre hovedretter (én vegetarrett) og to tilbehør (én grønnsak, én saus).
2. Be brukeren velge én hovedrett og ett tilbehør. Les inn i to variabler.
3. Logikk for vegetarmåltid-meldinger:
   - Ikke-vegetarisk hovedrett + ikke-grønnsakstilbehør → `"Du spiser ikke nok grønnsaker!"`
   - Begge med grønnsaker → `"Du har valgt et vegetarmåltid"`
   - Bare én med grønnsaker → skriv ut kombinasjonen (f.eks. `"Du har valgt biff med gulrøtter"`)
4. (Frivillig) Skriv et alternativt program `meny2.py` som løser punkt 3 på en annen måte.

---

## Oblig 2 – Frist: 1. september 2026 kl. 23:59

**Læringsmål:** Forstå kodeflyt, forskjellige datatyper og gjenbruk av kode ved hjelp av prosedyrer.

### Oppgave 1 – Utskriftsprosedyre
- Filnavn: `utskriftsprosedyre.py`
1. Lag et program som tar inn et navn og et bosted fra terminalen og skriver ut en hilsen. Eksempel:
   ```
   > python3 utskriftsprosedyre.py
   Skriv inn navn: Espen Askeladd
   Hvor kommer du fra? Oslo
   Hei, Espen Askeladd! Du er fra Oslo.
   ```
2. Flytt koden til en egen prosedyre. Kall prosedyren 3 ganger for 3 forskjellige personer.

### Oppgave 2: Konvertering
- Filnavn: `fahrenheit_celsius.py`
1. Ta inn en temperatur i Fahrenheit fra brukeren.
2. Konverter til Celsius: `(F - 32) * 5/9`
3. Skriv ut resultatet.
4. Utvid: la brukeren velge mellom F og C, og konverter riktig vei:
   - F → C: `(F - 32) * 5/9`
   - C → F: `(C / 5) * 9 + 32`
5. Test med 100 F → ca. 37,78 C.

### Oppgave 3: Kodeflyt (tekstoppgave, leveres som PDF)
Forklar programflyten ved å skrive tall foran linjene i rekkefølgen de utføres. Program å nummerere:

```python
def print_prosa():
    print("Melding til alle gaardeiere:")
    print("Antall dyr paa gaarden: ")
    antall_dyr = int(input())
    return antall_dyr

antall_dyr = print_prosa()

antall_nye_dyr = int(input("Hvor mange nye dyr kommer paa gaarden? "))
antall_dyr = antall_dyr + antall_nye_dyr

print_prosa()
print(antall_dyr)

if antall_dyr > 12:
    print("Det er mer enn ett dusin dyr paa gaarden!")
elif antall_dyr == 12:
    print("Det er ett dusin dyr paa gaarden!")
else:
    print("Det er mindre enn ett dusin dyr paa gaarden!")
```

Anta at brukeren taster inn tallet 8 under kjøring.

### Oppgave 4: Kodeforståelse og feilsøking
- Filnavn: `kodeforstaaelse.py`
- Besvar teorispørsmålene som kommentarer øverst i filen.

```python
a = input("Tast inn et heltall! ")
b = int(a)
if b < 10:
    print(b + "Hei!")
```

Spørsmål:
1. Vil programmet kjøre? Begrunn.
2. Hvilke problemer vil vi kunne møte på?

### Oppgave 5: Egen oppgave
1. Skriv din egen oppgavetekst om beslutninger (if/elif/else).
2. Løs oppgaven. Lever både oppgaveteksten og besvarelsen.

---

## Oblig 3 – Frist: 8. september 2026 kl. 23:59

**Læringsmål:** Holde styr på mange verdier ved hjelp av lister, mengder og ordbøker.

### Oppgave 1 – Lister
- Filnavn: `lister.py`
1. Lag en liste med 3 tall. Legg til 10 til på slutten.
2. Skriv ut lengden på lista.
3. Legg til 5 til på begynnelsen.
4. Slett tredje element i lista.
5. Skriv ut lista sortert i synkende rekkefølge.
6. Spør brukeren om et navn, og lag en liste med 3 navn inkludert det brukeren skrev inn.
7. Sjekk om ditt eget navn finnes i lista. Skriv ut `"Du husket meg!"` eller `"Glemte du meg?"`.

### Oppgave 2: Samling
- Filnavn: `samling.py`
1. Lag en ordbok med butikkvarer og priser: melk – kr 14.90, brød – kr 24.90, yoghurt – 12.90, pizza – 39.90. Skriv ut innholdet.
2. Les inn to nye varer og priser fra brukeren, legg til i ordboken. Skriv ut på nytt.
3. Spør brukeren hvilken vare de vil kjøpe, og skriv ut prisen.

### Oppgave 3: Billettpris
- Filnavn: `billettpris.py`
1. Lag en prosedyre som spør om alder og skriver ut billettpris basert på aldersgruppe: barnebillett, standardbillett, seniorbillett.
2. Test med 3 forskjellige aldre (én per kategori).

### Oppgave 4: Matplan
- Filnavn: `matplan.py`
1. Lag en datastruktur som kobler 5 beboere på et sykehjem til frokost, lunsj og middag. Lag en prosedyre som skriver ut navnene, ber brukeren om å velge én, og skriver ut matplanen. Melding hvis beboeren ikke er registrert.
2. Teoretisk spørsmål: Hvilken type samling (liste, mengde, ordbok) ville du brukt for:
   - Brukernavn på alle IN1000-studentene
   - Brukernavn og antall studiepoeng for hver IN1000-student
   - Alle vinnere i Lotto siste år (kun navn)
   - All mat noen gjester er allergisk mot

### Oppgave 5: Egen oppgave
1. Skriv en oppgavetekst om lister eller ordbøker.
2. Løs oppgaven. Lever oppgaveteksten som kommentarer over løsningen.

---

## Oppgave 4–8 (ikke publisert ennå)

Disse legges ut ukentlig på https://www.uio.no/studier/emner/matnat/ifi/IN1000/h26/Obligatoriske%20innleveringer/

| Innlevering | Legges ut ca. | Frist |
|---|---|---|
| Oblig 4 | 9. september | 15. september kl. 23:59 |
| Oblig 5 | 16. september | 29. september kl. 23:59 |
| Oblig 6 | 30. september | 6. oktober kl. 23:59 |
| Oblig 7 | 7. oktober | 20. oktober kl. 23:59 |
| Oblig 8 | 21. oktober | 3. november kl. 23:59 |
