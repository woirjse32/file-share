# Grunnleggende prinsipper for informasjonssikkerhet

## 1. Kitpaus (Kjerneprinsipper)

Kitpaus refererer til de grunnleggende prinsippene som danner grunnlaget for all informasjonssikkerhet. Disse prinsippene er universelle og gjelder uavhengig av teknologi, organisasjon eller kontekst.

### Hvorfor er kitpaus viktig?
- Gir et felles rammeverk for å forstå sikkerhetsbegreper
- Brukes som utgangspunkt for sikkerhetsvurderinger og risikoanalyser
- Hjelper organisasjoner med å bygge robuste sikkerhetsløsninger

### De viktigste kitpausene
| Prinsipp | Beskrivelse |
|----------|-------------|
| **Konfidensialitet** | Beskytte informasjon mot uautorisert tilgang |
| **Integritet** | Sikre at informasjon ikke endres uautorisert |
| **Tilgjengelighet** | Gjøre informasjon tilgjengelig for autoriserte brukere når de trenger det |
| **Personvern** | Beskytte enkeltpersoners privatliv |
| **Autentisitet** | Verifisere identiteten til brukere og systemer |
| **Ubenektelighet** | Forhindre at noen kan nekte handlinger de har utført |
| **Sporbarhet** | Spore handlinger og hendelser i et system |

---

## 2. Konfidensialitet

Konfidensialitet handler om å beskytte informasjon mot uautorisert tilgang og avsløring. Kun personer med riktig autorisasjon skal kunne lese eller få tilgang til sensitiv informasjon.

### Prinsipper for konfidensialitet
- **Need-to-know**: Kun gi tilgang til informasjon som er nødvendig for å utføre oppgaven
- **Least privilege**: Gi brukere minst mulig tilgang som er nødvendig
- **Separation of duties**: Del opp oppgaver slik at ingen enkeltperson har for mye makt

### Mekanismer for å opprettholde konfidensialitet
- **Kryptering**: Beskytte data i hvile og under overføring
- **Autentisering**: Verifisere brukeres identitet før tilgang
- **Autorisasjon**: Kontrollere hva brukere har lov til å gjøre
- **Fysisk sikring**: Låse dører, sikre serverrom

### Eksempler på brudd på konfidensialitet
- Datatyveri fra en database
- En ansatt som leser kollegas e-post uten tillatelse
- Uautorisert tilgang til skytjenester
- Phishing-angrep som gir tilgang til påloggingsinformasjon

### Konsekvenser av brudd
- Identitetstyveri
- Økonomisk tap
- Tap av tillit fra kunder og partnere
- Juridiske konsekvenser og bøter

---

## 3. Integritet

Integritet handler om å sikre at informasjon er korrekt, komplett og upåvirket av uautoriserte endringer. Data skal være pålitelig og troverdig.

### Prinsipper for integritet
- **Autorisasjon for endringer**: Kun autoriserte personer skal kunne endre data
- **Sporbarhet**: Alle endringer skal loggføres og kunne spores
- **Konsistens**: Data skal være konsistent på tvers av systemer
- **Validering**: Sjekke at data oppfyller forventede krav

### Mekanismer for å opprettholde integritet
- **Hashing**: Bruke hash-funksjoner for å oppdage endringer
- **Digitale signaturer**: Verifisere opphav og ekthet
- **Versjonskontrol**: Spore endringer over tid
- **Transaksjonslogger**: Dokumentere alle endringer
- **Backup og gjenoppretting**: Muligheten til å gjenopprette korrekte data

### Eksempler på brudd på integritet
- Uautoriserte endringer i regnskapsdata
- Manipulering av loggfiler for å skjule aktivitet
- Feil i databasen som gir uriktige data
- Man-in-the-middle-angrep som endrer data under overføring

### Typer integritet
| Type | Beskrivelse |
|------|-------------|
| **Dataintegritet** | Korrekthet og fullstendighet av data |
| **Systemintegritet** | At systemet fungerer som det skal uten uautoriserte endringer |
| **Prosessintegritet** | At prosesser kjører korrekt og ikke manipuleres |

---

## 4. Tilgjengelighet

Tilgjengelighet handler om å sikre at autoriserte brukere har tilgang til informasjon og ressurser når de trenger det. Systemer og data skal være operative og nåbare.

### Prinsipper for tilgjengelighet
- **Redundans**: Ha reservekomponenter og systemer
- **Feiltoleranse**: Systemet skal kunne håndtere feil uten å falle sammen
- **Høy oppetid**: Mål for hvor lenge systemet skal være tilgjengelig (f.eks. 99,9%)
- **Gjenoppretting**: Muligheten til å komme seg etter driftsstans

### Mekanismer for å opprettholde tilgjengelighet
- **Lastbalansering**: Fordel trafikk mellom flere servere
- **Replikering**: Kopiere data til flere steder
- **Backup**: Regelmessig sikring av data
- **Brannmurer og DDoS-beskyttelse**: Beskytte mot angrep som kan lamme systemer
- **Feilsøking og overvåking**: Oppdage og løse problemer raskt

### Eksempler på brudd på tilgjengelighet
- DDoS-angrep som overvelder en nettside
- Hardware-feil som tar ned en server
- Naturkatastrofer som skader datasenter
- Programvarefeil som gjør systemet utilgjengelig

### Mål for tilgjengelighet
| Oppetid | Nedetid per år | Nedetid per måned |
|---------|----------------|-------------------|
| 99% | 3,65 dager | 7,2 timer |
| 99,9% | 8,76 timer | 43,8 minutter |
| 99,99% | 52,6 minutter | 4,38 minutter |
| 99,999% | 5,26 minutter | 26,3 sekunder |

---

## 5. Personvern (Privacy)

Personvern handler om retten til å bestemme over egen informasjon og hvordan den brukes. Det innebærer beskyttelse av personlige data og respekt for enkeltpersons privatliv.

### Prinsipper for personvern
- **Dataminimering**: Samle inn kun nødvendig informasjon
- **Formålsbegrensning**: Bruke data kun til det formålet de ble samlet inn for
- **Innsamlingssamtykke**: Innhente samtykke fra personen dataene gjelder
- **Slettingsrett**: Retten til å få slettet personlige data
- **Innsynsrett**: Retten til å se hvilke data som er lagret

### Lovgivning og regulering
- **GDPR (General Data Protection Regulation)**: EUs personvernforordning
- **Personopplysningsloven**: Norsk lovgivning for personvern
- **EUs ePrivacy-direktiv**: Regler for elektronisk kommunikasjon

### Typer personlige data
| Kategori | Eksempler |
|----------|-----------|
| **Identifikasjonsdata** | Navn, fødselsnummer, adresse |
| **Helseopplysninger** | Medisinsk historikk, diagnoser |
| **Økonomiske data** | Bankkonto, kredittkort, lønn |
| **Biometrisk data** | Fingeravtrykk, ansiktsgjenkjenning |
| **Atferdsdata** | Nettleserhistorikk, kjøpsmønstre |

### Konsekvenser av brudd på personvern
- Identitetstyveri
- Diskriminering
- Økonomisk tap for den enkelte
- Tap av tillit til organisasjoner
- Juridiske sanksjoner og bøter

---

## 6. Autentisering

Autentisering er prosessen med å verifisere identiteten til en bruker, enhet eller system. Det handler om å bevise at man er den man gir seg ut for å være.

### Faktorer for autentisering
| Faktor | Beskrivelse | Eksempler |
|--------|-------------|-----------|
| **Noe du vet** | Hemmelig informasjon | Passord, PIN-kode, sikkerhetsspørsmål |
| **Noe du har** | Fysisk enhet eller token | Smartkort, mobiltelefon, nøkkelbrikke |
| **Noe du er** | Biometriske egenskaper | Fingeravtrykk, ansikt, stemme |
| **Noe du gjør** | Atferdsmønstre | Skrivemønster, bevegelsesmønster |
| **Noe du er på** | Posisjon eller nettverk | GPS, IP-adresse, Wi-Fi-nettverk |

### Autentiseringsmetoder
- **Enfaktor-autentisering (SFA)**: Kun én faktor (f.eks. passord)
- **Tofaktor-autentisering (2FA)**: To faktorer (f.eks. passord + kode på mobil)
- **Multifaktor-autentisering (MFA)**: To eller flere faktorer
- **Svak autentisering**: Kun én svak faktor (f.eks. bare passord)
- **Sterk autentisering**: Minst to faktorer, hvorav én er dynamisk

### Autentiseringsprotokoller
- **Kerberos**: Billetterbasert autentisering i nettverk
- **OAuth 2.0**: Autorisasjonsrammeverk for API-tilgang
- **OpenID Connect**: Identitetslag på toppen av OAuth 2.0
- **SAML**: Utveksling av autentiserings- og autorisasjonsdata
- **FIDO2/WebAuthn**: Passordløs autentisering med sikkerhetsnøkler

### Utfordringer med autentisering
- Phishing og sosial manipulering
- Brute force-angrep
- Passordlekkasjer
- Man-in-the-middle-angrep
- Session hijacking

---

## 7. Ubenektelighet (Non-repudiation)

Ubenektelighet handler om å forhindre at en part kan nekte å ha utført en handling. Det gir bevis for opphav, levering og innhold av en melding eller transaksjon.

### Viktigheten av ubenektelighet
- Juridisk bevis i rettssaker
- Ansvarliggjøring for handlinger
- Tillit i elektronisk handel
- Sikkerhet i digitale kontrakter

### Mekanismer for ubenektelighet
- **Digitale signaturer**: Kryptografisk bevis for opphav
- **Tidsstempler**: Dokumentere når en handling fant sted
- **Loggføring**: Detaljerte logger av alle handlinger
- **Blokkjede**: Desentralisert verifisering av transaksjoner
- **Sertifikater**: Digital identifikasjon fra可信tredjeparter

### Eksempler på bruk
- Digitale kontrakter og avtaler
- Elektronisk handel og betalinger
- E-postkorrespondanse i juridisk sammenheng
- Loggføring i sikkerhetssystemer

### Juridisk status
- **EUs eIDAS-forordning**: Gir digitale signaturer samme juridiske status som håndskrevne
- **Norsk lovgivning**: Anerkjenner digitale signaturer som bevis
- **Internasjonale standarder**: ISO 27001 inkluderer krav til ubenektelighet

---

## 8. Sporbarhet (Accountability/Traceability)

Sporbarhet handler om å kunne spore handlinger, hendelser og endringer i et system. Det innebærer å kunne Identifisere hvem som gjorde hva, når og hvordan.

### Prinsipper for sporbarhet
- **Identifikasjon**: Kunne identifisere alle parter som utfører handlinger
- **Autentisering**: Verifisere identiteten til de som utfører handlinger
- **Autorisasjon**: Kontrollere hvilke handlinger som er tillatt
- **Logging**: Dokumentere alle handlinger og hendelser
- **Revisjon**: Gjennomgå logger for å oppdage uregelmessigheter

### Elementer av sporbarhet
| Element | Beskrivelse |
|---------|-------------|
| **Hvem** | Identitet til den som utførte handlingen |
| **Hva** | Handlingen som ble utført |
| **Når** | Tidspunktet for handlingen |
| **Hvor** | Plasseringen eller systemet der handlingen fant sted |
| **Hvorfor** | Årsaken eller formålet med handlingen |
| **Hvordan** | Metoden som ble brukt |

### Verktøy for sporbarhet
- **SIEM (Security Information and Event Management)**: Samler og analyserer sikkerhetslogger
- **Loggføringssystemer**: Centralisert lagring av logger
- **Intrusion Detection Systems (IDS)**: Oppdager mistenkelig aktivitet
- **Overvåkingsverktøy**: Sanntidsovervåking av systemer og nettverk
- **Audit trails**: Detaljerte logger av alle endringer

### Lover og forskrifter
- **GDPR**: Krav til å kunne spore behandling av personopplysninger
- **ISO 27001**: Standard for informasjonssikkerhetsstyring inkluderer sporbarhet
- **PCI DSS**: Standard for betalingskortindustrien med krav til logging

---

## Sammenheng mellom prinsippene

```
                    ┌─────────────────┐
                    │   KITPAUS       │
                    │ (Kjerneprinsipper) │
                    └────────┬────────┘
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
        ▼                    ▼                    ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│Konfidensialitet│   │  Integritet   │   │Tilgjengelighet│
└───────┬───────┘   └───────┬───────┘   └───────┬───────┘
        │                    │                    │
        └────────────────────┼────────────────────┘
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
        ▼                    ▼                    ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│  Personvern   │   │Autentisering  │   │Ubenektelighet │
└───────┬───────┘   └───────┬───────┘   └───────┬───────┘
        │                    │                    │
        └────────────────────┼────────────────────┘
                             │
                             ▼
                    ┌───────────────┐
                    │ Sporbarhet    │
                    └───────────────┘
```

### Hvordan prinsippene støtter hverandre
- **Autentisering** er grunnlaget for **konfidensialitet** og **autorisasjon**
- **Integritet** sikrer at data ikke manipuleres, som støtter **ubenektelighet**
- **Sporbarhet** gir grunnlaget for å bevise **autentisering** og **integritet**
- **Personvern** bygger på **konfidensialitet** og **tilgjengelighet**
- **Tilgjengelighet** sikrer at **autentisering** og **sporbarhet** fungerer når det trengs

---

## Oppsummering

Disse åtte prinsippene utgjør grunnlaget for all informasjonssikkerhet. For å oppnå reell sikkerhet må man vurdere alle prinsippene sammen, ikke isolert. En svakhet i ett område kan kompromittere hele sikkerheten.

| Prinsipp | Hovedfokus | Nøkkelord |
|----------|-----------|-----------|
| **Konfidensialitet** | Beskytte mot uautorisert tilgang | Hemmelighet, personvern |
| **Integritet** | Beskytte mot uautoriserte endringer | Korrekthet, pålitelighet |
| **Tilgjengelighet** | Sikre tilgang når det trengs | Oppetid, redundans |
| **Personvern** | Beskytte enkeltpersoners data | Samtykke, minimering |
| **Autentisering** | Verifisere identitet | Bevis, verifisering |
| **Ubenektelighet** | Forhindre nektelse av handlinger | Ansvar, bevisførsel |
| **Sporbarhet** | Spore handlinger og hendelser | Logging, revisjon |
