# håndtere mange verdier

## oppsett

- objekter og tjenester
- lister
- mengder
- ordbøekr
- nøstedde sammlinger

