# Parameteroverføring, skop, underveisevaluering og oppsummering

## Prosedyrer versus funksjoner i Python

- I Python er det ikke noe teknisk skille mellom prosedyrer og funksjoner.
  - Begge kalles for funksjoner og har samme form:
    ```python
    def min_funksjon(parameter):
    ```
  - Forskjellen ligger i hvordan vi bruker dem i vår egen kode.

    - Det som skiller en ekte funksjon fra en prosedyre, er at en funksjon returnerer en verdi vi er interessert i.
    - Dette ser man både ved `return` i koden, og ved at resultatet av kallet blir brukt videre, for eksempel tilordnet til en variabel.

## Parametere og returverdi

- Prosedyrer uten parametere:
  - Handler stort sett om kontrollflyt.
- Prosedyrer med parametere:
  - Handler stort sett om tilpasset gjenbruk av kode.

### Skop for variabler

- Hver funksjon har sine egne lokale variabler.
  - Variabler som tilhører én funksjon, er ikke tilgjengelige i en annen funksjon.
  - Skopet til en variabel er hvor i koden variabelen er tilgjengelig, altså hvilken funksjon den tilhører.
  - Hver variabel tilhører et navnerom som igjen er knyttet til en ramme. For vårt formål kan vi se på dette som synonymt med skop.
- Vi overfører verdier mellom funksjoner gjennom parametere og returverdier.

## Det globale skopet

- Variabler som ikke er definert inni en funksjon, kalles globale.
  - Disse globale variablene er spesielle fordi de i prinsippet er tilgjengelige inni alle funksjoner.

## Oppsummering

- Prosedyrer og funksjoner lages på samme måte i Python, men funksjoner returnerer en verdi.
- Parametere lar oss gjenbruke kode med ulik input, mens `return` lar oss sende resultater tilbake.
- Lokale variabler finnes bare innenfor sin egen funksjon (sitt eget skop).
- Globale variabler er tilgjengelige overalt, men bør brukes med forsiktighet.


## Uke 6, overblikk og repetirsjon

#### tekserler i in1000
- programflyt + språk + verktøy

- leanring edge monetum
- onketkoritent programing

Kan du lage en ny kilent, python file, eller noe, som fungerer som en oppdikter (bruker microphonen) til å høre etter, finne ut hva som blir sakt, skrive det ned, trenger ikke noe spesielt forfattning, bør fungere GODT med norsk, se om de exister noen apier, fra goodle erller noe fro slike thing,

jeg vil at den skal fungere som en extern mest optimised client, som hører etter og lagrer alt infoen i en TXT, og har en enkelt UI, som man kan se om den er aktivt, se hva den har skrevet så langt, bør være optimised to å høre etter, skrive best mulig osv.
