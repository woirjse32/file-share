count = 0

tall1 = int(input())
tall2 = int(input())

while tall1 > tall2 or count == 100:
    tall1 = tall1 - tall2
    count = count + 1

if count == 100:
    print(tall2)
else:
    print(tall1)
