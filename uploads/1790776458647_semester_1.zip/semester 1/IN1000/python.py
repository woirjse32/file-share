class student:
    # konstruktørm kun self parameter
    # instansvariabel for poeng (int)
    def __init__(self, navn):
        self.poeng = 0
        self.navn = navn

    # retunerer antall poeng
    def hent_poeng(self):
        return self.poeng

    # øker poeng med antall
    def regiseter_poeng(self, antall):
        self.poeng += antall

    # skriver ut poeng og navn
    def skriv_ut(self):
        print("Poeng:", self.poeng, "Navn:", self.navn)