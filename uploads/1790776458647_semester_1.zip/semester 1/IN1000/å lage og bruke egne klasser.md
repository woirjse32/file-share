# Å lage og bruke egne klasser — uke 7 (IN1000)

## Innhold

1. [Objektorientert programmering (OOP)](#1-objektorientert-programmering-oop)
2. [Når bruker man klasser?](#2-når-bruker-man-klasser)
3. [En måte å struktuere programmer på](#3-en-måte-å-struktuere-programmer-på)
4. [Et objekt representerer «noe»](#4-et-objekt-representerer-noe)
5. [Vi har brukt tjenester (objekter) før](#5-vi-har-brukt-tjenester-objekter-før)
6. [Klasser](#6-klasser)
7. [Metoder](#7-metoder)
8. [Å lage egne klasser](#8-å-lage-egne-klasser)
9. [Slik ser en klassedefinisjon ut (syntaks)](#9-slik-ser-en-klassedefinisjon-ut-syntaks)
10. [Opprette og bruke objekter](#10-opprette-og-bruke-objekter)
11. [Deep dive](#11-deep-dive)
12. [Fra lyspærer til studenter: et komplett eksempel](#12-fra-lyspærer-til-studenter-et-komplett-eksempel)
13. [Kort oppsummering](#13-kort-oppsummering)
14. [Selvtest](#14-selvtest)

---

## Oppsett for timen

- Hvorfor objektorientert programmering?
- Programmering med objekter
- Hvordan definere og bruke egne klasser?

## Mål for økta

Etter timen skal vi kunne:

- kjenne til motivet for objektorientert programmering
- definere en klasse, opprette objekter og kalle metoder på objektene
- bruke og forklare begrepene **klasse**, **objekt** og **instansattributt**
- forstå sentrale begreper som **grensesnitt** og **innkapsling**
- kjenne til utviklingsprosessen for en klasse: design, implementasjon og testing

---

## 1. Objektorientert programmering (OOP)

- **Kortere vei fra en kompleks virkelighet til et program.**
- Prosedyrer og funksjoner kan løse deloppgaver, men blir fort rotete i store programmer.

### Når oppgaven handlerer om felles – kanskje komplekse – data

> Eksempel: veier og trafikklys

- Vi må samle informasjon om mange ting, og behandle de samme tingene på flere måter.
- Vi må endre og koordinere lyset ut fra tidsintervaller, trykk på knapper og hvor mange kjøretøy som står i krysset.
- Resultatet blir: mange variabelnavn, komplekse strukturer og mange funksjoner som må samarbeide.

Det er her objektorientert programmering (OOP) hjelper oss: vi binder **dataene** sammen med **operasjonene** på dataene, i stedet for å ha dem hver for seg i hele programmet.

### Objekt vs. prosedyre

| Egenskap | Prosedyrer | Objekter |
|---|---|---|
| Organisering | Data og funksjoner i to grupper | Data og funksjoner sammen |
| Hva en funksjon får | Argumenter | Objektet metoden kalles på (`self`) |
| Antall «enheter» | Én funksjon, mange kall | Én klasse, mange objekter |
| Skalerer til | Litt store programmer | Store programmer |

---

## 2. Når bruker man klasser?

Klasser passer særlig godt når:

- vi skal tilby et sett med tjenester som hører sammen – en «verktøykasse» der alt samarbeider
- tjenestene innebærer å dele data over tid, for eksempel håndtering av en liste, en fil eller et tekststykke
- vi skal lage og bruke flere like objekter med samme type data og oppførsel, for eksempel lyspærer eller studenter
- vi skal simulere sammensatte fenomener ved hjelp av objekter som representerer viktige elementer, for eksempel en trafikksimulering

---

## 3. En måte å struktuere programmer på

I OOP **samler vi relaterte data og koden som jobber med dem i objekter.**

- Dataene og funksjonene som hører sammen, samles i ulike objekter.
- **Objektet tilbyr resten av programmet et sett med metoder** → dette er *grensesnittet* (interfacet) mot objektet.
- **Hvordan objektet representerer og manipulerer dataene sine, er skjult** → dette er *innkapsling* (encapsulation).
- Det vi må gjøre selv: **bestemme hvilke data og operasjoner som trengs, og hvordan de skal grupperes i klasser.**

> To spørsmål vi alltid bør stille oss:
> 1. Hvilke data hører sammen?
> 2. Hvilke operasjoner skal det være mulig å utføre på dataene?

Innkapsling og grensesnitt gjør at én og samme klasse kan brukes i mange ulike programmer, også av andre programmerere: de trenger bare å kjenne metodene, ikke detaljene inni.

---

## 4. Et objekt representerer «noe»

**Fysiske ting i virkeligheten:**

- en bil, et eple, en fysisk kontrakt, et byggeprosjekt
- en dataoppføring, en studentoppføring, et lydopptak

**I et grafisk brukergrensesnitt:**

- et vindu, en meny, en knapp, en feilmelding i et vindu

> **Hovedpoenget:** Et objekt representerer én konkret ting. To objekter av samme type (samme klasse) kan ha ulik tilstand, men oppfører seg etter de samme reglene.

---

## 5. Vi har brukt tjenester (objekter) før

Uten å ha definert en klasse selv, har vi allerede brukt en masse objekter – de innebygde typene i Python.

### Lister

```python
navnliste = []              # lager et listeobjekt (en tom liste)
navnliste.append("Ola")     # metode: legger til på slutten
navn = navnliste.pop()      # metode: tar bort siste element og returnerer det
```

Merk: `pop()` **returnerer** det den fjerner. `append()` returnerer ingenting (`None`).

### Filer

```python
utfil = open("navn.txt", "w")   # lager en fil – en eksisterende fil tømmes
utfil.write("Ola\n")            # metode: skriver til filen
utfil.close()                   # metode: lukker filen – alltid nødvendig!
```

For å lese bruker vi modus `"r"`:

```python
innfil = open("navn.txt", "r")
innhold = innfil.read()
innfil.close()
```

> Filobjektet har også «skjult» ting: Det er objektet som husker hvilken fil det peker på, og det sørger for at filen lukkes. Det er innkapsling i praksis.

---

## 6. Klasser

- Objekter av **ulike klasser** har ulik oppførsel – de tilbyr ulike tjenester, avhengig av hvilken klasse objektet tilhører.
- **Klassedefinisjonen bestemmer:**
  - hvilke tjenester (metoder) objekter av klassen tilbyr
  - hvilke data hvert enkelt objekt har, og hvordan de representeres
- Når vi har definert én klasse, kan vi opprette **så mange objekter av denne klassen** vi ønsker i programmet vårt.
- Når programmet avsluttes, forsvinner alle objektene. Dataene er borte med mindre vi har skrevet dem til fil.

> **Begreper:**
> - **Klasse** = en mal (blueprint) for en type objekt.
> - **Objekt (instans)** = en konkret ting laget ut fra malen.

---

## 7. Metoder

- En metode er i praksis en funksjon som er definert **inne i en klasse**.
- Vi kaller også metodene når de utfører tjenester, akkurat som vi kaller funksjoner.
- **Men:** en metode må alltid kalles på et bestemt objekt. Derfor bruker vi **dotnotasjon**.

```python
liste = []
liste.append("ett_element")   # metode: legg til i slutten av lista
objekt.metode(argument)
```

- `liste` er objektet, `append` er metoden, `"ett_element"` er argumentet.
- Metoden kalles alltid med parenteser: `liste.append("x")` – ikke `liste.append["x"]`.
- Trenger metoden ingen argumenter, skriver vi `liste.append()`.
- Trenger den argumenter, står de inne i parentesene: `liste.pop(0)` fjerner det første elementet.

---

## 8. Å lage egne klasser

### Oppsett: lyspærer i et hus

Vi skal lage et program som styrer lysene i et hus.

- De innebygde klassene vi har brukt (lister, filer, strenger) gir oss objekter som er nyttige i veldig mange programmer, og som gjør at vi slipper å løse de samme oppgavene på nytt hver gang.
- Nå lager vi vår egen klasse. Vi ønsker å bruke lyspærer som objekter.
- Hver lyspære skal kunne slås **på** og **av**, og vi må kunne sjekke om pæren er på eller ikke.

### Fremgangsmåte

1. Hva skal klassen tilby? – tjenester/metoder.
2. Hva skal objektene huske av data? – hvilke variabler trenger vi?
3. Skriv klassen, og skriv et enkelt testprogram som bruker den.

### Fra krav til klasse

```
Klasse:  Lyspaere
Data:    _pa          (boolsk verdi: True = på, False = av)
Metoder: __init__()   – lage en ny lyspære (slår den av som start)
         tenn()       – skrur lyset på (eller lar det være på)
         slukk()      – skrur lyset av (eller lar det være av)
         er_pa()      – er lyset på? Returnerer True/False
```

- Foreløpig holder vi bare rede på om pæren er av eller på.
- Hvert lyspæreobjekt trenger derfor bare én boolsk verdi, lagret i objektet.
- Nå vet vi hvilke metoder vi må bruke – nå lager vi klassen.

### Steg 1: klassen med metoder (første utkast)

```python
class Lyspaere:
    # Konstruktøren – metoden Python kaller automatisk når vi lager et nytt objekt
    def __init__(self):
        pass

    # Er lyset på? Returnerer en boolsk verdi
    def er_pa(self):
        pass

    # Skrur lyset på (eller lar det være på)
    def tenn(self):
        pass

    # Skrur lyset av (eller lar det være av)
    def slukk(self):
        pass
```

> `pass` betyr «gjør ingenting». Vi bruker det når vi ennå ikke vet hva metoden skal gjøre, eller for å lage en tom klasse. Husk: etter hvert metodenavn skal det stå **kolon** (`:`), ikke semikolon.

### Steg 2: ferdig klasse

```python
class Lyspaere:
    def __init__(self):
        self._pa = False        # lyset er alltid av i starten

    def er_pa(self):
        return self._pa

    def tenn(self):
        self._pa = True

    def slukk(self):
        self._pa = False
```

**Hva endret seg?**

- `self._pa = False` i konstruktøren: Hvert objekt får sin egen `_pa`.
- `return self._pa` i `er_pa()`: Metoden **gir tilbake** verdien, slik at vi kan bruke den.
- `tenn()` og `slukk()` endrer bare på dataene. De skal **ikke** returnere noe – det er unødvendig og forvirrende. (I forelesningsnotatet sto det `return self._pa = True`, som både er feil syntaks og unødvendig.)

### Steg 3: bruke klassen

```python
lyst = Lyspaere()

print(lyst.er_pa())      # False
lyst.tenn()
print(lyst.er_pa())      # True
lyst.slukk()
print(lyst.er_pa())      # False
```

Flere lamper, hver med sin egen tilstand:

```python
lampe1 = Lyspaere()
lampe2 = Lyspaere()

lampe1.tenn()
lampe2.tenn()
lampe1.slukk()

print(lampe1.er_pa())    # False
print(lampe2.er_pa())    # True  <- lampe2 ble ikke påvirket
```

Dette er hele poenget: **samme metode, forskjellige data.**

---

## 9. Slik ser en klassedefinisjon ut (syntaks)

```python
class Klassenavn:            # 1. klassenavnet skal starte med stor bokstav

    def __init__(self):      # 2. konstruktør
        ...

    def metode1(self):       # 3. metoder (navn med små bokstaver)
        ...

    def metode2(self, arg):  #    metoder kan ta argumenter i tillegg
        ...
```

- Alle objekter av én klasse tilbyr **de samme metodene**.
- Hvert objekt har **sine egne dataverdier** (kalt *attributter*).
- Alle metoder i en klasse har tilgang til `self`, som peker på **det objektet metoden ble kalt på**.
- Metoden bruker `self` for å aksessere attributtene i objektet den ble kalt for.

---

## 10. Opprette og bruke objekter

Alle innebygde typer i Python er klasser, og de har en **snarvei for å opprette objekter**:

- `str()` → oppretter og returnerer en ny streng
- `int()` → oppretter og returnerer et nytt heltall
- `list()` → oppretter og returnerer en ny liste

For klassene vi lager selv gjelder akkurat samme regel: **opprett og returner objektet ved å bruke klassenavnet med parenteser**. Parentesene kan stå tomme.

```python
lyst = Lyspaere()
```

Bruk av metoder – to former vi bør kjenne:

```python
status = lyst.er_pa()      # bruker verdien metoden gir tilbake
lyst.tenn()                # utnytter bare effekten av metoden
```

---

## 11. Deep dive

### 11.1 `self` – hva er det egentlig?

Når vi skriver:

```python
lyst.tenn()
```

så gjør Python omtrent dette:

```python
Lyspaere.tenn(lyst)        # objektet sendes inn som første argument
```

Derfor må den første parameteren i **hver** metode være `self`. Python setter den inn automatisk, så vi skal **ikke** skrive den selv når vi kaller metoden. Men vi må alltid definere den.

- `self` er bare en konvensjon for navnet. Vi kunne kalt den `this` eller `petersen`, men da ville andre programmerere blitt forvirret.
- Uten `self` visste ikke Python hvilket objekt metoden skulle jobbe med.

```python
class Lyspaere:
    def tenn(self):
        self._pa = True

    def er_pa(self):
        return self._pa
```

Hva går galt uten `self`?

```python
class Lyspaere:
    def tenn():              # feil: self mangler
        self._pa = True
```

- Kaller vi `lyst.tenn()`, får vi `TypeError`, fordi Python automatisk sender inn objektet som første argument.
- Kaller vi metoden via klassen, `Lyspaere.tenn()`, får vi `NameError`, siden `self` da ikke er definert.

### 11.2 Attributter: instansattributter vs. klasseattributter

**Instansattributter** lages inne i metodene (vanligvis i `__init__`). Da får **hvert objekt sin egen kopi**:

```python
class Lyspaere:
    def __init__(self):
        self._pa = False    # instansattributt

a = Lyspaere()
b = Lyspaere()
a.tenn()
print(b.er_pa())            # False – b har sin egen _pa
```

**Klasseattributter** skrives inne i klassen, men utenfor metodene. Da har de **alle objekter i klassen**:

```python
class Lyspaere:
    antall = 0              # klasseattributt – felles for alle lyspærer

    def __init__(self):
        self._pa = False    # instansattributt – forskjellig per lyspære
        Lyspaere.antall += 1

    def hent_antall(self):
        return Lyspaere.antall


Lyspaere()                  # lager én lyspære
Lyspaere()                  # lager én til
print(Lyspaere.antall)      # 2
```

> **Vanlig fellgruve:** Skriver vi `self.antall += 1`, lager Python et *nytt* instansattributt som bare den ene lyspæren ser. Derfor øker vi klasseattributtet med klassenavnet: `Lyspaere.antall += 1`.

Regel for hva vi bør bruke:

| Trenger hvert objekt sin egen verdi? | Bruk |
|---|---|
| Ja | Instansattributt (`self.x`) |
| Nei, det er likt for alle | Klasseattributt (`Klassenavn.x`) |

### 11.3 `return` kontra «bare endre»

Det er lett å blande sammen to ulike typer metoder:

```python
class Lyspaere:
    def __init__(self):
        self._pa = False
        self._batteri = 100

    # Endrer på objektet – gir ikke tilbake noe
    def tenn(self):
        if self._pa:
            return              # avbryter: lyset er allerede på, spar batteriet
        self._pa = True
        self._batteri -= 1

    def slukk(self):
        self._pa = False

    # Endrer på objektet og forteller hva som skjedde – gir tilbake en verdi
    def lad(self):
        self._batteri = 100
        return "Ladet opp!"
```

- Bruk `return` når **den som kaller metoden trenger et svar**.
- Hvis metoden bare skal endre på objektet, skal den ikke returnere noe.
- `return` uten verdi avslutter metoden tidlig – nyttig i «bruk ikke videre»-tilfeller.

> **Vanlig fellgruve:** Skriver du `return self._pa = True`, får du en `SyntaxError` (du kan ikke bruke `return` som tilordning), og du signaliserer i tillegg at metoden skal gi en verdi tilbake. Skriv:
> ```python
> self._pa = True
> ```

### 11.4 Innkapsling: understrek foran attributtet

Vi skrev `self._pa`, ikke `self.pa`. Hvorfor?

- En understrek foran signalerer: **dette er en intern detalj – ikke bruk det utenfra.**
- Programmet vårt skal bruke metodene (`tenn()`, `slukk()`, `er_pa()`), ikke rote med dataene direkte.
- Da kan vi endre hvordan pæren lagres (for eksempel til en teller) senere, uten å ødelegge resten av programmet.

```python
# Dårlig stil – får hverken validering eller beskyttelse
lyst._pa = "banan"
print(lyst.er_pa())     # er_pa() returnerer en streng, ikke True/False!
```

> Python håndhever ikke innkapsling automatisk (dette kalles «konvensjon over håndhevelse»). Det er fortsatt verdt å følge konvensjonen.

**Dobbel understrek (`__pa`)** betyr noe annet: Python gir deg *name mangling*, som gjør at navnet blir nesten umulig å nå utenfra klassen. Det brukes vanligvis til såkalte «dunder»-metoder.

### 11.5 La Python vise objektene dine: `__str__`

Når vi skriver `print(lyst)`, skriver Python ut noe som `<__main__.Lyspaere object at 0x7f...>`. Vi kan si fra om hva vi egentlig vil se:

```python
class Lyspaere:
    def __init__(self, rom):
        self._pa = False
        self._rom = rom

    def tenn(self):
        self._pa = True

    def slukk(self):
        self._pa = False

    def er_pa(self):
        return self._pa

    def __str__(self):
        tilstand = "på" if self._pa else "av"
        return f"Lyspaere i {self._rom} er {tilstand}"
```

```python
lyst = Lyspaere("stua")
print(lyst)             # Lyspaere i stua er av
lyst.tenn()
print(lyst)             # Lyspaere i stua er på
```

Dette er en **dunder-metode** (dobbelt understrek på begge sider). Python kaller den automatisk. Metoden skal alltid ha `self` og returnere en streng.

> Læringstips: Skriv `__str__` for hver klasse du lager. Da blir feilsøking mye enklere, fordi du kan se hvilke data objektet faktisk har.

### 11.6 Komposisjon: klasser som bygges på hverandre

Klasser trenger ikke stå alene. Ofte består et objekt av andre objekter:

```python
class Lyspaere:
    def __init__(self, rom):
        self._rom = rom
        self._pa = False

    def tenn(self):
        self._pa = True

    def slukk(self):
        self._pa = False

    def er_pa(self):
        return self._pa

    def __str__(self):
        return f"Lyspaere i {self._rom} er {'på' if self._pa else 'av'}"


class Rom:
    def __init__(self, navn):
        self._navn = navn
        self._lyspaerer = []          # en liste med Lyspaere-objekter

    def legg_til_lyspaere(self):
        lyst = Lyspaere(self._navn)
        self._lyspaerer.append(lyst)
        return lyst

    def tenn_alle(self):
        for lyst in self._lyspaerer:
            lyst.tenn()

    def antall_paa(self):
        return sum(1 for lyst in self._lyspaerer if lyst.er_pa())


stue = Rom("stua")
stue.legg_til_lyspaere()
soverom = Rom("soverommet")
soverom.legg_til_lyspaere()
soverom.legg_til_lyspaere()

stue.tenn_alle()
soverom.tenn_alle()
print(stue.antall_paa())      # 1
print(soverom.antall_paa())   # 2
```

Her ser vi hele kjeden:

- `Rom` **inneholder** flere `Lyspaere` (komposisjon).
- `Rom` har selv attributter (`_navn`, `_lyspaerer`), metoder, `__init__` og `__str__` – akkurat som `Lyspaere`.
- `Rom` bruker `lyst.er_pa()` for å spørre lyspærene om noe. Den trenger ikke å vite hvordan `_pa` er lagret.

Dette er veien videre i kurset: små, ryddige klasser som settes sammen.

### 11.7 `with` for filer

Fil-eksempelet vi brukte, kan skrives tryggere med `with`. Da blir filen lukket automatisk, også hvis programmet stopper midt i koden:

```python
with open("navn.txt", "w") as utfil:
    utfil.write("Ola\n")
```

### 11.8 Feilsøking: vanlige feil

| Feil | Riktig |
|---|---|
| `def tenn(self);` | `def tenn(self):` – kolon, ikke semikolon |
| `liste.append["x"]` | `liste.append("x")` – parenteser, ikke hakeparenteser |
| `navnliste apend("Ola")` | `navnliste.append("Ola")` – prikken må være med |
| `self-_pa = False` | `self._pa = False` – understrek, ikke bindestrek |
| `return self._pa = True` | `self._pa = True` – verdien lagres, trengs ikke returneres |
| `def tenn():` i en klasse | `def tenn(self):` – metoder må ha `self` |
| `lyst = lyspaere()` | `lyst = Lyspaere()` – klassenavn med stor bokstav |
| `lyst.tenn(lyst)` | `lyst.tenn()` – `self` fylles inn automatisk |
| `print(lyst)` gir `<Lyspaere object at 0x...>` | Legg til `__str__` i klassen |

---

## 12. Fra lyspærer til studenter: et komplett eksempel

### Behovet

Vi skal lagre og bearbeide informasjon om studenter.

- En student har mange egenskaper. Ulike systemer «ser» studenten på ulike måter: det ene leveringssystemet, det andre eksamenssystemet, det tredje lånekassen.
- Vi må derfor lage en modell av en student som kun omfatter de egenskapene vi trenger – ikke hele virkeligheten.

Hva skal klassen tilby?

- lage nye studentobjekter med 0 poeng ved semesterstart
- øke en students poeng (så mye som vi vil) når en ny innlevering er rettet
- lese (hente ut) antall poeng for en student
- skrive ut en student med navn og poeng

### Første utkast

```python
class Student:
    # Konstruktøren har bare self-parameteren
    # Instansvariabel for poeng (int)
    def __init__(self):
        self.poeng = 0

    # Returnerer antall poeng
    def hent_poeng(self):
        return self.poeng

    # Øker poeng med et antall
    def registrer_poeng(self, antall):
        self.poeng += antall
```

- Hvert objekt av klassen `Student` får sine egne kopier av `poeng`.
- Metodene har tilgang til instansvariabelen i det objektet de kalles på.

### Grensesnitt, innkapsling og utvidelse

Innkapsling er et sentralt begrep i programmering:

- Så lenge grensesnittet (metodene) er stabilt, er det uproblematisk at «det er litt rot» i klassen.
- Innkapsling og et grensesnitt gjør at klassen kan brukes i flere store programmer, og av flere programmerere.
- Én eier utgjør ofte klassen alene. Innkapsling betyr at bare metodene kan brukes utenfra klassen.
- Data som står i klassen, er «ikke offentlige» og brukes bare inne i klassen.

I Python støttes innkapsling med konvensjoner:

- Alle navn som ikke skal synes utenfor klassen, begynner med `_`.
- Gi egne instansvariabler og eventuelle hjelpemetoder navn med understrek.
- I praksis er innkapsling et designvalg – det er opp til oss å følge konvensjonen.

I førsteutkastet skrev vi `self.poeng`. Nå vet vi at poengene er en intern detalj, så vi flytter dem til `self._poeng` og utvider klassen med studentens navn:

```python
class StudentMedNavn:
    def __init__(self, navn):
        self._navn = navn
        self._poeng = 0

    def hent_poeng(self):
        return self._poeng

    def registrer_poeng(self, antall):
        self._poeng += antall

    def skriv_ut(self):
        print(f"{self._navn}: {self._poeng} poeng")
```

- Vi kan fortsatt lage så mange objekter av klassen som vi vil.
- Hvert objekt har sine egne instansvariabler som lagrer poengene til sin student.
- Men hvordan vet vi hvilket objekt som lagrer poengene til hvilken student? Derfor trenger objektet også et navn.

Når vi oppretter et nytt objekt, er det fordi vi har informasjon om en ny student – altså fordi vi vet navnet hennes eller hans.

### Test av klassen

Vi skriver et lite testprogram rett etter klassen, i samme fil:

```python
def test():
    s = StudentMedNavn("Ola")
    assert s.hent_poeng() == 0          # ny student har 0 poeng
    s.registrer_poeng(3)
    s.registrer_poeng(5)
    assert s.hent_poeng() == 8          # 3 + 5 = 8


test()
```

- Klassen skal ha minst én test per metode.
- Ulike testmetoder kan brukes til å avdekke feil, siden objektene «husker» verdiene sine, altså har en tilstand mellom kallene.
- `assert` sørger for at vi tenker ut på forhånd hva vi forventer, og stopper kjøringen dersom forventningen ikke holder.

### Samlinger av objekter

- Av en klasse kan vi lage mange objekter med ulike verdier i instansvariablene, altså ulike tilstander.
- Objektene kan lagres både i lister og i ordbøker, og vi kan iterere over disse med `for`-løkker som vi har sett før.

```python
from studentmednavn import StudentMedNavn

studenter = []
studenter.append(StudentMedNavn("Ola"))
studenter.append(StudentMedNavn("Dole"))
studenter.append(StudentMedNavn("Ooffen"))

studenter[0].registrer_poeng(3)
studenter[0].registrer_poeng(5)         # Ole:  8 poeng
studenter[1].registrer_poeng(12)        # Dole: 12 poeng
studenter[2].registrer_poeng(5)
studenter[2].registrer_poeng(6)
studenter[2].registrer_poeng(9)         # Ooffen: 20 poeng

print("Studenter med nok poeng (fra liste):")
for student in studenter:
    if student.hent_poeng() >= 19:
        student.skriv_ut()              # skriver ut bare Ooffen
```

### Organisering av kode

- I innleveringene fremover skal dere levere hver klasse i en egen fil – altså ett Python-modul per klasse.
- Filen skal ha samme navn som klassen, men med små bokstaver og endelsen `.py`. Klassen `StudentMedNavn` ligger altså i `studentmednavn.py`, og hentes med `from studentmednavn import StudentMedNavn`.

---

## 13. Kort oppsummering

- Objekt = data + funksjoner som hører sammen.
- **Grensesnitt** = metodene resten av programmet bruker.
- **Innkapsling** = detaljene om dataene er skjult.
- En **klasse** bestemmer hvilke metoder (tjenester) objektene tilbyr, og hvilke data de har.
- Et **objekt** er en konkret instans av en klasse, med sine egne dataverdier.
- Oppretting: `Klassenavn()`. Bruk av metoder: `objekt.metode()`.
- Metoder må ha `self` som første parameter – den peker på objektet metoden ble kalt på.
- `__init__` kalles automatisk når objektet lages, og setter opp objektets data.
- Bruk `_` foran attributtnavn på data som er ment som interne.
- Tester klassene med `assert`, helst én test per metode.

---

## 14. Selvtest

1. Hva er forskjellen på en klasse og et objekt?
2. Hva betyr `self` i en metode, og hva skjer hvis vi glemmer det?
3. Hvorfor skriver vi `self._pa` og ikke `self.pa`?
4. Hva skjer hvis vi lager et objekt av en klasse som ikke har en `__init__`-metode?
5. Hva er forskjellen på et instansattributt og et klasseattributt?
6. Skriv en klasse `Konto` med saldo, og metodene `saldo()`, `innbetaling(beløp)` og `uttak(beløp)`. `uttak` skal nekte uttak hvis beløpet er for stort.
7. Hvorfor bør vi alltid definere `__str__` i en klasse vi lager?
8. Hva har et listeobjekt og en klasse vi lager selv til felles?

---

*Merknad: Eksemplene bruker norske bokstaver i variabel- og metodenavn (`er_pa` → `er_på`). Det er tillatt i Python 3, og det er slik vi gjør det i forelesningene. Noen velger likevel å unngå æ, ø og å i filnavn, særlig når man skriver kommandoer i terminalen.*
