# Uke 2 IN1000

## Presis forståelse av programmering

  - Programmering er problemløsning
  - Bruke variabler for å ta vare på verdier
  - Feilmeldinger
  - Innlesning fra tastatur
  - Beslutninger (if) - avgjøre hvilken kode som kjøres

### Formelle begreper

- **print(2+2)** : uttrykk noe som kan evalueres.
- **Programsetning**: En linje i et pythonprogram.
- **"Hei!"**: String
- **5**: integer
- **5.1**: float

### Boolske uttrykk og verdier

- Grunnleggende operasjoner: < > == != >= <=
- Kan kombinere sannhetsverdier: and, or, not

  - Uttrykk kan naturligvis inneholde ulike variabler.

#### Boolske variabler

- Boolske verdier kan holdes av variabler.
- En boolsk variabel kan brukes alle steder hvor man kan bruke en boolsk verdi

### Evaluering av funksjoner

- En viktig del av programmering (som vi kommer mer tilbake til senere) er funksjoner
- Kan være biblioteksfunksjoner

#### Hva gjør input

- Input fryster programmet imens brukeren skal skrive et svar, det vil si at alt stopper opp og venter til brukeren skriver noe.

#### Bruk av funksjonsevaluering til en verdi

> tall = int("1" + "3") ---> 13 (tallet)

> Man kan også skrive: tall = int(input())

#### Prinsippene for evaluering av en programsetning

- Man begynner alltid inni og beveger seg utover
  - 18 + ((3+2)*2)
  - int(input())

### Hva som skjer mellom linjer

- Kodeflyt med beslutninger
  - (if else)
  - elif
