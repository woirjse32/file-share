# Trygg infrasturkur og sikre datasystemer

## oppsett.

- nettverkssitkerher
- komijasjonsksikkerhet
- datasikkere
- systemsikkerhet
- buffer utnyttelser
- digiatele vediskjerder

### angreps verktorer:

- direkte angrep mot sårbare syteemr og applicaksoner
- suprigung av abvlitting
- trafidksm ot nettdteder slik at ligim trakfikk blokeres.

### nettverks siskkehret.

> handler om å besktive g ostyrkre tilboklingen / traffiken over nett.

- hvordan overføres data på en trygg måte:
> med overføring menver vi pakker sent i nettverk og, f.eks. fysik leveling av en USB pinne med data.

### Hva er vanlige trusler mot nettverkstrafikk i:
  - 1  tråløsde nett
  - 2 kablede nett.

#### Kommukasjonssikkeret

- komiajsons i trpeøsie nett går via tadiosingaler:  - hvem skal helt sokan klytte til signalense
- siganflrotutieke l(vis det er maksse samtidig traffikk kan det skje intefrerens)
- førte avkantleiren en treåløs enhet vil kodle seg til aksremed sigandl sigel
- komprejeise aksespunker spaietl påne netverkspnkter

- komaksjons i k aeleie nentt går iv fysitke kabler
- anything hvor tftugjg ned e jujesin fykk ykug
- ødelig kalebel
- komaksjoetig nettverks endepinkter
- kommprirg enheter på amme fysike nettverk.

### kryting sikkehrt i lagene

- sikrenettverksprotpkoler
  - transport kayer secturtty tls tilbyr torkeing for ente til ende appliasoner
  - ipsec kryotograf på ip pakker
- vpn baset å tls eller ipsec kombler to subnett sammen så det fungere som et LANs selv om de fiutske advsekilt.
- wifi protected acesss )(apa) ktrtying på strøse nettverk kryterier forbindleemn mellom deg og aksesspiunkt/ruter.


### botnett
> DDoS
> Sender mye nettverkstrafik og bruker veier for å få tjeneren til å bruke mer tid en normalt itl å svare på forespørseller.

### hvordan beskytte et datanett?

- perimertsikkeht:

  - brannmur:
    - skejkkpinkt so slipper inn eller avvise trakkfikk inn spriker ut fea et nettverk basert på forholdesfitnee regelett.
    - bannmur fugnerer som en ilgangskontroll for nettverks-
    - kan vøre et sataprogram eller maskingvare lagt for akkurat dette formålet.
  - inntegrerinsdetkejson
    - oversnettverk og brues ba til å deletrike 
      - mistbrueker itrafikk: bde forøk på suskessfulle
     forhold
     - datvirus og anen ordiernign rgmavar
     - trjentesteteprip.

## Systemsikkrhet.
> Systemer innholder applicasitoner og nettverk.

- transisjonell sikkhetsmodell:
stoler på emdeuste,eme mettverkset anses upplititlig.

- programvare

-applsakonsprogravare
- systemprogrammvasre
(aplisasksonsyskkerhet og sytemsykkhet)

### systemsikkrhet og programvare

- hva er programvare:
  > endesystem:
    - til denne endesystemen har vi koblelet mus, tastatur, kablednettverk, minne, osv. 

### sikkhethet i opritativssytemer

- os syterer like brukes tilgang til ressueeer (prinsispp om minste rivtluguim)
- kerjenren i optetvitstyemtet styrer alt.
- kjerneen kommuniserer med perfiirkashetete i datsmaksinen gjennom direive
brukere proseen komuakserer via kejerneen for å kunene betntte prerifentlehtene.
- minnet i en datamskej beentyettes bla til mellomlagring


> hva betyer dette for sikkherhetet i programvare: 

- en byuffer er en sammhendgnee skejsjon i minniet i datamaksjenen, avsatt til å innholde data.

### kan denne brukes krativt?

- ja gjensom å køade såøre bae progammer kan man ksrive uthemmet itl minnit et idatameiner 

## endre minnet:

  - openssl er en åoenkolde og er et or er et bilogoktek kodet i c som impreserer proktoleen tls
  -- bruesi  mioener av apsliajsoner oprterivt lot enheter og severere.

