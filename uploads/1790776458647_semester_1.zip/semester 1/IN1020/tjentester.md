# Tjenester på Internett

Notater om hvordan tjenester på Internett er bygd opp: transportlaget og applikasjonslaget, hvilke tilgangsmodeller som finnes, hvordan innhold distribueres, og hvordan DNS og HTTPS fungerer.

## Innhold

- [Transportlaget](#transportlaget)
  - [TCP: egenskaper](#tcp-egenskaper)
  - [Mettingskontroll](#mettingskontroll)
  - [TCP og deling av ressurser](#tcp-og-deling-av-ressurser)
- [Applikasjonslaget](#applikasjonslaget)
  - [Tilgangsmodeller](#tilgangsmodeller)
  - [Forbindelsesstadier](#forbindelsesstadier)
  - [Distribusjonsformer for tjenester](#distribusjonsformer-for-tjenester)
  - [Strømming av video: MPEG-DASH](#strømming-av-video-mpeg-dash)
  - [Distribusjon av innhold med CDN](#distribusjon-av-innhold-med-cdn)
  - [Proxy og cache](#proxy-og-cache)
  - [Peer to peer (P2P)](#peer-to-peer-p2p)
  - [Napster: eksempel på P2P](#napster-eksempel-på-p2p)
- [Protokoller: DNS og HTTPS](#protokoller-dns-og-https)
  - [DNS: Domain Name System](#dns-domain-name-system)
  - [DNS og sikkerhet](#dns-og-sikkerhet)
  - [HTTPS](#https)
  - [Persistens: persistente og ikke-persistente protokoller](#persistens-persistente-og-ikke-persistente-protokoller)
  - [Sikkerhet: HTTP og HTTPS](#sikkerhet-http-og-https)
- [Internet of Things (IoT)](#internet-of-things-iot)
- [Begreper å kunne forklare](#begreper-å-kunne-forklare)

---

## Transportlaget

### TCP: egenskaper

**Transmission Control Protocol (TCP)** er en forbindelsesorientert protokoll.

- **Treveis håndtrykk:** Forbindelsen settes opp med SYN → SYN-ACK → ACK.
- **Flytkontroll:** Sender ikke mer data til mottakeren enn den kan ta imot.
- **Overbelastningskontroll (congestion control):** Tilpasser sendehastigheten etter hvor full nettverksveien er.
- **Strømlevering i rekkefølge:** Data leveres i den rekkefølgen de ble sendt i.
- **Pålitelighet:** Implementert ved at mottakeren sender bekreftelser (ACK) på hver pakke den mottar.
- **Feilsjekking:** En sjekksum verifiserer at dataene ikke har blitt skadet under transporten.

Tilstandene i en TCP-forbindelse er listet under [Forbindelsesstadier](#forbindelsesstadier).

### Mettingskontroll

- En ruter er i utgangspunktet bare en FIFO-kø (*first in, first out*).

### TCP og deling av ressurser

- TCP deler ressursene (båndbredden) mellom tilkoblingene.

---

## Applikasjonslaget

Applikasjonslaget inneholder blant annet:

- **DNS** (Domain Name System) – se [DNS](#dns-domain-name-system)
- **World Wide Web (WWW)** og **HTTPS-protokollen** – se [HTTPS](#https)
- **Strømming av video** – se [MPEG-DASH](#strømming-av-video-mpeg-dash)
- **Internet of Things (IoT)** – se [IoT](#internet-of-things-iot)

### Tilgangsmodeller

Tilgangsmodellen avgjør hvem som kan bruke en tjeneste, og hvem som kontrollerer den.

#### Klient–tjener

- Klienten ber om en tjeneste, ofte på forespørsel fra en sluttbruker.
- Tjeneren utfører tjenesten og leverer et svar tilbake.
- I en *transparent klient–tjener-modell* skjules detaljene bak en abstraksjon, slik at klienten ikke trenger å kjenne til implementasjonen.

#### Peer to peer (P2P)

- Brukes blant annet lokalt, i lokale nettverk, der man slipper å være avhengig av kjernetjener.
- Problemer: blant annet pålitelighet.

### Forbindelsesstadier

En TCP-forbindelse går gjennom følgende stadier:

```
CLOSED → LISTEN → SYN-SENT → SYN-RECEIVED → ESTABLISHED
       → FIN-WAIT-1 → CLOSE-WAIT → FIN-WAIT-2 → LAST-ACK → TIME-WAIT → CLOSED
```

### Distribusjonsformer for tjenester

#### Pull

- Klienten ber tjeneren om én bestemt tjeneste.
- Tjeneren leverer den mest mulig relevante informasjonen.

#### Push

- Tjeneren dytter en tjeneste, for eksempel en beskjed, til klienten.
- Tjeneren sørger for at data er bufret fra før, eller at data blir levert til en klient som var avkoblet da de ble sendt.

#### Publish/subscribe

- En variant av push der tjeneren dytter ut beskeder til en gruppe abonnenter.

### Strømming av video: MPEG-DASH

**MPEG-DASH (Dynamic Adaptive Streaming over HTTP)** er en standard for adaptiv strømming av video over HTTP.

Videoen deles i små segmenter i stedet for å leveres som én stor fil. Spilleren kan da velge mellom flere forhåndslagrede varianter:

- **Segmentering:** hvor fintinndelt videoen skal deles (for eksempel segmenter på 1–2+ sekunder).
- **Antall kvalitetslag:** hvor mange alternative kvalitetsnivåer som tilbys.
- **Tilpasningsstrategi:** hvordan spilleren velger kvalitet under avspillingen.

Dette gir adaptiv bitrate:

- Valgene tas av klienten (spilleren), ikke av tjeneren.
- Buffering i spilleren er det som skaper forsinkelsen.

### Distribusjon av innhold med CDN

**Content Delivery Network (CDN)** er hierarkiske systemer for å distribuere innhold.

- Cacher populært innhold.
  - Populære videoer blir lagret på nærmeste sluttbruker.
  - Videoer som ikke er så populære, lagres lenger unna: enten på edge-serveren eller nærmere kjerneserveren.
- Særlig viktig når båndbredden er begrenset, for eksempel Wi-Fi på fly.

### Proxy og cache

- En **forward proxy** står nær klienten.
- En **reverse proxy** står nær tjeneren.
- Dette gir lastbalansering, sparer nettverkspakker og reduserer forsinkelse.

### Peer to peer (P2P)

P2P ligner på CDN på flere måter:

- En node kan være både klient og tjener.
- Dittig og enkel distribusjon av innhold.
- Innhold havner nærmere brukeren.

#### Topologier: ren P2P og hybrid P2P

**Ren P2P**

- Alle nodene er likeverdige.

**Hybrid P2P**

- Noen sentrale noder har en særskilt rolle:
  - sentrale tjenere, eller
  - *superpeers*.
- Superpeers velges ofte fordi de:
  - ikke ligger bak brannmur og/eller NAT,
  - har mye av en ressurs, for eksempel båndbredde, harddiskplass, CPU og regnekraft.
- Slike løsninger kan hjelpe til med for eksempel å redusere forsinkelsene i en P2P-løsning.

#### Styrker

- Ideelt for å dele ressurser mellom enheter (peers).
- Ressurser som kan deles, kan være:
  - CPU
  - lagring (harddiskplass)
  - nettverksbåndbredde
  - eller nesten hva som helst
- Tilgang til andres ressurser og programmer.
- Robust mot endringer i nettverket av peers.

#### Svakheter

- Egner seg dårlig til applikasjoner som er avhengige av lav forsinkelse, for eksempel online spill med strenge tidskrav.
- Er avhengig av en viss grad av sentral kontroll. I praksis brukes derfor gjerne noe sentralisering – noe tas «ut av sekken».
- Peers kommer og går: mye nedbrudd og reaksjoner krever håndtering av konsistens.
- Kan være vanskelig å effektivt indeksere og finne igjen elementer.

### Napster: eksempel på P2P

- Program for deling av musikkfiler over Internett, lansert i 1999.
- Arkitektur:
  - Sentral indeksering.
  - Distribuering, lagring og nedlasting.
  - Alle filer som lastes ned, blir delt.
- I dette P2P-eksemplet var endesystemene (klientene) også filtjener.

---

## Protokoller: DNS og HTTPS

### DNS: Domain Name System

- Kjører i protokolllaget.
- Er oppløsning for å finne en IP-adresse: enklere å huske et navn enn en IP-adresse.

### DNS og sikkerhet

- DNS-navneoppslag knytter sammen navn til IP-adresser. Kommunikasjonen foregår i klartekst.
- **Farer:**
  - *DNS-forfalskning:* en angriper injiserer uriktige opplysninger i navnetjeneren.
  - *DNS-modifisering:* en man-in-the-middle angriper og forfalsker meldinger.
  - *DNS-kaping:* en angriper endrer hvilke navnetjenerer offerets maskin benytter.
- **Tiltak:**
  - *DNSSEC (Secure Domain Name System):* signerer DNS-informasjon basert på asymmetrisk kryptering og egen PKI.
  - Navnetjenerne må sikres godt.
  - Nettleseren setter et hengelåssymbol på websider, noe som bekrefter autentisitet.

### HTTPS

**HTTPS (Secure Hypertext Transfer Protocol)** er en applikasjonsprotokoll for web, basert på klient–tjener-modellen:

- En nettleser (HTTPS-klient) ber om en nettside og får den vist.
- Tjeneren sender webobjekter som svar på forespørselen.

**Versjonshistorikk:**

| Versjon | År |
| --- | --- |
| HTTP/1.0 | 1996 |
| HTTP/1.1 | 1999 |
| HTTP/2 | 2015 |
| HTTP/3 | 2018 |

#### HTTPS-protokollen

- Bruker TCP for transport.
- Klienten oppretter en TCP-forbindelse (*socket*) til tjeneren på port 80.
- Tjeneren godtar TCP-forbindelser fra klienten.
- HTTP er en protokoll på applikasjonslaget, og utveksler data mellom HTTPS-klienten (nettleseren) og HTTP-tjeneren (webtjeneren).
- TCP-forbindelsen lukkes når utvekslingen er ferdig.
- HTTPS er *stateless*: tjeneren oppbevarer ingen tilstandsinformasjon om tidligere forespørsler.
- Protokoller som baserer seg på tilstand, er komplekse:
  - Tilstanden må vedlikeholdes.
  - Hvis en tjener eller en klient krasjer, kan tilstanden bli ulik mellom dem, og da må den gjenopprettes.

### Persistens: persistente og ikke-persistente protokoller

- **Ikke-persistente protokoller:**
  - HTTP/1.0: tjeneren leser forespørselen, svarer og lukker TCP-forbindelsen.
  - Det kreves to runder for å hente ett objekt: én for TCP-forbindelsen og én for forespørselen og overføringen.
  - Hver overføring lider av TCP sin gradvise økning i sendehastighet (*slow start*).
  - Mange nettlesere støtter flere parallelle protokoller som løsning på dette.

### Sikkerhet: HTTP og HTTPS

HTTPS har to hovedmål:

- **Konfidensialitet og integritet:** kryptere kommunikasjonen mellom klient og tjener.
- **Autentisitet:** sikre tillit til at webtjeneren faktisk er autoritativ.

I tillegg:

- Støtter både HTTP og bruker SSL/TLS.
- Bruker en offentlig nøkkelinfrastruktur (PKI) med offentlige nøkler og sertifikater.

---

## Internet of Things (IoT)

Enheter i daglig bruk i husholdninger og på arbeidsplasser som leverer ekstra tjenester ved hjelp av Internett.

- Kan bidra til å redusere energiforbruket, for eksempel gjennom:
  - automatiske husholdningsmaskiner,
  - helseapplikasjoner,
  - smarthus,
  - logistikk.
- Snakker med en tjener i skyen.
- Leverer data som brukes til å analysere dataene.

---

## Begreper å kunne forklare

| Begrep | Forklaring |
| --- | --- |
| TCP | Transmission Control Protocol: forbindelsesorientert, pålitelig protokoll på transportlaget. |
| Tredjeveis håndtrykk | SYN → SYN-ACK → ACK: oppsett av en TCP-forbindelse. |
| Slow start | TCP øker sendehastigheten gradvis i starten av en forbindelse. |
| Mettingskontroll | Håndtering av overbelastning i nettverket. |
| DNS | Domain Name System: oversetter navn (for eksempel `ntnu.no`) til IP-adresser. |
| DNSSEC | Signerer DNS-informasjon med asymmetrisk kryptering for å avsløre forfalskning. |
| PKI | Public Key Infrastructure: offentlige nøkler og sertifikater som bekrefter identitet. |
| HTTP | Hypertext Transfer Protocol: applikasjonsprotokoll for web. |
| HTTPS | HTTP kryptert med SSL/TLS. |
| Stateless | Protokoll som ikke lagrer tilstand fra tidligere forespørsler. |
| Socket | Endepunktsadresse for en forbindelse mellom klient og tjener. |
| MPEG-DASH | Dynamic Adaptive Streaming over HTTP: standard for adaptiv videostrømming. |
| Adaptiv bitrate | Spilleren velger kvalitetsnivå under avspilling basert på tilgjengelig båndbredde. |
| Kvalitetslag | Ett alternativt kvalitetsnivå (oppløsning/bitrate) i en strømmet video. |
| Strømming av video | Video overføres og spilles av mens den kommer, i stedet for å lastes ned helt først. |
| IoT | Internet of Things: fysiske enheter koblet til Internett som utveksler data. |
| CDN | Content Delivery Network: nettverk av servere som leverer innhold fra en server nær brukeren. |
| Edge-server | En server i CDN-et som ligger nær sluttbrukerne. |
| Cache | En mellomlagret kopi av innhold, slik at det kan leveres raskere uten å hentes fra kilden. |
| Forward proxy | Mellomtjener på klientsiden av kommunikasjonen. |
| Reverse proxy | Mellomtjener på tjenersiden av kommunikasjonen. |
| Pull | Klienten henter data fra tjeneren når den vil ha det. |
| Push | Tjeneren sender data aktivt til klienten. |
| Publish/subscribe | Abonnenter melder seg på et emne og mottar beskeder automatisk. |
| P2P | Peer to peer: nodene er både klienter og tjenere for hverandre. |
| Superpeer | En sentral node i en hybrid P2P-topologi. |
| NAT | Network Address Translation: skjuler private IP-adresser bak en offentlig. |
