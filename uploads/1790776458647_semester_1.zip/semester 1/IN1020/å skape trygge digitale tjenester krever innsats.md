# Å skape trygge digitale tjenester krever innsats

## Oppsett

- Hvorfor er datasikkerhet så viktig?
- Å innfri sikkerhetsmål, autentisitet og sikre tilganger

## Nøkkelord

- Lovpålagte krav
- Trusselmodellering og risikoanalyse
- Systematikk og kontinuitet
- Administrative sikkerhetstiltak
- Hva skjedde i Lørenskog kommune?

### Lovverket setter en del krav for hva som skal gjøres

#### Innebygd personvern (GDPR)

- Sørge for at programvareutviklere vi bruker oppfyller personvernprinsippene
- Ta hensyn til personvern i alle utviklingsfaser av et system eller en IT-løsning
- Det minst personverninngripende alternativet skal være standard i alle systemer og løsninger:
  - mengden av personopplysninger
  - omfanget av behandlingen
  - lagringstid
  - tilgjengelighet kun for berettigede personer

#### Sikkerhet ved behandling (GDPR)

- Ivareta informasjonssikkerhet gjennom hele behandlingsprosessen
- Gjennomføre egnede tekniske og organisatoriske tiltak for å oppnå et sikkerhetsnivå som er passende med hensyn til risikoen

### Innebygd informasjonssikkerhet og personvern

- Opplæring: kunnskap om informasjonssikkerhet, personvernopplæring, taushetsplikt og risikovurdering
- Krav: interne og eksterne krav til sikkerhet; spesifiserer behandling av persondata
- Design: trusselmodellering og risikovurdering; design av sikkerhet minimerer sårbarheter og innhenting av persondata
- Koding: vurdere trusler, unngå sikkerhetsbrudd i kode; sjekk for sårbarheter i standard komponenter og byggverktøy
- Test: verifiserer at trusler håndteres og sårbarheter er fjernet gjennom statisk og dynamisk testing
- Produktsetting: plan for hendelseshåndtering, varsling av hendelser og vedlikehold av programvare
- Forvaltning: vedlikehold av programvare, fjerning av sårbarheter, håndtering og varsling av hendelser og beredskapsøvelser

### Hva med annen type informasjon?

- Generelt finner man få lovpålagte krav til informasjonssikkerhet, men noen finner man i lovverket rettet mot spesifikke bransjer og forvaltningsorganer:
  - sikkerhetsloven
  - digital sikkerhetsloven
  - forskrift om IT-standardisering i offentlig forvaltning
  - e-forvaltningsforskriften
  - lov om elektronisk kommunikasjon

## Sikkerhetsstyring

### Dagens trusselbilde

- Bakteppe:
  - Stormaktrivalisering
  - Forholdet mellom USA og Europa er i endring
  - Krig og konflikt rammer flere kontinenter
  - Norges rolle som forsvarsleverandør til Ukraina
  - Kinesisk kontroll i verdikjeder
  - Rask teknologisk utvikling
  - Konsentrasjonsrisiko
- Trender:
  - Innsidervirksomhet
  ...

### Behov for systematikk og rammeverk

- Rammeverk for informasjonssikkerhet:
  - NSMs grunnprinsipper for informasjonssikkerhet er tilpasset norske forhold.

### Behov for systematisk styring

- Sikkerhetsstyring er systematiske aktiviteter for å oppnå og opprettholde et sikkerhetsnivå i overensstemmelse med de mål og krav en organisasjon har satt seg.
- Informasjonssikkerhet må inkluderes i virkeligheten
- Eksempler: NSMs styringshjul

## Å innføre tiltak og risiko i et system

- Ønsker oss:
  - Tidlig innsats: forebygge og håndtere sikkerhetsproblemer tidlig
  - Bedre forståelse: gjøre gode risikovurderinger
  - Tiltak som fungerer: effektiv sikkerhetsstyring

### Risiko

- Verdier
- Sårbarheter
- Trusler

### Trusselmodellering

- Trusselmodellering består i å identifisere og beskrive relevante angrepsscenarier og ulike innfallsvinkler:
  - Fokus på trusler og trusselaktører
    - Identifisere trusselens mål, hvordan de går frem for å oppnå dem, hva er angrepsvektorer og angrepsstrategier
  - Fokus på sårbarheter
    - Plukke systemene fra hverandre, identifisere de svake delene og avdekke hvor og hvordan de kan angripes
  - Fokus på verdier
    - Identifisere verdier i systemet, avdekke hvordan finansielle hendelser kan inntreffe

## Risikoidentifisering

- Å identifisere en risiko betyr å finne en relevant kombinasjon av en trussel, sårbarhet og hendelser som kan skade verdier

## Risikoanalyse

- Risikoanalyse involverer en konsekvensvurdering
- Praktisk risikoanalyse veier vanligvis to faktorer for å bestemme nivået på hver risiko:
  - Sannsynlighet: sannsynligheten for at en gitt type hendelse inntreffer
  - Konsekvens: hvordan verdier påvirkes som følge av hver type hendelse
- Hvor skal innsatsen legges?
  - Usannsynlige hendelser som medfører store tap?
  - Sannsynlige hendelser som har lavere kostnad?

> Man ender opp med et slags regneark som analyse som viser alle hendelsene man må jobbe mot.

## Risikovurdering og risikohåndtering – hvem gjør hva?

### Ledelse, eiere, brukere og fageksperter må samarbeide

- Eierne av verdier må hjelpe til med å:
  - lage oversikter over verdier og spesifisere sikkerhetsmålsetninger
  - vurdere konsekvensen av brudd på sikkerhetsmål

## Lørenskog kommune

- Utsatt for datainnbrudd våren 2026
- Resultat:
  - nedetid for kommunens IT-tjenester
  - virksomhetsdriften

### Angrepsvektor

- SEO poisoning (også kalt search poisoning)

## Administrativ datasikkerhet

### God informasjonssikkerhet koster

- Budsjetter og ressurser til:
  - kompetanse og bevissthet
  - styring og kontroll
  - drift og vedlikehold
  - sikkerhetstiltak