# Bevissthet

## Plan (fulltekst underveis)

### Bevissthetsfilosofi (filosofi om sinnet)

> Det vanskeligste spørsmålet er forholdet mellom kropp og sinn.

- Hva er sinnet?
- Hva er forholdet mellom kropp og sinn?
- Er mentale tilstander en del av kroppen vår?
- Er sinnet noe fysisk?
- Hvordan kan kropp og sinn påvirke hverandre?

> **Eksempel:** En person som har flere egenskaper. Hun har fysiske egenskaper (hårfarge, høyde, hudfarge osv.), og så har hun fysiske egenskaper ved hjernen (synapser som fyrer).

**Mentale egenskaper:**

- tanker
- følelser
- opplevelser
- ...

> **Spørsmål:**
> - Er mentale egenskaper noe annet enn fysiske egenskaper?
> - Kan mentale egenskaper reduseres til fysiske egenskaper?

#### Grunner til å tro at mentale egenskaper ikke er identiske med fysiske egenskaper

**Absurde spørsmål:**

- Hvilken farge har oppfatningen min av at jorden er rund?
- Hvilken form har ønsket mitt om å klappe katten min?
- Hvor mye veier opplevelsen av å sitte og høre på en forelesning om bevissthetsfilosofi?

**Tilgjengeligheten av kunnskapen:**

- Kunnskap om fysiske fakta er i prinsippet tilgjengelig for alle, det er offentlig.
- Kunnskap om mitt mentale liv er privat.

> **Eksempel – Phineas Gage:**
> Han fikk en metallstang rett gjennom hodet. Når man ser på før og etter, endret personligheten hans seg (frontallappen).

#### Metafysiske spørsmål

> Filosofiske spørsmål:

- Handler om hva som eksisterer og på hvilken måte noe eksisterer.
  - Er sinnet en abstraksjon?
  - Er sinnet mentalt, irreducerbart og ikke-fysisk?
- Er mentale egenskaper identiske med fysiske egenskaper?
  - **Nei:** Egenskapsdualisme (ikke identiske)
  - **Ja:** Egenskapsmaterialisme (identiske)

- Finnes det mentale substanser som er noe annet enn fysiske substanser?

#### Substans og egenskaper

**Substans:**

- Det objektet eller tingen
- Noe som kan ha egenskaper

**Egenskaper:**

- Noe som kan tilskrives en substans

**Spørsmål:**

- Er det bare fysiske egenskaper som finnes, eller finnes det mentale substanser i tillegg til fysiske substanser?

**Egenskapsrelasjonisme, egenskapsdualisme, substansmaterialisme, substansdualisme**

### Substansdualisme

> Ikke et kjent syn i dag, men likevel har det viktig historisk relevans.

- Det mentale er en egen substans.
- Mental substans ≠ fysisk substans.
- Noen ganger kalt «kartesiansk dualisme» (etter Descartes).

## Descartes' syn på kropp og sinn

- Det finnes to typer substanser:
  - Det som har utstrekning (res extensa)
  - Det som tenker (res cogitans)

### Res cogitans vs. res extensa

| Egenskap | Res cogitans | Res extensa |
|---|---|---|
| Type | Den mentale substansen | Den fysiske substansen |
| Kjennetegn | Vesentlig tenkning | Vesentlig utstrekning |
| Mangler | Utstrekning | Tenkning |
| Frihet | Enkel (sinnet), fri – ikke underlagt mekaniske prinsipper | Underlagt mekaniske prinsipper |

### Descartes' forståelse av naturen

- Det kartesiske verdensbildet.
- Den fysiske verden fungerer som en egen avansert mekanisk maskin.
- Endring og bevegelse skjer utelukkende som et resultat av bevegelse og interaksjon mellom materielle substanser.
  - Universet bestod utelukkende av materie og bevegelse.

### Descartes' forståelse av dyr

- Sofistikerte mekaniske maskiner.
  - All bevegelse er et resultat av maskinens operasjoner.
- Dyr mangler et sinn.

> Han mener at mennesket skiller seg fra andre dyr fordi vi har en «sjel» – noe bare mennesket har.

### Spørsmål

- Hvorfor mente Descartes at sinnet og kroppen ikke er identiske?
- Hvilke grunner hadde han for å mene det?
- Hva betyr det at noe er identisk?
  - Numerisk identitet

#### Leibniz' lov om identitet

- Dersom a og b er identiske, har a og b alle egenskaper som hverandre.
- Følgelig: dersom a og b ikke deler alle egenskaper, er a og b ikke identiske.


##### Forholdet mellom fkropp og sinn

- Hvis sinnet mitt er irentisk med kroppen min mp jroopp og sin dee alle egsnakoer
- der som sinnet mie r har enejaer som hejermeikr lager ogis ver er ikke siane dientisme emd kroppen

##### Arguemnt for at skejrlen ikk  eer itdentk med kroppen

table:
¨premiss 1: Jeg kan kalr og tydeig forsktelleme med at at jeg esktisterer uten at kroppen og hjernen min eksitster.
premiss 2: Gud eksister og øsnker ikke å vilede meg, slik at det jeg kna forstile med klart og tydelig må være en reell mulighet.
konklusjon: Jeg kna eksitstere uten at kroppen og gjerenen min eksisterer.
premiss 3: kroppen og gjerneen men kunne ikke eksister dersom kroppen og herneen min ikke hadde eskistert.
konklsujson 2: Jeg er ikke identisk med kroppen oghjernen min.

> resultatet av dette er det subsatnasudlaisme.

### Elisabeth avbohmens innveding.

- 1618-1980
- filosof og prinsesse av bohmen
- utganspunketer for brevvekslingen er meditasjonene 1641

##### brev 1.

- 6 mai 1643


### Problemmet med mental kausaltiet:

- kausalitet forholet mellom årsak og vitkig.
- dersom det mentale og det mentiaite er to fundemental like subsatnder på det mapten descares brjekr hvorkan det mentale ha asual påvirkig på det fysiske?
  - hvodan kan det mentale ha prslritp på det fysirkee.

#### Kaysal lunking av dden fywskirke verden_

- en hver fysitker hendelriehr ehr en fysktif orklairng
- enhver fyrskig virkig ahar en tilstrkkelig fysktig årsak.

##### Elisabeths arguemtn

- samt kan påvirke kroppen kausalt
- kasual pråvrikig på kroppen krever fysysk kontakt
- fysisk kontakt er bare mulig mellom matielre ojenter (fysikiske objekter)
- sinnet er ikke et makriskes objetk (devare dualisme)
- sainnet kan ikke påvikre kroppen kauusauøt (fra 2-4)
- dette føerer til en selvelringe 1 ksinnet kan pårvike kraulatl sinnet kan ikke påvikre krippen kauslat

- konkulasjon: enten sinneet ike privke kroppen kausalt eller deauclise er feil.

##### Epifenomenaisme

- kroppen kan påvikre sinnet kausalt men sinnet kan ikke prvikre kroppen kausalt.


##### brev 2:
tre ulike diet
- kropp: iden om utsterkeling
- skjelen idden om tekning
- sjelen og kroppen eidene dere forkening


David chamers:
the hard problem of concouseness

hvodan kan fystike processer i hjernene være opphva til emtiake eneignaker
hvordan kfystikerpe orcesser vøre oppgavet til sujeektitve opplevelser?

forsklag: papsykisme
 betuvet er funament egwnake med alle fytiekre ethiteter

 