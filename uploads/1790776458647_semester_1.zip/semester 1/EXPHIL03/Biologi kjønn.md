# Biologisk kjønn, sosialt kjønn og den sosiale konstruksjonen av virkeligheten

## Oppsett

- Del 1: ulike sosiale konstruksjoner av biologisk kjønn
- Del 2: skille mellom tre typer sosial konstruksjon
- Del 3: forskjeller mellom sosiale konstruksjoner og sannhet og virkelighet

## Sally Haslanger: sosial konstruksjon

### Haslangers tekst – «Sosial konstruksjon: kjønn og andre sosiale kategorier»

I teksten forsøker Haslanger å forklare en rekke ulike ting:

- Å forklare hva det innebærer å si at noe er sosialt konstruert
- Å skille mellom tre ulike måter noe kan være sosialt konstruert på
- Å skille mellom «biologisk kjønn» og «sosialt kjønn»
- Å vise at både biologisk og sosialt kjønn er sosiale konstruksjoner

## Biologisk kjønn

- Hva avgjør ditt biologiske kjønn?
- Hva avgjør hva som avgjør det biologiske kjønnet?
- Skal den egenskapen vi velger, spille en rolle for ulike sosiale konsekvenser?

### Haslanger: «biologisk kjønn» som sosial konstruksjon

- Hva skal til for at en person regnes som f.eks. en «biologisk kvinne», og hvorfor skal én av disse egenskapene være den avgjørende?
- Kan vi snakke om flere enn to biologiske kjønn?
- Dette er til syvende og sist et sosialt valg om hvordan vi vil bruke begrepene.
- Vitenskapen kan undersøke hvilke biologiske egenskaper som finnes, men den kan ikke alene avgjøre hvilken egenskap som skal telle som kjønn. Det valget er sosialt.

#### Genealogi

- Genealogiske undersøkelser (undersøkelser om hvordan noe ble til) er ofte verktøy for å avdekke en sosial konstruksjon.
- Begrepsdomener, klassifikasjoner og deskriptive egenskaper formes ofte med utgangspunkt i interessene til dominante sosiale grupper.
- Hva skal vi regne med når vi bruker begrepene?
- Hvem er vi?

## Første type sosial konstruksjon: konstruksjon av ideer og begreper

- «Å si at vårt begrep om X er sosialt konstruert, kan være mer enn å hevde at vi utviklet det gjennom en sosial og historisk prosess. Det legger også vekt på at måten vi deler verden inn på, bærer preg av sosiale forhold.»

- Hva er begreper?
  - Kognitive redskaper som
    - hjelper oss å organisere fenomener
    - grupperer gjenstander eller ideer (frukt og grønnsaker, biler, sykler osv.)
    - framhever det en gruppe har til felles og skiller det som gjør dem forskjellige

- Dette gjør at vi kan spørre: hvordan kan vi best utforme begreper som fungerer som nyttige redskaper?

## Andre type sosial konstruksjon: objektkonstruksjon

- Selve tingen blir formet av sosiale forhold.
- Objektkonstruksjon er intuitiv i dag.
  - Kroppen blir formet av idéen om kvinner, som igjen forsterker idéen.

> Ideer kan stereotypisere kjønn basert på egenskaper, og dermed definere hvilke egenskaper som til sammen regnes som «kjønnede».

### Tilbakekoblingseffekten

- En tilbakekoblingseffekt er når en person forandres av å bli klassifisert.
  - Å alltid måtte forholde seg til hvem en er som klassifisert, påvirker individets selvforståelse.
- Mennesker responderer på sosiale normer og forventninger og forandrer ofte seg selv for å passe med forventningene til kategorien.

### Simone de Beauvoir

- «Man fødes ikke som kvinne, man blir det.»
- Kjønn er ikke et naturlig faktum, men en historisk idé som blir innprentet i oss.
- I boken *Det annet kjønn* viser hun hvordan ideer og myter om kvinner skaper forventninger til kvinners atferd, som blir selvoppfyllende.
- Å tenke på seg selv som «jeg er en kvinne» blir begrensende for personens frihet, fordi selve idéen om en kvinne er begrensende.

## Tredje type sosial konstruksjon: sosial konstruksjon av slag

- Haslanger hevder det er viktig å forstå konstruksjonen av sosiale slag for å kunne forstå hvordan kategoriene påvirker sosiale konsekvenser.

### Hva er et slag?

- En gruppe eller type ting som identifiseres ut fra et felles kjennetegn som gir dem en bestemt egenskap.

### Naturlige vs. sosiale slag

Filosofer skiller ofte mellom:

- **Naturlige slag:** ting som er det de er i kraft av sine fysiske egenskaper
- **Sosiale slag:** ting som også avhenger av sosiale egenskaper for å være den tingen de er

> Altså: et slag er et sosialt slag dersom det som medlemmene i slaget har til felles, og som gjør dem til medlemmer av slaget, er sosiale egenskaper.

### Sosial konstruksjon av slag: funksjonell variasjon

- Sosialkonstruksjonsteoretikere vil ofte hevde at mange ting som framstår som naturlige slag, egentlig er sosiale slag.
- Hvilke slag vi deler verden inn i, varierer derfor mellom samfunn og over tid.

### Kvinne og mann som sosiale slag

- Å være kvinne er noe mer enn å ha visse kroppslige egenskaper – det er også å innta en viss posisjon eller rolle i samfunnet, der man er underlagt visse normer og forventninger.
- Å være en person med XX-kromosomer og livmor er et naturlig slag, men å være kvinne er ikke det samme som å ha XX-kromosomer og livmor. Det er å inneha en sosial posisjon.

## Sosial konstruksjon, virkelighet og nytte

- At noe er en sosial konstruksjon, betyr ikke at tingen ikke er virkelig.
- Sosiale konstruksjoner er reelle i den forstand at de har konkrete konsekvenser for menneskers liv.

### Sosial konstruksjon og essensialisme

- Sosialkonstruktivismen utfordrer essensialismen, altså idéen om at ting (f.eks. kjønn) har en fast, uforanderlig kjerne uavhengig av sosiale forhold.
- For konstruktivisten finnes ingen «kvinnenatur» som noe gitt; kjønn får sitt innhold gjennom sosiale normer og praksiser.

#### Elimativitsme

- Å være eleimait om et bregp er å mene at et begrept ikke har en funksjon

- f.eks.
  - hekser
  - Hyteri
  - 

- En like eleiemtift emener vi bør beolde begeept eveutll med medføringer.

