# Rom og geometri

## Oppsett

### Immanuel Kant: teoretisk filosofi

Det mest sentrale erkjennelsesteoretiske verket i Kants kritiske filosofi:

- _Kritikk av den rene fornuft_
- _Prolegomena til enhver fremtidig metafysikk som skal kunne opptre som vitenskap_

> Den teoretiske filosofien handler om hvordan man kan erverve kunnskap om den teoretiske verden, mens den praktiske filosofien handler om fri handling og hvordan man skal handle fritt.

#### _Kritikk av den rene fornuft_

- Hans største verk. Kant mente det ble misbrukt, og derfor skrev han det om i 1787 (andre utgave; første utgave kom i 1781).

#### _Prolegomena til enhver fremtidig metafysikk_

> Kants filosofi er svært abstrakt.

- Hva er erfaring (altså empirisk kunnskap)? I naturvitenskapen brukes erfaring for å forklare alt man kan se – og hvordan man tenker seg til det.
- Dette er kunnskap som man kan knytte til erfaring: begreper som har en fast, sikker mening i historien, og som man kan sikre.

### To veier for erfaring til verden

- Sansemottakelighet (sanseintrykk) – vi _mottar_ inntrykk fra verden.
- Forstanden – den _selv bringer fram_ erkjennelse (spontanitet).

Sammen utgjør disse grunnlaget for a priori-kunnskap.

### A priori

#### Termer du bør kunne

- Uavhengig av all erfaring
- Uavhengig av alle sanseintrykk
- Forutsetning for all erfaring

A priori-kunnskap er **ikke medfødt** – den er uavhengig av erfaring, men oppstår likevel i sinnet.

### To kjennemerker ved a priori

- Nødvendighet
- Streng allmenngyldighet

### Syntetiske og analytiske dommer

- **Analytisk dom:** predikatet er skjult i innholdet i subjektet. Dommen sier bare det som allerede ligger i begrepet.
- **Syntetisk dom:** predikatet ligger helt utenfor subjektet og er ikke skjult i det. Dommen tilfører noe nytt.

### Analytiske dommer

Eksempler:

- Alle legemer er utstrakte
- Alle (a + b) er b

1. Predikatet (b) er identisk med det begrepet vi allerede har i subjektet.
2. Dommens nødvendighet er bevist gjennom kontradiksjonsprinsippet.

For å anta det motsatte:

- Det finnes et legeme uten utstrekning
- Det finnes et (a + b) som ikke er b
- → en selvmotsigelse

Ergo er den analytiske dommen nødvendig sann.

### Syntetiske dommer (a posteriori)

> Erfaringsdommer

- Alle legemer er tunge
  - (a + b) er c
- Ingen motsigelse:
  - Det finnes et (a + b) som ikke er c
- Predikatet _tyngde_ legges til subjektsbegrepet _legeme_ (a + b) ved hjelp av erfaringen.
- Forbindelsen er derfor kontingent (tilfeldig), ikke nødvendig og ikke strengt allmenngyldig.

### Syntetiske dommer a priori

- Kants teori er svært knyttet til dette.
- Man kan nesten si at Kants teori faller hvis dette ikke eksisterer.
- Store deler av Kants teori er bevis på at dette finnes.

**Teoretisk fornuft (bruk):**

- Matematiske dommer
- Naturens grunnprinsipper:
  - Alt som skjer har sin årsak.
  - Materiens kvantitet forblir uforandret i alle legemlige forandringer i verden.
  - I all kombinasjon av bevegelse er kraft og motkraft alltid like sterke.

**Praktisk fornuft:**

- Moralens øverste prinsipp: det kategoriske imperativ.

> Disse dommene er nøkkelen til å forklare hvordan sinnet vårt og sanseinntrykkene våre får oss til å ordne verden – altså det som får oss til å kunne ...

### Aritmetikk

- A priori, men ikke analytisk.

> Analytisk a priori vs. syntetisk a priori.

### Aritmetikk (2)

- Man kan gå ut over disse begrepene ved å ta aksiomer som korresponderer med det ene av de to, til hjelp. For eksempel en fremstrakt finger, eller som man sier i aritmetikken, fem punkter, og slik, litt etter litt, legge enhetene til det gitte og således fremstille begrepet syv i anskueligheten (5 + 2 = 7).

### Geometri

- Geometriske dommer er ikke analytiske, men a priori.

- Den rette linjen mellom to punkter er den korteste.
  - Begrepet om _rett_ er et begrep om en _kvalitet_.
  - Begrepet om _korthet_ er et begrep om en _kvantitet_ (størrelse).
- De to begrepene må knyttes sammen ved hjelp av anskuelsen (rommet).
  - Man kan ikke vise nøyaktig hvordan dette skjer – og derfor må vi tenke over hvordan det gjør det.
  - Anskuelsen må dermed her tas til hjelp; kun ved hjelp av den er det syntetiske mulig.

- Eksempel: summen av de indre vinklene i en trekant (er 180°).
- Denne dommen er ikke analytisk:
  > "Gi en filosof begrepet om en trekant, og la ham på sin måte finne ut hvordan summen av dens vinkler forholder seg til den rette vinkelen. Han kan tenke over dette begrepet så lenge han vil – han vil ikke komme frem til noe nytt."
  - Med andre ord: for å komme fra begrepet _trekant_ til _180°_ må han trekke inn anskuelsen.

### Euklids parallellpostulat

### Einsteins syn

- Ren geometri: geometriske teoremer tømt for alt faktisk (empirisk) innhold. De har kun et formelt innhold, bestemt av andre antatte ideer (aksiomer) i det geometriske systemet.
- Som ren geometri sier teoremene altså ikke noe om den fysiske verden; først når geometrien knyttes til erfaring, får den empirisk innhold.

