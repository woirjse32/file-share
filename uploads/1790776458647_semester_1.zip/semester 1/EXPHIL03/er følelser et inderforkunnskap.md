# Er følelser et hinder for kunnskap?

## Oppsett

- Feministisk epistemologi
- Historisk nedvurdering av emosjoner
- Hva er emosjoner?
- Myten om nøytral forskning

### Feministisk epistemologi

- Hva er feministisk epistemologi?

Elizabeth Anderson:
"Feministisk kunnskap og vitenskap kritiserer hvordan de overordnede oppfattelser og praktiske knytninger og populistiske knytninger til kunnskap skaper kunnskapsoppfattelse og begrunnelser som systematisk diskriminerer kvinner og andre underordnede grupper og forsøker å endre disse oppfattelsene og praksisene slik at de fremmer disse gruppenes interesser"

#### Hvorfor trenger vi feministisk epistemologi?

- Den deskriptive delen
  - Vi trenger noen til å kartlegge diskrimineringspraksiser
  - Fordi disse er normale/usynlige
  - Å avdekke diskriminering er ekstra viktig når diskriminering skjer på en usynlig måte
  - Særlig når disse forholdene ikke er åpenbare og synlige
  > Så vi trenger dette for å kunne se diskrimineringene

- Den normative delen
  - Det fremmer verdier
  - Diskriminering er urettferdig og må bekjempes
  > Hvis det oppdages noe som er diskriminerende så må man gjøre noe med det.
  - Ute etter å kartlegge diskriminerende forhold, ikke bare inkludert med kvinner, men også andre diskriminerte grupper.
  > "Man kan si at det er alles interesse å tildekke og vise disse"

### Historisk nedvurdering av emosjoner

- Så langt har vi gått gjennom "fornuftens sentrale rolle i kunnskapens dannelse, argumentasjon, vitenskapelig metode."
  - Hva med emosjoner? Har de en positiv rolle i kunnskapsdannelse, eller er de bare et hinder?
  De aller fleste i filosofihistorien har sett på emosjoner som farlige, villedende og skadelige for kunnskapsinnhentelse.
    - Jaggers mål er å vise at emosjoner kan ha positiv epistemisk verdi.

  Kontrasten mellom fornuft og emosjoner skjer langs flere akser:

  | Fornuft | Emosjoner |
  |---------|-----------|
  | Det rasjonelle | Det irrasjonelle |
  | Det mentale | Det fysiske |
  | Det kulturelle | Det naturlige |
  | Det universelle | Det partikulære |
  | Det offentlige | Det private |
  | Det mannlige | Det kvinnlige |


- Jegger mener at kontrasten mellom fornuft og emosjoner ble skjerpet på 1600-tallet
  - Platon og Aristoteles hadde et mer nyansert syn på emosjoner. De så dem som nødvendige, selv om de trengte veiledning fra fornuft

- Det historiske bakgrunnen er viktig for å vise hvorfor vi synes det er ganske naturlig å tenke slik om emosjoner
  - Moteksempler fra Platon og Aristoteles viser at det ikke er nødvendig at vi nedvurderer emosjoner

### Hva er emosjoner?

##### Fem trekk ved emosjoner

- De er følelser
- De er intensjonelle
- De evaluerer eller vurderer situasjonen
- De er aktive
- De er sosiale konstruksjoner

##### Emosjoner er følelser

- De inkluderer fysiologiske reaksjoner, dvs. kroppslige prosesser
  - Tenk på hvordan adrenalin produseres når man blir redd eller sint
- "Det stumme synet"
  - Emosjoner er bare følelser
    - Resten av Jaggers analyse er en tilbakevisning av det stumme synet

##### Emosjoner er intensjonelle

- Dette betyr at emosjoner har innhold eller handler om noe
> Hvis du er trist, sint, glad og får spørsmålet "hvorfor er du sint?" så kan du oftest forklare hvorfor du er det.
  - Det er en "ledende tanke eller vurdering" som bestemmer hvilken emosjon det er snakk om (s. 136)
    > Det har innhold som kan defineres som tanker eller en vurdering
    > For å kunne skille mellom forskjellige følelser må man peke på konkrete ting
  - Eksempel:
    - Innholdet som bestemmer hvorvidt en avvisning betyr at jeg er bekymret for at datteren min er sein, eller sint fordi det er buss forsinket igjen

##### Emosjoner evaluerer situasjonen

- Emosjoner forutsetter verdier
> Hvis man opplever en emosjon så har vi opplevd noe som vi opplever som bra eller dårlig. Emosjoner sier noe om hva vi bryr oss om.
- Eksempel:
  - Flykt, sorg, stolthet osv. rettes mot en kompleks situasjon som identiteten evaluerer (s. 140)
- En evaluering dømmer noe som er godt eller dårlig
- Emosjoner velger hva oppmerksomheten skal fokusere på og definerer delvis våre observasjoner
  - Dette er viktig for å se emosjoners bidrag til vitenskapen

##### Emosjoner er aktive

- Vi opplever ofte emosjoner "som opplevelser som overmanner oss" (s. 138)
  - Men vi kan påvirke og forme våre emosjoner
  - Man kan til en viss grad velge glede
    > Man kan velge å tolke verden på en måte som gir mer glede

##### Emosjoner har en sosial funksjon

> Man kan styre litt selv hvordan vi arbeider med gode og dårlige situasjoner ute i verden
  - Vi oppnår noe ved å være trist eller sint
    - De er handlingsaktige (men de er ikke handlinger)
  
##### Emosjoner er sosiale konstruksjoner

- Kultur lærer barn hva en passende reaksjon på en situasjon er
- Siden emosjoner involverer evaluering, er de bundet til måten verden oppleves kulturelt
> Kulturen rundt oss gir oss verdier og hvordan vi skal respondere på stimuli
  - Stor variasjon i hva som godkjennes som uttrykk for sorg, respekt, hat og sinne
  - Noen emosjoner er kulturelt spesifikke

### Myten om nøytral forskning

- Positivisme
  - En empirisk tilnærming til vitenskap hvor den forstås som en objektiv, verdinøytral og interessefri aktivitet
- Positivismen fremhever et ideal om nøytral forskning, og nekter emosjoner en positiv rolle
  - Emosjoners innflytelse er "ansett for å forvrenge eller hindre observasjon eller kunnskap" (s. 142)

- Et unntak i positivistisk epistemologi
  - Oppdagelseslogikk vs. begrunnelseslogikk
    > Fine måter å beskrive det som skjer når man prøver å finne ut hvilke hypoteser som skal testes (oppdagelseslogikk)
    > Det som skjer etter man har testet (begrunnelseslogikk)
    - Eksempel:
      - 1. Man lager hypoteser for undersøkelser
      - 2. Man tester hypotesene
- Positivismen tillater at emosjoner kan spille en rolle når man lager hypoteser
  - Dette er fordi det ikke finnes "noen begrensninger på de ikke-logiske metodene som kan brukes" (s. 142)
    - Når det kommer til begrunnelseslogikk (når man tester hypoteser) må man ta vekk emosjoner. Altså er situasjonen betraktet som helt annerledes:
      - Da er det etterprøvbarhet som teller, som kan eliminere subjektive verdier og emosjoner
      > Slik at det kan prøves på nytt av noen andre (for å teste etterprøvbarhet)

- Jaggar kritiserer positivismens distinksjon mellom oppdagelses- og begrunnelseslogikk som kunstig
> Med det mener Jaggar at det egentlig ikke er mulig å skille de to, fordi de går inn i hverandre
  - Hun peker på historiske eksempler på vitenskapelig praksis hvor det er ganske åpenbart at verdier og emosjoner har gjennomsyret hele prosessen
    > Er forskerne nøytrale, eller kan vi se at forskningen har klare egne verdier som vises?

- Myten om nøytral forskning må forkastes
  - Betyr det at ideen om objektiv vitenskap er håpløs eller umulig?
  - Nei, vi må revurdere forholdet mellom kunnskap, verdier og emosjoner
  > Vi må tenke på en annerledes måte om hvordan verdier og emosjoner spiller inn i snakk om vitenskap
- Myten fungerer som en ideologisk mekanisme som ekskluderer kvinner og andre minoriteter
  - De med makt tjener på at vitenskapelig forskning som reflekterer deres verdier blir ansett som objektiv
  - De uten makt kan avskrives som emosjonelle, irrasjonelle og subjektive

##### Fredløse emosjoner

- Emosjonell hegemoni
  - Siden emosjoner er sosiale konstruksjoner i samfunnet, "blir de bygget inn i fungeringen til vår emosjonelle karakter" (s. 145)
  - De aksepterte emosjonene stemmer overens med det dominerende verdisynet
  - Det dominerende verdisynet pleier å tjene de med makt
  - Derfor blir folks emosjoner en måte for de med makt, og dermed definisjonsmakt, å videreføre deres gjeldende posisjon i samfunnet

- Blir emosjoner bare ødeleggende?
> Nei, fordi mennesker ikke alltid har de konvensjonelt aksepterte emosjonene
  - Hemonier er ikke totale eller fullstendige
  - Konvensjonelt uakseptable emosjoner kalles for "fredløse emosjoner" (outlaw emotions)
- Subkulturer og fredløse emosjoner
  - Når individer opplever disse, blir de forvirret, men sammen kan folk danne en subkultur med "oppfatninger, normer og verdier som systematisk utfordrer de rådende" verdiene (s. 146)
  - Slike emosjoner er "epistemisk revolusjonære" (s. 146)

- Fredløse emosjoner og feminisme
  - Eksempler:
    - Fredløse emosjoner kan avdekke kjønnsdiskriminerende forhold
    - Sinet mot uønsket seksuell oppmerksomhet blir en del av en felles oppfatning at det finnes "et utbredt mønster av seksuell trakassering" (s. 147)
    - Det kan være vanskelig å forstå at det som vi nå ser på som ren seksuell trakassering var ganske vanlig og akseptert for 50 år siden
- Fredløse emosjoner leder til en positiv forandring i samfunnet


- Fredløse emosjoner og kritisk fornuft
  - Kan motivere til nye undersøkelser og styre valg av vitenskapelige problemstillinger
  - Kan lede til "revolusjonære revisjoner" (s. 147)

- Innvendinger:
  - Hvilke fredløse emosjoner bør omfavnes, og hvilke bør avvises?
  - Hvorfor skal vi foretrekke fredløse emosjoner over konvensjonelle emosjoner?

- Noen emosjoner er mer passende enn andre
  - Emosjoner er passende hvis de er karakteristiske for at et samfunn der alle trives, eller om de leder til at et slikt samfunn etableres (s. 148)

