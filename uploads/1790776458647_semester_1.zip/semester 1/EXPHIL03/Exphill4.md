## Kunnkapsresistens

- wikforss: 

### hva er kunnskapsresistens

- Det finnes mye relevant kunnskap sm vi burde ha og som er lett tilgjengelig for oss, men som mange ikke likevel ikke tar til seg.
- Det er ikke slik at vi går aktivt inn for p være kunskapsresistente.
- Kunnskapsresisten er ikke det sameme som uvitenhet
- Det finnes en rekke ting vi ikke vet av ulike grunner som ikke har noe å gjørøe med kunnskapsresistens
  - umulig  vite, f.eks. hvor mange stjerner det er i universet.
  - trivielle, f.eks Hva jeg spiste til forkost 12. mai 1982 (**trivielle påstander**)

## Hvorfor er kunnskapsresistens et problem?

- demokratiet:
  - vis vi går ut og ikke tar inn information (lett tilgjengelig og relevant info), hvordan kan vi stoles på til å stemme.
- kunnskapsresistens utfordrer verdien av utdanning:
  - Universitetsutdanning avhenger av at studetene er åpne for læring.
- Hvis vi kan forstå mekansime som ligger itl grunn for kunnskapsresistens kan vi ha et håp om å gjøre noe med det.

### Hva er kunnskap?

-epistemologi, erkjennelsetorie
  - læren om kunnskap

- sentrale spørmåm innen epistemologi
  - hvordan danner vi kunnskap?
  - hve er kunnskap=

- Dette sprøpemet er bedree enn sorøeme om vitenskap, fordi vitenskap er er en from for kunnskap.

#### Hva er kunnskap?

- ulike former for kunnskap.
    - Praktisk kunnskap:
      - Knowledege how:
      - knyttes til gerdigheter:
      - F.esk kan sykle, svømme osv.
    - Teoretisk kunnskap:
      - Knowlege that
      - påstandfrom (at p)
      - fe.sk jeg vet at oslo er hvoedstaden i norge.

### Teoretisk kunnskap

> dette er den typen kunnskap man får når man (**søker, snakker med chat, osv**).

- klassik defisnjon av kunnskap:
 - stammer fra platons theaiteos
 - kunnskap er en begrunnet sann ppfatning
- tre betingelser for kunnskap.
  - Overbevigning
  - sannhet
  - begrunnet

#### vise hvordan det fungerer

##### overbevising (eller oppgatining)
  - det pyskoligkse aspektet ved kunnskap
  - kunnskap avhenger av at de finnes som innehar kunnskapen dvs en kjenner.

  - Der er ikke nok at a bare leser noe, tenker noe eller får noe prestenert
     - man må også tro at dette er sant

   - vitkig ma kan ha en overbist uten å være 100% sikker på noe.

- For å vite at noe er tilfelle må du tro at dette "noe" er tilfelle.
  - For å vite at p må du he en oppfatning om at p.

##### Sannhet

-for å vite at noe er tilfelle må det faktisk være tilfelle
  - for å vite at noe er p må det være sant at p
- hva er sannhet
  - korrespondansetteorien stammer fra aristotelses.
  - den sier at sannheten foreleigger når tankeinnhold stemmer overens med verden.

##### begrunnelse

- vi må ha evidens for oppfatningene cåre for å ha kunnskap
  - vi må ha gode grunner for å tro det vi tror.

> eksempel: Jeg tror at 25 av dere ikke spiste frokost idag. (overbevisning)
>-->
> vi teller, og det viser sg at 25 av dere ikke spiste frokost (Sann)
>-->
> Det var ren gjettning (god grunn?)

- eveidensen gjør det tilstrekkeling sannslyug at oppfatining er sann
  - det må finnes en pålitelig sammenheng mellom evidens og oppfatning
  - Poenget med begrunnese er å nå sannheten og kunne dele den.
- hvor og hvordan finner vi evidens for våre oppgatninger?
  - wikforss mener at hovedårsaken til kunnskapsresistens er evidensrestistens

  - I forskning består evidens av vitenskapelig belegg i tråd med faglige metoder
    - tøyking foråsaker fkeft
  - vi får evidents i dagligvet tpå to gmåter
    - diktere sansene cåre
       - hanne har os seg en blå gener
    - indetkere fra andre menneker
       - dette inkulerere bekjente og ekesmeper
         - det regner i bergen nå
         - røying forskeirnger kreft

> Resonnering, observasjon, vtnesbyrd

##### Begrunnelse
- tre betingleser forkunnskap
  - overbevisning
  - sannhet
  - begrunnelse

- wikforss skriver "det første vilperdereder seg om min psyskilogike tilstand. den andre viklåere derdier seg om vrodan er ver og det trede vikperder binder seammen de to: evidens det gjode grinnlagetk obler min yskeigiske sammen


###### Hva teller som god evidens og hvor mye evidens er nok?

- Er det alltid mulig p betvile det jeg ser, eller, det andre forteller med?
  - undergraver til vevidens?

- infallibillisme og fallibilisme er uenige om hvordan vi skal svare


- infallibilister hevderat kunnskap krever ufailbarlig begrunnelse.
  - ufeilbarlig begrunnelse garaterer sannheten i påstanden den begrunner
- fallibilister støtter et svakere begrunnelseskrav
  - Begrunnelsen som kereves for kunnskap trenger å sannsynligjøre men ikke garantere at det påstanden den begrunner er sann.

#### secartes project.
- metodisk tvil

- descartes gud og infallibilisme
-descartes mener å kunne bevise at gud finnes.

  - siden gud er gud kan det ikke være slik at gud vil bedra oss.
  - det kan derfor ikke være slik at det som fremstår som **klart og tydelig** for oss er feilarikg.
  - Mye av det infomaton vifår gjennom snser fremstår som kalr og tydelig for oss
  - siden gud eksisterer kan vi derfor få sikker kunnskap gennom sansenes erfaring.

- vi kan ha kunskap om det som er heved over enhver tivl
- gjennom metodisk tvil kom vi først frem til at det eneste som ikke kan betvieler er at jeget seksieksiter
- Deretter s vi at desciremen menste at fud eksitens gjør at vi lkeevel kan stle på sannene som kilde til kunnskap
- vi kan stole på både emereike vitenskaper og hverdagskunnsap.

##### wikforss fallibilisme

- decartes gudsbevis er ikke overbevisende.
  - Vi kan ikke forutsette at gud str som gartatis for sansene våre.
- Decartes syn op kunnskap er altfor strengt.
  - vi kan ikke ha kunnskap om den ytre verden.
  > vis vi setter trekselen på kunnskap på 100% sikerhet kan vi ikke ha emirisk kunnskap fordi, det er nermest alrdi 100% sikkerthet
- wikforss mener at det emp være rom for tvil
  - Ellers må vi slutte oss til skeptitisme


##### hva er fallibilisme

- "fallibilisme " fra latin "fallibilis" feilbar

. kunnskap kerever ikke at der ikke kan vre rom for tvil
- kunnskap krever kun at begrunnelsen gjør det tilstrekkelig sansynlig fat oppfatningen er sann.

- om å bruke tvil som et motargument
  - det er ikk een innvending mot en overbevisning å påpeke at man kan ta feil.
  - det at noe ikke kan bevises med sikkerhet er ikke et godt motarguemtn
  - så lenge man har god nok evidens kan dette gi oss kunnskap
  - det å så tivl om evidens kan også misbrukes.
    - Eks. klimaskeptiskere
    - "fake news"
- Vi bør være allikevel være åpen for evidens som taler imot overbevisningene våre.

- hva er evidens som taler imot overbeiving?
  - Kullkastere! (defeaters)

- Hva er en kullkaster?
  - noen som undergraver dine grunner for en overbevsing

##### tre typer evidensresistens
- **1**: vi er ikke villige til å teste våre overbevisninger
- **2**: Vi unngår å ta til oss relevant informasjon (mulige kullkastere)
- **3**: Selv når vi står overfor relevant infomation, forsetter vi å tro det vi ikke har god grunn til å tro.

>--> kan minde om hva kant sa om latskap.


##### evidensresistens

- Kunnskapen har både indre og ytre fiender
- indre fiender: psykologiske mekanismer som hindrer oss i å ta til oss kunnskap.
  - Dette kalles **Kognitive skjevheter** (cognitive biases)
    - eksempel: Bekreftelsesskjevhet, meningsfatholsenhet, og dunning-kruger-effekten.


##### Dunning kruger effekten
> De som har minst kunnskap av ting ofte ser på seg selv som om de har mest kunnskap.

- ytre fiender
  - kunnskapsresistens har fått større gjennomslag grunnet ny teknologi.
     - Mange ulike kilder å velge mellom -- hvordan vet vi hvilke kilder som er gode?
     - informasjon som presenteres filtreres ut ifra historikken.
     - LLMs skaper tekster som virker informerte.

  - polarisering selger

##### Hvordan kan vi motarbeide kunnskapsresistens?

- Kritisktenking.
  - Vi må forstå argmentajson, hva avgjør om noe er et stekt eller godt arguemtn? for ekemepl skillet mellom innhold (holdbarhet) og logisk form (gylidhet)


- Kunnskap om empiriske forhold
  - Gå ut i verden og observer de relevante forhold.
  - Ha tiltro til eksperter (men selvfølgelig ikke helt ukritisk)

- Debatter bør foregå på skikkelig vis
  - partene må være både saklige og redelige
    > så kan vi motarbeide kunnskapsresisstens.
  - Man bør ikke ha debatter mellom eksepter og lekpersoner om temaer det er vitkesaplig konsensus rundt
     - det kan få det til å virke som om det er tet åpent spørmål.
