# Hvordan skal vi leve? Dyd eller lykke?

> Kjernen i forelesningen: Aristoteles' etikk i *Den nikomakiske etikk*.
> Spørsmålet er ikke «hvordan blir jeg lykkelig?», men «hva er det som gjør et liv godt?».

## Oppsett

- Grunnspørsmålene: hva er det gode livet, og hvilket liv er det beste livet?
- Aristoteles, mål og det høyeste gode
- Øvelsen: «hvorfor?»-testen fram mot eudaimonia
- Funksjonsargumentet – hva er menneskets oppgave?
- Eudaimonia – blomstring, og hvorfor det er mer enn lykke
- Vane og øvelse: vi blir dydige ved å gjøre
- Læren om middelveien
- Dyd i forhold til nytelse
- Praktisk klokskap (*phronesis*)
- Edelhet og det edle motivet
- Konsepsjonen: hvilket menneske vil jeg være?

---

## Grunnspørsmålene

Aristoteles stiller tre spørsmål i starten av *Den nikomakiske etikk* (NI I.1):

1. Hva er mennesket? Hva utgjør egentlig et menneske – hva er det som gjør oss mennesker?
2. Hvor kommer vi fra? Hva er vår opprinnelse, og hva er det som styrker eller svekker oss?
3. Hvorfor er vi her? Hva er meningen med livet, og hva er det vi egentlig skal gjøre?

Dette er de samme «store spørsmålene» som vi møter i evolusjonsemnet:

- **Hva er mennesket?** Her svarer Aristoteles: et fornuftig dyr.
- **Hvor kommer vi fra?** Her er svaret annerledes. I stedet for å forklare formen ut fra årsaker, forklarer Aristoteles formen ut fra målet.
- **Hva er meningen med livet?** Her er svaret et mål: blomstring.

> Dette er et **teleologisk** (målrettet) syn på verden. Meningen med en ting er dens formål (*telos*), ikke omvendt.

## Aristoteles og hans etikk

### Verket

- NI er skrevet som et læreverk: det er ment som en innføring i etikk for politikere, ikke som et abstrakt filosofisk verk.
- Struktur: **bok en** handler om det høyeste gode (hva er det beste livet?), **bok to og tre** om dyder og laster, og **bok seks** om intellektuelle og etiske dyder.
- Aristoteles skriver ikke «det finnes ett svar», men oppgir ofte ulike synspunkter og løser dem så best han kan. Noter hva han tar «for gitt».

### Mennesket som *zoon logon*

- Mennesket er et *zoon logon*: et fornuftig (rationelt) dyr.
- Poenget er at vi har et fornuft som kan styre resten av sjelen.
  - Vi har både en *rationell* del (forstanden) og en *irrasjonell* del (følelser, begjær, vilje).
  - Det er fornuftet som skal være herre over det irrasjonelle.
- Dette forklarer hvorfor Aristoteles kan si at mennesket er annerledes enn dyret, selv om dyret også «gjør» ting:
  - Bare mennesket har et mål som er et mål **for hele sjelen**, og som skal styre det øvrige.
  - Derfor finnes dyd også hos dyret, men hos mennesket er den noe det selv skal ta ansvar for.

### Hva er et mål (*telos* / formål)?

- Vi handler ikke tilfeldig. Hver handling har et formål: noe den er ment til å oppnå.
- Formålet kan være:
  - et **produkt** (skipbyggeriet → skip)
  - en **handling** (krigføring → seier)
  - eller en **tilstand** (medisinen → helse)
- Aristoteles skiller mellom det som er målet **i virkeligheten** og det som bare **ser ut** som et mål.
  - Vi trenger helse for å leve godt – vi *vil* leve godt, ikke helse for å leve.
  - Helse er altså ikke det siste målet. Den er et middel mot noe annet.

---

## 1. Det høyeste gode og målenes hierarki

### Alle handlinger har et formål

- Hver gang vi gjør noe, gjør vi det **for noe** – vi har et mål.
- Vi handler ikke av hensikt uten hensikt. Det finnes ingen handling som ikke er ment til å oppnå noe.

### Mål kan være midler eller mål i siste instans

> Mål danner et **hierarki**: noen mål er midler, og noen mål er siste instans.

- Medisinen har helse som formål.
  - Helse er ikke bra *i seg selv* – den er bra *for noe annet*, for det gjør det mulig å handle, leve og blomstre.
- Skipbyggeriet har et skip som formål.
  - Men et skip er ikke det beste. Det er et middel.
- Påstanden: **det finnes et siste mål, som ønskes for sin egen skyld**, og som alle andre mål er ordnet under.

> «Alt er ordnet mot det samme målet» – forskjellige mål kan ikke være siste instans samtidig, for da ville de enten være like (men de er ikke) eller det ene vært et middel for det andre (men da er det ikke siste instans).

### Konsekvensen: det finnes et «høyeste gode»

- Når alt er ordnet mot ett mål, må det finnes et **høyeste gode** (det høyeste målet / *summum bonum*).
- Dette er det gode som er ønsket for sin egen skyld, og som alle andre goder er ment å fremme.
- Aristoteles kaller dette **eudaimonia** – blomstring. (Se avsnitt 4.)
- I NI I.2 konkluderer han: det høyeste gode er det som oppnås for dets egen skyld, og som alt annet bidrar til.

### Sammenhengen mellom mål og årsaker

- Aristoteles: **godene rangeres i samme rekkefølge som årsakene er rangert i.**
- Vi må altså skille mellom:
  - det som er det beste for oss, og
  - det som bare er en nødvendig forutsetning for det beste.
- Helbred er en årsak til et godt liv, men det er ikke det gode livet.
- Konsekvens: vi kan ikke bare spørre «er det nyttig?», vi må spørre «er dette målet det peker mot?».

### Styrke og innvendig svakhet

- **Styrke:** dette er et rettferdig mot svaret til relativisme. Hvis alt var relativt, ville det ikke funnet noe enkelt svar på «hva er det beste livet?». Ved å peke på målenes hierarki får vi ett svar, ikke mange.
- **Svakhet:** argumentet er ikke i seg selv et bevis på at hierarkiet finnes. Det er fremsatt som *sannsynligvis* sant. Målet er ikke å «bevise» at det finnes et høyeste gode, men å vise at det er et godt svar på spørsmålet.

---

## 2. Øvelsen: «hvorfor?»-testen

### Eksempelet: hvorfor lader jeg telefonen min?

Tenk på alt du gjør i løpet av en dag, og still spørsmålet: **hvorfor gjør jeg det?**

- Hvorfor lader jeg telefonen min?
  - For at den skal ha strøm.
    - Hvorfor skal den ha strøm?
      - For at jeg skal kunne bruke den.
- Hvorfor ser jeg en episode?
  - Fordi det er underholdende.
    - Hvorfor vil jeg ha noe underholdende?
      - Fordi det er gøy / fordi det får meg til å føle noe.
- Hvorfor leser jeg Chandlers Crus?
  - Fordi det er interessant.
- Hvorfor kjøper jeg T-bane-billetter?
  - Fordi jeg skal på jobb / fordi jeg vil komme fram.
- Hvorfor ringer jeg telefon?
  - Fordi jeg vil snakke med noen.

### Hvordan fungerer testen?

> To spørsmål du alltid kan stille:
> - **Tenk etter hvorfor man vil noe.** Hva er det egentlig man vil?
> - **Tenk etter om man gjør noe for lykke.** Er dette handlingen bare en vei til noe annet?

- Gjør du det samme spørsmålet om igjen, stopper svaret før eller siden.
- Svaret på «hvorfor vil jeg ha det?» blir et vilje- eller gledesmål, og da er det bare ett spørsmål igjen: *hvorfor vil jeg ha **det**?*
- Til slutt kommer du til noe du vil ha **for dets egen skyld**. Det er det som søkes etter i hele Aristoteles' etikk.

### Konklusjonen

- Når vi gjør testen på alle aktivitetene våre, ser vi at de fleste peker i samme retning, mot det samme sluttmålet.
- Og det avslører hva eudaimonia er: **det er det du gjør for dets egen skyld**, ikke det du gjør som middel til noe annet.
- Derfor: eudaimonia er ikke én av tingene du gjør. Den er det som gjør de andre tingene verdt å gjøre.

> Dette er en praktisk øvelse som skal vise poenget, ikke et bevis på det.

---

## 3. Funksjonsargumentet

### Argumentet

- En fot har en oppgave: å gå.
- En hals har en oppgave: å bære.
- Et øye har en oppgave: å se.
- Disse oppgavene er ikke valgfrie. De er det som gjør foten til en fot, og øyet til et øye.
- **Derfor må også mennesket ha en oppgave.**

### Formelen

> **P1:** Hver ting har en oppgave, og oppgaven er det som er godt for tingen.
> **P2:** Meningen med hver ting er dens oppgave.
> **Konklusjon:** Menneskets oppgave er derfor det som er godt for mennesket – altså den fornuftige virksomheten.

- I *De Anima* II.12 skriver Aristoteles at øyets formål er syn, fotens formål er å gå. Siden hvert organ har sitt formål, må også sjelen ha sitt.
- Mennesket er det eneste dyret som kan utøve fornuft og dermed ha en oppgave som gjelder hele sjelen.
- Derfor er det som er dydig for mennesket, det som utøver fornuften på riktig måte.

### Er formelen nok?

- NEI – og det er viktig å merke seg at Aristoteles selv er klar over det.
- I NI I.2 skiller han mellom to ting:
  1. **oppgaven** (det en menneske gjør) – f.eks. det en far gjør for sine barn
  2. **oppgaven, utført godt** – f.eks. det en **god** far gjør for sine barn
- Det er den andre som er det gode livet. Å bare ha en oppgave er ikke nok, den må også utføres dydig.
- Derfor er den presise formuleringen: **det gode mennesket er den fornuftige virksomheten, utøvd i samsvar med dyd.**
- Dette er en **virksomhet** (*energeia*), ikke en evne. Evnen å telle er ikke det samme som å telle. Du har evnen til å telle, men bare den som faktisk teller regnes som dydig på det.

### Innvendinger

- **Er tenkning nok?** Hva med et liv uten tenkning?
  - Vi må skille mellom *tenkning som mål* og *tenkning som redskap*.
  - Tenkning er nyttig for andre ting: for å planlegge, for å forstå, for å handle riktig.
  - Men tenkning kan også være formål i seg selv. Da blir vi nær det Aristoteles kaller **betraktning** (*theoria*) – den høyeste aktiviteten (NI X). Dette er litt utenfor dagens notater, men verdt å kjenne til.
- **Hva med dyr?** Dyr er også aktive. Hva er det som gjør mennesket annerledes?
  - Dyrene har oppgave, men de kan ikke forstå målet som sådan. De følger drifter, ikke et formål.
  - Mennesket kan forstå at noe er et middel mot noe annet. Det er det som gjør *zoon logon*.
- **Er oppgaven medfødt eller innlært?** Blir man født som en god far, eller blir man det?
  - Se avsnitt 5: det er vanen.

---

## 4. Eudaimonia – blomstring

### Hva ordet betyr

- **Eudaimonia** kommer fra gresk og betyr bokstavelig **«blomstrende»** eller **«blomstring»** – «det gode liv er det som vokser og blomstrer, på samme måte som en plante».
- Ordformen *eudaimon* betyr «heldig» eller «vellykket».

### Eudaimonia gjelder livet som helhet

- Eudaimonia gjelder **hele livet** – ikke bare enkeltstående øyeblikk.
- Den er ikke en følelse man har i ett bestemt øyeblikk. Den er noe som vokser frem over tid.
- Dette er en viktig forskjell fra lykke, som kan komme og gå.

### Eudaimonia er bedre og rikere enn lykke

- Aristotelisk skiller man mellom:
  - **Eudaimonia** = blomstring, en tilstand/aktivitet
  - **Lykke** = en følelse, et humør
- Mange oversetter *eudaimonia* som «lykke», men det er misvisende. Aristoteles vil skille mellom det.
- **Det er ikke ved et tilfeldighets spill at vi blir lykkelige og sørgmodige, men ved de ting vi gjør** (NI I.10). Vi blir ikke lykkelige fordi vi er heldige, men fordi vi handler riktig.
- Dette er også en **viktig forskjell fra dagens psykologi**, som ofte beskriver lykke som en følelse. Aristoteles snakker om en hel måte å leve på, ikke om et humør.

### Eudaimonia def. (NI I.10)

> **Eudaimonia er en virksomhet i samsvar med dyd i et fullt liv.**

- Merk de tre delene: **virksomhet** – ikke en tilstand. **I samsvar med dyd** – ikke følelser. **I et fullt liv** – ikke én god dag.
- I motsetning til de andre goder:
  - Rikdom, helse, ære, makt – disse kan forbrukes. De kan gå tapt.
  - Eudaimonia kan ikke forbrukes. Den bygges opp og forsvinner ikke ved en svart dag.

### Hva følger av definisjonen?

- Eudaimonia er knyttet til dyd. Dyd er derfor ikke en løs tilføyelse, men en del av det gode livet i seg selv.
- Hvis dyd er en del av eudaimonia, og eudaimonia er det gode livet, så må vi leve dydig for å leve godt. Det er derfor dyd er så viktig i Aristoteles' etikk.

### Måten virksomheten er dydig på

- Du kan drive en virksomhet på mange måter, av ulike grunner:
  - av frykt for straff
  - av konkurranseinstinkt
  - av vane
  - av respekt for dem som ser på
  - fordi du vil det
  - av håp om å få tak i makt
- Virksomheten kan være den samme, men forskjellige motiver gir ulik karakter.
- Aristoteles sin konklusjon: virksomheten er det beste når den er «på grunn av det gode» – altså når hensikten er den riktige.

### Eudaimonia – oversikt

| | Eudaimonia (blomstring) | Lykke (gladhet) |
|---|---|---|
| **Hva** | En virksomhet, et liv | En følelse, et humør |
| **Når** | Hele livet | Øyeblikk |
| **Hvordan** | Ved at vi lever dydig | Kan komme ved tilfeldighet |
| **Forhold til dyd** | Inneholder dyd | Sig ingenting om dyd |
| **Kan forbrukes** | Nei | Kan gå tapt |

---

## 5. Vi blir dydige ved å gjøre

### Vane og øvelse

- Hver dyd er delvis medfødt og delvis utviklet gjennom vane.
- Vi får evnen til å handle dydig gjennom **øvelse**, akkurat som vi får ferdigheter gjennom øvelse:
  - Man lærer ikke å skrive, spille instrument, sykle eller bruke et verktøy ved å lese om det.
  - Man må prøve, og det går bra og dårlig mange ganger.
- Dette er grunnen til at Aristoteles sier at **dyd ikke er noe man «bestemmer» seg for å ha.** Man kan ikke resolvere seg til å være modig. Man blir modig ved å oppføre seg modig.

### Hvordan øvelse virker

- Kraften ligger i selve handlingene. Det er i handlingene at vi blir slik vi blir.
- **Vi blir rettferdige ved å gjøre rettferdige handlinger.**
- **Vi blir modige ved å gjøre modige handlinger.**
- Vi blir altså ikke dydige ved å *tenke* på å bli dydige, men ved å *være* dydige.
- Dette er grunnen til at vane trenger tid og gjentakelse. Dyd er ikke noe som kan kjøpes ferdig.

> Merk: kraften ligger i handlingene, ikke i intensjonene alene. Det er derfor det er vanskeligere å være ærlig én gang enn å være ærlig hele livet.

### Vanen alene er ikke nok

- Vane er nødvendig, men ikke tilstrekkelig.
- Man kan ikke bli god til å svømme ved å bare kjenne til vannet. Man må vite *hvordan* man skal svømme.
- På samme måte: man kan ikke lære å være rettferdig ved å gjøre det urettferdig.
- Derfor trenger man **praktisk klokskap** – for å vite hvilke handlinger man skal øve på. (Se avsnitt 8.)
- En person kan ha øvd mye, men øvd de **feil** tingene. Vane uten retning er ferdigheter i det gale.

### Hver dyd har en motsatt last

- For hver dyd finnes det en motsatt last, og det er nettopp dette som gjør middelveien mulig.
- Man kan ikke ha en dyd uten en motsatt last. Uten mot er man feig, ikke nøytral.
- Det er derfor dyd ikke er en følelse. Man *vil* gjerne være redd, man *vil* gjerne være ærlig – man må bare gjøre det i riktig dose og mot riktig grunn.

---

## 6. Læren om middelveien

### Dyd er ikke en lyst, men et middel

- Dyd er ikke noe man holder på fordi man liker det. Det er noe man gjør fordi det er riktig.
- Det er et middel mellom to laster: en mangel i den ene retningen, og en overdrivelse i den andre.

### De to lastere for hver dyd

| Dyd | Mangel (for lite) | Overdrivelse (for mye) |
|---|---|---|
| **Mot** | Feighet | Raskhet |
| **Selskapighet** | Kjølede | Vårdsløshet |
| **Gavmildhet** | Gjerrighet | Ødselhet |
| **Sannferdighet** | Selvnedsettelse | Prahleri |
| **Edelhet** | Lavsinnethet | Hovmod |
| **Vennskap** | Strid | Smigeri |
| **Vittighet** | Klossethet | Tullet |
| **Tålmod** | Irritabilitet | Følelseslighet |

- Merk at **mangelen og overdrivelsen ofte ser like ut** – det er det som gjør det vanskelig å treffe.
- Begge er laster. Det finnes ingen handling som er «ingen av delene».

### Dyd er som helse

- Dyd er som helse: et **riktig blandingsforhold**.
- Jern er ikke «bare godt» – det er godt for noe og dårlig for noe annet.
- Det er godt eller edelt **avhengig av konteksten**. Det finnes ingen egenskap som er god i alle sammenhenger.
- **Konklusjon:** det er ikke nok å si at noe er «godt» eller «dårlig» isolert sett. Man må alltid spørre: godt for hva?

### Middelveien er relativ til oss

- Aristoteles: **middelveien er ikke den samme for alle, men relativ til oss** (NI II.2).
- Konkrete eksempler fra teksten:
  - En **kort** person som får en kappe på, vil si at kappen er for lang. Ingen vil si at personen er for kort.
  - Å be om en middelhøyde på **7,5 talenter** er latterlig – det er det samme tallet for alle, uansett om man er lav eller høy.
  - En **svak** bue som man bøyer hardt, vil knække. Det er ikke buen som er feil – styrken er for stor i forhold til buen.
- Dette viser at **middelveien ikke er et fast punkt eller en formel**. Den avhenger av personen, situasjonen og formålet.

### Konsekvens: ingen regel

- Det finnes ikke noe fast regelverk som avgjør hva som er dydig i en hvilken som helst situasjon.
- Det er tre grunner til det:
  1. Middelveien er relativ til oss.
  2. Hva som er dydig, avhenger av formålet med handlingen – ikke bare av hva handlingen er.
  3. Det avhenger av den konkrete konteksten.
- Derfor trenger man praktisk klokskap. (Se avsnitt 8.)

> Men: dette betyr ikke at «alt er lov». Dyd er avgrenset av de to lastene. Man kan komme av middelveien, men bare i én av to retninger. Det er et rom for feil, men det er ikke tomrom.

---

## 7. Dyd i forhold til nytelse

### Spørsmålet

- Er noe dydig fordi det er nyttig, eller er det nyttig fordi det er dydig?
- Dvs.: vi gjør ting for å få nytelse, eller er det noe ved handlingen i seg selv som er godt?

### Svaret i NI II.1: dyd er mer enn nytelse

- Aristoteles avviser tanken om at dyd bare er verdt fordi den fører til nytelse.
- **Antagelse:** vi verdsetter dyd bare fordi den gir nytelse. Hvis det er sant, blir mengden nytelse avgjørende.
- **Konsekvens 1:** flere nytelser blir bedre enn færre. Men hva nytter det? Da blir det *bedre* å være en tyran med mange hoder enn en konge med én – noe vi umiddelbart avviser.
- **Konsekvens 2:** det betyr at lykke bare er et spørsmål om kvantitet, og at det beste livet er et liv der man får flest nytelser. Men da må alle de åndelige nytelsene (for eksempel nytelsen av å forstå) vike for de kroppslige. Det er heller ikke akseptert.
- **Konsekvens 3:** en person som handler dydig, men av andre grunner (plikt, frykt, vane), ville vært dårligere stilt enn en person som handler iltert av fornøyelse. Men det er ikke slik.
- **Konklusjon:** vi må innrømme at det finnes en nytelse som er bedre enn annen nytelse – nemlig gleden ved det gode. Dyd er bedre enn nytelse.

### Vi kan tilpasse måten vi oppnår nytelse på

- Det er ikke bare *om* vi liker noe, men **hvordan** vi liker det. Og det kan endres gjennom vane.
- Vi kan trene oss til å finne glede i det som er dydig:
  - slik at vi finner glede i å være modig
  - eller i å være ærlig
  - eller rettferdig
- Dette er den samme mekanismen som i avsnitt 5: vane endrer hva vi kjenner glede ved.
- Målet er at vi *vil* det gode, ikke bare at vi gjør det.

### Hva vi faktisk blir dydige av

- Vi blir dydige gjennom **gjentatte utførelser av dydige handlinger**.
- Og gjennom å utvikle et tilsvarende **holdning til dem** – altså at vi etter hvert ønsker å gjøre dem.
- Det er altså to ting samtidig:
  1. Handlingene endrer vanene våre.
  2. Holdningen endrer seg, slik at vi *vil* handle dydig.
- Det er derfor vane alene ikke er nok – holdningen må også endres.

### Konsekvens: det er ikke nytelsen som gjør handlingen dydig

- Det er **ikke** nok at en handling føles god for at den skal være dydig.
- Det er motivet, formålet (telos) og holdningen til handlingen som avgjør.
- En handling kan føles god (nytelse) og likevel være uærdig.
- En handling kan føles ubehagelig (ikke-nytelse) og likevel være dydig.

---

## 8. Praktisk klokskap (*phronesis*)

### Hva praktisk klokskap er

- **Phronesis** er evnen til å forstå hva som er **godt i en bestemt kontekst** – altså å vite hvordan man bør handle i en bestemt situasjon.
- Det er en evne til å *forstå* hva som er riktig – ikke bare å følge en regel.
- Ordet kommer fra gresk *phronein*: «forstå, merke seg». Det handler om å merke seg hva som passer i en situasjon.
- Phronesis kommer ikke fra boklig læring, men gjennom **erfaring og vane**. Den utvikles gjennom å leve.

### Teoretisk visdom vs. praktisk klokskap

| | Teoretisk visdom (*sophia*) | Praktisk klokskap (*phronesis*) |
|---|---|---|
| **Gjelder** | Det som er universelt og evig | Det som er lokalt og tidsavhengig |
| **Objekt** | Det som ikke kan forandres | Det som kan forandres |
| **Eksempel** | Matematikk, metafysikk | Hvordan man bør leve |
| **Hvordan** | Ved å forstå sammenhenger | Ved å dømme i situasjonen |

### Sammenheng med karakter

- Phronesis er ikke løsrevd fra dyd. Den er bundet sammen med karakteren.
- En klok person som ikke er dydig, er ikke klok – han er listig. En dydig person som ikke er klok, har gode intensjoner uten å kunne sette dem i praksis.
- Den **dydige og kloke** personen er målet: dyd gjør at man vil gjøre det riktige, og phronesis gjør at man vet hvordan.

> «Dyden gjør at man vil gjøre det riktige, og klokskapen gjør at man vet hvordan det skal gjøres» (NI II.5).

### Eksempelet: klok uten dyd

- Aristoteles sier at man kan ha en medfødt evne til å være klok, uten at personen er dydig.
- Han sikter til en person med stor naturlig intelligens, men dårlig karakter.
- Poenget: intelligens alene er ikke nok. Klokskap må være koblet til viljen.
- Derfor kan vi ikke lære klokskap uten å jobbe med karakteren vår.

### Når klokskap mangler

- Uten phronesis står vi igjen med:
  - enten regler som er for generelle (de passer ikke på situasjonen)
  - eller oppskrifter som forteller oss hva vi skal gjøre uten å forklare hvorfor (det gir ingen forståelse)
- Praktisk klokskap er derfor nødvendig fordi middelveien er relativ (se avsnitt 6).

---

## 9. Edelhet

### Hva det betyr å være edel

- **Edel** er ikke det samme som «fin». Edelt er det som står høyt, det som er høytverdig og fortjent.
- Edelhet er knyttet til det vi gjør for en god sak, og til holdningen vi har når vi gjør det.

### Edelhet som dyd

- Edelhet (ofte omtalt som *megalopsychia* – storhet av sjel) er en dyd i seg selv, ikke bare en egenskap ved andre dyder.
- En edel person har høy sans for det gode og edle, men er ikke pretensiøs.
- Ifølge NI: det er ikke kjennetegn på en edel person å være oppblåst, men å være edel i høy grad.
- Edel er derfor forbundet med **mot og utholdenhet** – man gjør det riktige selv om det er vanskelig og uten belønning.

### Motivet er avgjørende

- For å vite hva vi vil, er det viktig at handlinger **ikke er motivert av noe uvesentlig**.
- En handling kan se edel ut, men være drevet av:
  - forfengelighet
  - frykt for å miste anerkjennelse
  - gjengjeldelse
- Da er den ikke edel, uansett hvor mye den ligner på en edel handling.
- Det er motivet (telos) – ikke formen på handlingen – som avgjør.

### Eksempelet: den edle døden

- Aristoteles: **det er edlere å dø av nød, i slag, enn av sykdom.**
- Hvorfor?
  - Fordi man dør for noe. Man dør for en god sak.
  - Ved å dø av sykdom dør man for å unngå smerte – og det er et selvhenSynsmotiv.
- Kontrast: en handling som ser edel ut, men som gjøres for å unngå ubehag, er ikke edel.
- Dette viser at edelhet ikke handler om resultatet, men om **hvorfor**.

### Konteksten

- Her ser vi hvordan den aktuelle konteksten spiller inn.
- Det samme resultatet kan være edelt i én sammenheng og uærdig i en annen:
  - å dø i slag kan være edelt
  - å dø i en unødvendig krig kan være dumhet
- Edelhet avhenger derfor av:
  - hvem
  - hva
  - hvorfor
  - når

---

## 10. Konsepsjonen: hvilket menneske vil jeg være?

### Med dyd spør vi hvilket menneske vi vil være

- Med dyd spør vi oss selv: **hvilket menneske vil jeg være?**
- Det er ikke et spørsmål om regler, men om **hvem vi vil bli**.
- Og det avgjøres gjennom:
  - **hva vi gjør** (vanene våre)
  - **hva vi vil** (holdningen / karakteren)
  - **hva vi gjør i hver enkelt situasjon** (praktisk klokskap)

### Vi utvikler dyder gjennom tilvænning

- Dyder er ikke bare medfødte. De må utvikles.
- Dette er den praktiske konsekvensen av alt over: man blir dydig ved å leve dydig, ikke ved å *ville* være dydig.

### Praktisk klokskap avgjør hvordan vi reagerer

- Vi bruker praktisk klokskap til å forstå hvordan vi bør reagere i bestemte kontekter.
- Det finnes ikke noe fast regelverk – det er dømmekraft i den enkelte situasjonen.

### Dyd er knyttet til eudaimonia og til menneskets funksjon

- Dyd er ikke et mål i seg selv. Den er **et middel** mot eudaimonia.
- Og eudaimonia er knyttet til ideen om menneskets funksjon:
  - mennesket har en oppgave
  - oppgaven er å utøve fornuften
  - det gode er å gjøre det dydig
  - blomstring er det som skjer når det gjøres over et helt liv

### Sammenhengen – hele kjeden

> **Formål (telos)** → **Mål-hierarki** (alt peker mot ett mål) → **Eudaimonia** (blomstring) → **Dyd** (hvordan vi lever for å oppnå det) → **Praktisk klokskap** (hvordan vi finner den riktige handlingen) → **Vane og øvelse** (hvordan vi blir slik)

- Alle leddene henger sammen. Bryter du ett, faller resten.
- **Merk:** dette er ikke en rekkefølge man «følger» i livet. Det er én struktur som forklarer hele etikken.

---

## Mønstereksempel: hvordan bruke dette på en konkret sak

**Situasjon:** En venn ber deg om å betale en regning han ikke har penger til.

**Steg 1 – Hva er målet?**
- Er det å hjelpe en venn, eller er det å unngå skam og å bli sett som egoist?
- Formålet (telos) avgjør allerede mye.

**Steg 2 – Hva er telos med handlingen?**
- Å hjelpe fordi det er riktig, eller å hjelpe for å bli likt?

**Steg 3 – Hvilke dyder er relevante?**
- Ærlighet, rettferdighet, generøsitet, takknemlighet.

**Steg 4 – Hva er de to lasterne?**
- Mangel: strenghet / å nekte urettferdig
- Overdrivelse: godtroenhet / å ettergi alt

**Steg 5 – Hva sier praktisk klokskap?**
- Hvem er vedkommende? Hva er relasjonen? Har vedkommende gjort noe før? Hva ville en rettferdig person sagt?

**Steg 6 – Hva er edelt her?**
- Å hjelpe uten å forvente å få noe tilbake er edelt.
- Å låne ut penger uten å si ifra hva det gjelder, er uærdig.

**Steg 7 – Konklusjon**
- Middelveien avhenger av konteksten. Derfor må vi spørre og dømme – vi kan ikke regne det ut.

---

## Begreper du bør kunne

| Begrep | Betydning |
|---|---|
| **Eudaimonia** | Blomstring; det gode liv; virksomhet i samsvar med dyd i et fullt liv |
| **Eudaimon** | Heldig, velsignet |
| **Dyd** (*arete*) | Fortrinn; det som gjør en ting til den tingen den skal være |
| **Telos** | Formål, mål; det tingen er ment til |
| **Hedonia** | Nytelse, fornøyelse, behag |
| **Hexis** | Tilstand; varig vane; karakter |
| **Ethos** | Vane; sedvanemåte; karakter |
| **Phronesis** | Praktisk klokskap; evne til å dømme i en situasjon |
| **Sophia** | Teoretisk visdom |
| **Megalopsychia** | Storhet av sjel; edelhet |
| **Zoon logon** | Rationelt dyr; mennesket |
| **Energeia** | Virksomhet; aktivitet (ikke bare evne) |

---

## Spørsmål du bør kunne svare på

1. Hva er det høyeste gode, og hvorfor finnes det? Hva er det høyeste gode *ikke*?
2. Forklar funksjonsargumentet. Er det et bevis på at mennesket har en oppgave? Hva mangler?
3. Hva er eudaimonia, og hvordan skiller den seg fra lykke? Hvorfor er det viktig å skille?
4. Hvorfor er det ikke nok å ha en oppgave? Hva trengs i tillegg?
5. Hvordan blir vi dydige? Hva betyr det at vi blir dydige *ved å gjøre*?
6. Hva er læren om middelveien? Hvorfor er middelveien relativ til oss?
7. Hvilke tre grunner er det til at det ikke finnes noe regelverk for dyd?
8. Hva er forskjellen mellom dyd og nytelse? Hvordan viser Aristoteles at dyd er mer enn nytelse?
9. Hva er praktisk klokskap, og hvorfor er den nødvendig?
10. Hva er edelt? Hvorfor er motivet viktigere enn resultatet?
11. Hvordan henger eudaimonia, dyd, phronesis og vane sammen?

---

## Notater du bør sjekke i teksten

- Under «det høyeste gode» står et notat om **hovedmål og delmål** – sjekk om det sikter til hierarkiet mellom mål, eller om det er noe annet.
- Under «øvelse» er det et eksempel med en **ferdighet** – sjekk hvilken ferdighet det er snakket om.
- Under «konsepsjonen» er det notert at **det ikke finnes noe regelverk** – sjekk om det sikter til middelveien og phronesis, eller om det er et eget poeng.
- Sjekk sidetall i **antologien** for sitatene – her er henvist til *Den nikomakiske etikk* (NI) med bok og kapittel.
