# Evolusjonsteorien og mennekestes plass i natueren.

DE store spørsmlene:
- hva er menneket?
- Hvor kom vi fr`Hva er vår oppritnelse?
Opphav
- hvorfor er vi til? Hva er meningen med ivet?
Formål

To åpenbare observasjoner:
- Kampen for tilverelsen.
- De som er gode gjør det best.

Tre betingelser for natulig utvalg.

- Variasjon
- Fitness forkejller
- Arvelighet

### hvorfor trenger vi variasjon?

- uten varajson vil det ikke vise noe for naturlig utvalg å elge mllom!

- Naturlig utvalg er en sorteringsprocess
  - his alle indeitdere er identiske så er det ikke noe å sorte blant!

### Hvorfor trenger vi fitness forkejller?

- Fitness er en betegelste på et ididivfs forvantine antall avkom
- naturlig  utvlag vil ikke skje med mindre det er forskejll i antall av avom bland idietive i en proipasjon.
  - Som avkommet også for avkom.

### hvorfor trenger vi arvelighet

-- uten en meksitke som sørefer for at avkom likner p sine foreledere komukative evkajsoner endirnger ikek vøre mulig

- tenk tilabek på elefecteksemrplet
  - hvis der er helt tilgelriglig om avkommet lignienr på sine forelrider ville ikke forler ved å ha en mindre kropp vært mer enn en grenreasjon

  - så for at natulig utvalg skal kunne prsiere konstualte iveclosjelel enrigner.

### Hva disse betugelene ikke spesifiserer

- Mekantiske for arvelighet
  - Hva sørefer for at avkom ligner på sine forleterE?
  - Moderetne evoltigjosnteori: gener
  - Altiveite maktismeir, solsalt arv, søktoligk arv, symbroitotsk ultuerel arv.

- Variasjons opphav
  - jvorfor oppstår arvelig vasjonon?
  - Mederer eeolosuojsonteroi: genritks mutajson og eller rekomonasjon.
  - andre mulige mekarismer plasitbilet, genterik assmilasjon, epegenetikk.

### Gen begrepet

- gen begerer har mange ulike defineajson i de ulike beigligke disperlieene.

  - definisjonen fra evolsijonsbilogien: gener er en sekves av DNA som påviker en orginaismens trekk.
  - vitkig eganskaper.



## Tilbake til de store sørsmålene:

- Hva er mesnnekeet, er avansert dyr, men ikke noe vesentlig anderlesdes med andre dyr.

-Hva kommer vi fra?
- vi er produkt av tilgerlde muajsoner.

- Hva er menigene med livet?
- formåletrettset fors.ekse er lar flere på valig naturvitenskaå.

## standard versoneen av eluaosjonsteoriene.

- Grener er vitkige med orgaimer i sentrum
  - Oprgiansjons foredere er hva natlgug utvalg seklfer fra
- men kun fordypisk vasjon som er et produskt av underliggene genrtisk vasjonen er ert rekaruvt natlug sleketjon.

- genere er kun ideriekre synlig for natulig

- gerner er fuedemtete
- gener har som maål for å skale mange koperer av seg selv som ,ulig
- orgaimer er overlevelsemaksiner genere ahr kopi for å fremme sine egene intereseer
- gener er vellkyet ved å skaepr oversmetmaskiner som sørger for genedes vidre resperjaosner i kommende genrajsoner
- gener er entetne sm  elekterere ved natulg utvalg


## Gnesletasoneisme

- Gener kommer i to vrasjoater, Alleler, A og b
- Gjennom å prisere elfatner som er vmindre gnere ad outvkomer A varetneten

- to paralelle kamper for tilveræerleen.
  - en mellom eleftatne på kyrer
  - de stoe har A.



## Hvorfor ta genenets perspectiv.

- kan forklare genomen som tiltrekkenende er pefor setandervaersjon av evoljsonsbroin.

- exisletns i isteddenfor.
- seksull kambialse
-viktig for darwin. alhuisme

- vorfor er disse femonomene paradokiste?
  - De er stafieltig og allefierigk som giv lare fittness for idetiviele orgaimer.


## Eusoialitet

- Eusosialitet er en type sostial orgiansimsering derett eller flere idiirver i en solsal gruppe reduserer sin egen reprosuernetmulig for å oppførste avkom fra ansdre indervier i den samme gruppen

- maur 
-dronnig
- dronger
-atdentne
- nAkerotter
-dronning
-repistuke haner
- autotneme

## seksuell kannibalisme

- seksuell kannibalisme refere til fenomeen der en orgaime som oftes hunnen siser manen sin under eller etter paring

-. parteltee forteler for hunen
  - mat enrgi
  - mindre konkuaresne for mat og ressueer lokalt

- Fordeler og ulimer for hannen:

-  - den fpr ikke mulig het til å være seg
- men mister fretige oeariskermulihjer som gir annen lavere fitness
- jvrfor har ikke hamme utvkilig stragier for å unngå å bli spist.


## Bipologisk altruisme

- bilogisk alturisme er afferd hos et idievit sm mster egene repsursjormsutligher men som øker tilsvarede ulighet hos andre idieder i gruppen.

- bilogisk allteriems ehar konsetrates med egisme
  - adeferd somøsker et idiedievs repsirsons muligher gjere på bekosting av andre idivider i gruppen


## Problemet med alturisme

- hvis antulig utvalg stoerer p bagkrun på idierver so mer i kaorniekre konrkser med hvere er videne de som frår flest avkom

- hvordan kan vi forkare at noen enkeltidierer ser ut som å ofte sine ege overlevieiteke og repsirlsjonsmeutlig her for å gjelpe sine egne overlevlesandre id

## for gruppens beste

- standerkarolging av disse parariske kremeornee var tildeirlere at natulig utvalg ikke kvittet seg med allguere idivder..


## problmer.

- Det er vanlgig å gjøre rede fro hvodan ftupper repsorserer.
  - siden natulig utvalg hander om differisell reptisjons hva skal vi grgne som avkommet itl en gruppe?

- siden natulig utvalg hndler om differusle repfsjone. hva skal v tegne som avkommet til en gruppe?
- hva egjr noe til en gruppe?
  - kan alle runt varmfull regnes som en gruppe dyr?
 kanskje alle komatke?
- kunne iv ikke du si at edet vart til grupes neste at alle ideitle gikk ammen med å handes med evetige motdyr
det er vanslgig å se hcorda ikke eigiskeitme.


## repsiasns og overlesitkemaskitnger.

- Vi kan iføtke darmin lese autkstis rblem ved å gjøre et sikte mello mrepsirke go overleslee maksinger
- forirg om reltiei er en skerokson liveits oppsringsle

- ri firkr var kun egitkig for este sitable semainger av atmer oppsto

- noen av idsse esntere asamliene av atoner bandt sseg sammen og domel molekeyler

- noen av disse moltukee fikk etller hovøt egenskaper at de kunne lage koper av seg eslev, de øfrtkte repsitkesrrene.


## Feil koperieing og vairjaon


## konsukrse og innovasjon

- i øået av kame fr toøvereøse slaåe mpem reåøoaskpter pverdevoesøe ,alromer fpr ¨hise seg selv


- med øsktoee lpmmlarese for rssierer ble disse overleslemakriene mer og mer kompel og effetive
- mnoen orvelgielenesmakring kan ha utvidet evnen til å spise andre overleslemakring for å dra nytte av deres ressuerer

## Fra replicaksoner til gener.

- i dag har alle reprleiekr samleg seg ikoneoenre som samtaer for å skale pe overlesltingmasitnene som sørger for dens fremsitgie eksistens

- de har fått neantet gener og alle ideitder veriser er dens overleismekang inkuldert manenesket

## Hvordan kan gner være egositkseie?

- hva mener vi med egoisme?
  - Må ikke forståes i en psykologisk forstand generkan ikke bry seg om noe


- Det er heller "som om" gener er egoisktiske
  - Et gene er etisketks ved å eprotmdeøerer sin egen overlevelse uten å prosydere eller på nelasotmg av sin overlesleitmasking overleslee.


## Mennesket er bare et overlevelsemaskin for å fremme genee.


## Autotiske mhos mennekset

- hva med mennekers autlsitme?
