# Exphil 3

## Hva er vitenskapen? Hva er vitenskapelig?

### Pseudovitenskap

> Pseudovitenskapen er vitenskap som er falsk, men prøver å vise seg selv som sann.
> - Teorier som utgir seg for å være falske.
> - Påstander som later som de er vitenskapelige.

### Selektiv og usunn skeptisisme

### Pseudovitenskaplige teorier
- Astrologi
- Frenologi
- Homeopati
- Kreasjonisme

### Pseudovitenskaplig praksis
- Vage, overdrevne eller ikke testbare påstander
- Bevisfornekelse
- Lav standard for bevisinnsamling
- Litengrad av åpenhet mot eksterne eksperter
- Konspirasjonistisk argumentasjon
- Bruk av villedende språk

### Hva er vitenskap? Hva er vitenskapelig?

> Det er ikke lett å gi et konkret definisjon, men:
> - Vitenskap er en systematisk, metodisk og kritisk undersøkelse, studie eller forskning.
> - Vitenskapen stiller krav om tilfredsstillende evidens eller begrunnelse for, eller begrunnelse av, de påstandene som fremsettes.

## Vitenskap refererer også til en rekke fagområder
- Naturvitenskapene
- Samfunnsvitenskapene
- Humaniora

### Skille mellom vitenskap og pseudovitenskap
- Epistemiske grunner
  - Hvilke teorier burde vi tro på?
- Etiske og politiske grunner
  - Hvem er ekspertene som samfunnet kan stole på?
  - Hva gjør vi når folk nekter å tro på det ekspertene sier?
  - Å kalle noe for "pseudovitenskap" kan være maktmisbruk
    - Trofim Lysenko ledet en kampanje mot genetikk

### Demarkasjonskriterium
- Oppgaven er mye vanskeligere enn man skulle tro!

#### Konsensus
- "Et utsagn utgjør konsensus dersom tilstrekkelig mange mennesker er tilstrekkelig overbeviste om det" (s. 65)
- Hvis vi tenker på menneskeheten, har mennesker trodd på mange absurde ting.
  - Poseidon forårsaker jordskjelv, demoner finnes, stjerner er guder, osv.
- **Vitenskapelig konsensus?**
  - Forskere har vært enige om andre ting: geocentrisme, flogiston, uforanderlige ting, osv.

- En teoris vitenskapelige verdi har ingenting å gjøre med hvor mange mennesker som tror på den.
  - "Teoriens verdi avgjøres utelukkende av hvilken objektiv støtte disse hypotesene får av kjensgjerningene" (s. 66)

- Teorier blir konfrontert med fakta, og en teori må underbygges av fakta.
  - Tenk på debatten mellom Galileo og Scheiner.

## Fakta og teorier

- Lakatos siterer den russiske filosofen David Hume (1711–1776) som etterlyste "eksperimentell" argumentasjon.
  - Er det tilstrekkelig for vitenskap?
- På 1600-tallet var det mye forskning gjort på hekser.
  - Dette inkluderte nøyaktige observasjoner og eksperimenter.
  - Heksekunst ble sett på som et forbilde for den type eksperimentell argumentasjon.

- Eksperimentell resonnering bruker induksjon.
  - Induksjon er en type argumentasjon som etablerer en generell påstand fra observerte enkelttilfeller.
- Induktivt resonnement:
  - P1: Alle svanene i Sørsanden er hvite.
  - P2: Alle svanene i Central er hvite.
  - P3: Alle svanene i Paris er hvite.
  - Konklusjon: Alle svanene er hvite.
- Det finnes svarte svaner i Australia!

### Induksjonsproblemet

> Man kan ikke alltid være sikker på at neste data kommer til å støtte dataen man har fra før.

- Lakatos sier at "det ikke finnes noe gyldig måte å avlede en naturlov fra et endelig antall kjensgjerninger på" (s. 66).

- Alle vitenskaplige teorier er like umulig å bevise (s. 66).

- Standarden for vitenskap bør ikke være for høy.
  - Descartes' kriterium "hinsides all tvil" er for strengt og utopisk.
  - Empirisk vitenskap kan ikke være like sikker som matematikk eller like nødvendig som deduktiv argumentasjon.

### Probabilisme
- Løser induksjonsproblemet ved å senke standarden for hva som teller som vitenskap.
  - En teori krever høy sannsynlighet, ikke sikkerhet, for å telle som vitenskap.

- Poppers innvending:
  > "Samtlige teorier, matematisk sannsynlighet, vitenskapelige som pseudovitenskapelige, er lik null" (s. 67).

### Karl Popper (1902–1994)
- Østerriksk-britisk filosof.
- Poppers argument mot probabilisme:
  - Sannsynlighet = Observasjoner / mulig evidens.
  - Siden mulig evidens er uendelig og antall observasjoner er bestemt og endelig, er sannsynligheten alltid lik null.
- Induktiv metode og probabilisme forsøker å "strengt bevise eller verifisere teorier via evidens og observasjoner.

  - Poppers idé: Istedenfor **verifiserbarhet**, kan vi benytte oss av **falsifiserbarhet**.

  - Falsifiserbarhet: En teori er falsifiserbar dersom det er mulig å sette opp en test eller eksperiment som kan vise at teorien er feil.

  - Falsifiseringsprinsippet:
    - En teori er vitenskaplig kun hvis den er falsifiserbar.

  - Ensempel på en falsifierbarhetstest:
    einsteins relativets teori <strong>
  - mulig test: avblying av lys på grunn v solen
    - siden solen ar så stor masse vil rommet rundt solen bøye lys som går forbi nør solen
    - lys eviger seg vanligvis i rette linker
    - dermed i følge relativeteorien burde lys fra stjerner som kommer til fori solen "bes rundt solen
  - hvis det viser seg at lys ikke bøyen seg rundt solen så vil relativetsorien.

  - Einsteins rletietsori bestpr falsifiering
     - den 29. mai 1919 under solformelejke tok eddington bilder fra øya principe på arktigverket
     - tok bulder av stjernee som egenstlig skulle vært gjent bak solen. de nle sett akkurat hvor einstein forutså og ikke hvor newtonsk fysikk hadde forusett
     - piblist i 1920 og førte til allemnt aksept av relaitvietepren
     - md en troi solk ikke betåer av falsiferoing kan vøre en utdatert eller feilarktig vitenskapelig teori


  - marxistisk teori
   - historik mateirmieme
     - forsåk å å forklare mennesketes historie utifra kampen om producsjonsmidlene mellom ulike sosiale klasser
     - en forklaringsmodel for samfunnets og mennesker histore
     - marx så på sin toeri som en vitenskap
   - Marxist trori mer generelt
     - Samlede betier for toeireker forkalringmodeller og iteltekueller trasjison med opphav i karl marx sitt tankegods
   - Er marxiteier teori en vitens eller pseudovitenp i føkge poppe?
     - "for en poppertilhener er marxistemen vitensjaplig hivs marxister er villige til å spesiekre kjensgjerninger som ville får dem til å påågi marxisme skulle de forellgege svhsi de netier p gjre dette blir marxisme en pseudovitenskap
    - svaret avhenger av hvorvidt marxisme formuler en falsifiserhbrhetskriterium

  - Innveninger mot falsifiseringsprinnsipet
    - Det stemmer ikke med hva vi ser i praksis! 
    >Vitenskapsfolk forkaster ikke teoriene sine basert på en eneklt motsitridene obersvarsjon.
    - de er tykkhudede krative og motstandysktige
    >det oppgir ikke en troi bare fordi den motsies av fakta.
  - Hva gjør vitenskapsfolk med motstirdene obersvasjoner.
    - besktive dem som utregelmessigheter eller anomalier, som de ikke ennå kan forklare.
    - bruke det toreirke rammeverket for å forklare at de ikke faktisk strider mot teorien.
    - endre deler av det teorieke rammeverket for p tilpasse dem.
    >Eksempel: Alexis bouvar (1767-1843) oppdager uventende endring i banen til uranus
       - denne observasjoner står i strid med newtons lover
       - potenisell falsifierende observajson
    - hvordan reagerer bouvard på opversvasjonen?
       - Han forkaster ikke nawtons lover basert på observajson
       - instedenfor utvleder at baner til utanus må våre påvikeen av grativsjonell pertuebasjon fra en ukjent planent.
       - i 1847 blir neptun for føste gang observert!
          - Neptun blir først "oppdaget" på bakgrunn av en matematisk preduksjon.

### Kuhn og vitenskapelige revolusjoner
  - tomas kuhn var en ameriskasn filosof (1922 - 1996) som skrev "the struckture og the sientific tevoulsjons" i 1962
    - thomas kuh nøe pårvikeen av propper og sentalt i hans kritkk av popper stpr vitenskapplig praksis
  - i følge beståer vitensaplene av paradigmener som er det reoriske rameverket vitenskaplsfolkj ruker ofr å forstå verden.
    - vitenskapelige fremstivh nadler is tor gram om vitenslapge revoulsjoner hvor et paredigme blir forkastet til ofrdel for et bedre et.

  - men vitenskaplige revulsjon tilhører skjeldenhet, mesteparten av tider fjober vitenskapfol iinnen samme paradigme (normalvitenskap)

  >paradimer, kjennetegner vitenskap, paradimen skrift, er det som viser vitenskaplige revusljonen.

    - hav er et vitekslaig pradimene?
      - et parDIGME ER ET RAMMEVERK FOR Å FORSTÅ VERDEN. DET BESTÅR AV AKSEPTERE TOEIRER, METODER, LOVER, ANTAGELSER, OG TEKNOLOGIER, SOM EN GRUPPE FORSKIERE GJOBBER INNENFOR OG UTI GRA.

    - vitenskaplige utvkiling
        - prepraradigmatik fase-
        - normalvitensap med problemløsing.
        >alle baseres seg selv rundt samme standpunkt, grunninfo for å bygge seg opp.
        
        -anomilar
        > uregelmessige observasjoner som ikke vi vet hvordfor skjer ennå.

        -krise
        > krisen skjer, når, vi har på overganging på starten av en "revulsusjon". Einstein > newton

        - vitenskplig revulsjon.

        - paradismeskifte og nytt paradigme.
    
    > Kuhns kritikk mot poppers stit falsifiereingorunssipp.
      - falsifisajon skjer hvordandlig i forbindelse med "revulusjonsfasen", som er reltiavit sjeldne aledninger.
        - egener seg sikke om demarkasjonssprinsipp
        - vi burde heller bruke normalvitenskapen sm utgangspunkt for demarksjon
      - Krav om problemøsing
        - normaeivene består av problemlsøig hvor de regisjaede reoriene er aktieprter og problemet som kal løses er defiener i hendhld til didsse
        - et demoarksjonsprinsipp må bli formulert

   - Kuhn om paradigmens usammenlignbarhet
      - ifølge kuhn er de vitenskaplige paradimgene før og etter et paradigmeskrifene så forskijellene at reoriekene drees usammenligmbare
        - det nye paradigmet kan ikke bevises eller motbevises av reglene i det gamle paradigmed, og onvendt.
    - Lakatos sin innvedig
        - Kuhn sitt syn på vitenskap gjør at endringer i teorier skjer som en slags ittrasjonell ovettalelse, der det ikke er noen gde argumener for å endre vitenskapelig syn.

  ### Forskningsprogrammer
     - lakatos kriterer popper og kuhn men bygger osgp vidre på dem.
       - engig med popper i at vi trenger en forstelge av reoriesk endring som er trasjonel begrunnet
       - enig med kuhn i at vi må ta høyde for vitenskapshistorie og faktisk vitenskapelig praksis, vitenskapsfolk gir ikke opp teoriene sin lett.
     - laktoes utvikler teorien om forskningsprogrammer.
    -Hva er et forsningsrprogram?
      - komplekse rammeverk som rettleder vitenkalige språksmål, ekseperimenter og tolkninger av data.
      - historire enhetter som eksitester i en perisode endrer seg over til løser problemer og teanker anomalier
        - newtons mekanikk
        -evolusjonsteorien
        - mikrobeteorien om sykdom
      - forskingsprogrammer vs paradigmer
         - forskinger inklere flere beskleidede roeiren men er mindre en paradigmenr
         - viktig forskejll fra paradigmener, ha seom skjer når forskingsprogrammer endres.

      - Struktueren til et forskningsprogram.
         - hard kjerne av utforandrlige teorien og antakelser.
         - beskyttelsesbelte av forandringel hjelpehypoteser og tilleggsantagelser.
         - forbud mot å endre den harde kjernen (negativ heuristikk)
         - påud som andgir de akrisme måter å endre hjelepsyepere og tilleggsantekeger på (postiv heuristikk)
      Husk eksempler med alexis bouvard
        - uvendtene endring i banen til uransus str i strid med newtons lover
         - han forkaster ikke newtons lover (hard kjerne)
           - han legger til en hjelpehypotese
             - en hitil uoppdagetplanet som påvirker utranus sin bae
              > neptun
        - Anomilarer eller utregelmessigheter
         - Alle teorier har dem
           - dette betyr ikke at de er dårlige, uvitenskapelige eller ifare for å bli forkastet.
    - Progressive og degeneraende forskningenspormer
(this should maybe be table under)
     - progressive forskningsprogram.
       - gjør nye og oversakende preduskjoner
       - øker forklaringsenven til programmet

    - degeneende forskningsprogram
      - gjør ikke nye preduskjoner
      - øker ikke forklaringsevent il fprofenerment
      - forkuset på nåteiden
      - takler porgramete funn og forarer nye date, men gi

 ### Marxisme degerenerende forskingspremmer

 > marxisme hari kke foruettstt nye og overaksende krjennsgjerningser de uventende forutsigelsene har visste seg at være feil

 #### lakatos sitt demakrasjonskriterium
   - et forksingsprofamer er itkalig dersom det er progreirvt og pseudoevuteepelig dersom det er degerenderene
 - enridng i vitkensaligen
, et degenrenede ofrksings vil dø lagsom etterhversom flere og flere forkeviele vil skrifte itl more fo