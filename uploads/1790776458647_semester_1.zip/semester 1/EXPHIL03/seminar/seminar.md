INFO:
Hva er avgrensingskritierum et / bekrsitlive av vitenskapen og se om deres syntes at disse tller eller ikke som vitenskap, basert på lakatoses avgreenasitktiekrtum for vitenskap.

kuhn mener at det ikke fines noe objetkitv skille mellom vitenskap og psudovitenskap. argmenerter for og imot dette. hvorfor.**For Kuhn (skeptikerposisjonen)**

- Kuhn, *The Structure of Scientific Revolutions* (1962): Fagområder er **underbestemt**. Data alene bestemmer ikke hva理论 skal være – teorien avgjør hvilke data som er relevante, hva som er et problem, hva som er en god løsning. Dette er hans "duck-and-cover"-poeng: rivaliserende teorier er **inkommensurable**, de snakker ulike språk og ser ulike problem.
- Paradigmaer er **udøvelse, ikke regler**. Å observere gjennom et paradigmakikkhull (paradigm-mediated perception) betyr at du ser en **gøs** vs. to mus, ikke bare det samme. Da er det ingen nøytral metode å sammenligne de to teoriene med.
- Vitenskap og pseudovitenskap skiller seg derfor ikke ved **epistemiske kvalitet** (ingen objektive kriterier for "bedre"), men ved **sosioinstitusjonelle forhold**: skole, fagdisiplin, tidsskrift, kvalitetssikring, replikasjon, internasjonal konferanse. Pseudovitenskap mangler disse. Det er en *sosial* forskjell, ikke en *metodisk*.
- Konsekvens: Kuhn avviser "den objektive metoden" som universal standardskjema. Vitenskap er bare det noe slik praksis fungerer i en gitt tid – en relativistisk, historisistisk posisjon.

**Imot Kuhn / for en objektiv skillelinje**

- **Problem of demarcation er ikke uløselig selv om vi dropper naivisme.** Popper: falsifikasjon. En påstand er vitenskapelig dersom den kan prinsipielt motbevises. Astrologi, gjestemålinger og "himmelske mekanismer" er ikke-falsifiable. Dette er et objektivt, språklig kriterium, ikke et sosialt.
- Kuhn selv innrømmer at han ikke løser demarcasjonsproblemet, og i kap. 16 faktisk går tilbake til *normal science* og det han kaller "the values of science" – objektive kriterier som nytte, fruktbarhet, empirisk innhold. Han er altså ikke så relativistisk som han tolkes.
- **Poppers falsifikasjonisme og Kuhns historie er komplementære, ikke konkurrerende.** Kuhn forklarer *endringer i praksis*, Popper forklarer *hva som teller som godt vitenskapelig argument*. Kritikere som Agassi og Toulmin viser at Kuhn mangler en normativ grunn – uten den er "han aksepterer astrologi så lenge astronomer gjør det".
- **Realisme om underbestemthet er ikke relativisme.** At data er underbestemt av teori betyr at *valget mellom teorier* krever utenforvitenskapelig vurdering – men hver eneste teori kan fortsatt testes *internt* mot data. Replikasjonsfeil, manipulering, p-hacking, manglende blinding, ikke-reproducerbarhet er **objektive** feil. De er like relevante i Kuhn's paradigm shifts som i normal science.
- **Metaforen "gøs/mus" er ikke så sterk som den ser ut.** Kuhn skriver selv at observasjonen kan korrigeres, at skarpe sinner kan se gjennom kikhullet, og at anomalier til slutt tvinger fram endring. Det er et idealisert bilde brukt mot en karikatur av positivismen.

**Hvorfor striden står fast**

- Kuhn angriper en **sterkere** positivistisk posisjon enn den som faktisk finnes. Hvitboksmetodologien er forlatt, og selv Popper avviste den. Det Kuhn angriper, er en modus operandi, ikke en levende posisjon – så mye av kritikken treffer en stråmann.
- Motparten angriper Kuhn på **normativ grunn**: uten kriterier er både Kuhn og en astrolog like "gyldige" i hans eget rammeverk. Det er det reelle problemet. Kuhn har sterkt svar på *hva* han avviser, svakt på hva som bevarer skillet.
- Løsningen i praksis er ofte **hybrid**: Kuhn forklarer historien og det sosiale, Popper/Hüttig levererer testene. Metaforsk forskere flittig bruker, men ingen felles standard.
- Det er også et **maktproblem**: Kuhn passer bedre til å forstå hvordan vitenskap *endres* enn hvordan den *bør* evalueres. Det er en deskriptiv styrke og samtidig en normativ svakhet.