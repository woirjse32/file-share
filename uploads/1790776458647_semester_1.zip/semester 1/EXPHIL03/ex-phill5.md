# Bullshit, politikk og uvitenhet

## Oppsett

- Filosofens rolle i samfunnet
- Kritikk av demokratiet
- Rettssaken mot Sokrates
- Sokratisk elenchus (testing)
- Sokratisk visdom
- Mot og uvitenhet om døden

### Filosofiens rolle i samfunnet

- Vitenskap
- Vitenskapens grunnlag
- Vitenskapelig metode
- Demarkasjonsproblemet
- Hvorvidt samfunnet kan stole på vitnesbyrd

> Filosofene har bidratt med å formulere tydelige kriterier for god argumentasjon, tilstrekkelig bevis, vitenskapelig praksis og generelt hva som teller som kunnskap.
> Med politiske og etiske spørsmål er situasjonen annerledes.
  - Finnes det "eksperter" i etikk og politikk?

##### Sokrates' forsvarstale

> Forsvar for hans egen filosofiske praksis.
  - Håndtere uvitenhet i etiske og politiske spørsmål.
  - Utfordre aksepterte sannheter og antatte eksperter.
- Får folk til å bry seg om visdom og dyd.

- "Filosofi" betyr "kjærlighet til visdom".

### Problemet med demokratiet

> Demokratiet i Athen var et direkte folkestyre.

- Embetsmenn og andre verv ble valgt gjennom loddtrekning.
- Alle borgerne var med i folkeforsamlingen og kunne tale, stemme og foreslå lovendringer.

> Moderne demokratier er representative.

- Folk kan stille som representanter og stemme på de som fremmer deres synspunkter.

##### Sokrates kritiserer Athens demokrati fordi:

- Retorikk får en styrende rolle i politikk.
- Politikere kan appellere til folkets emosjoner for å manipulere dem.
- Rykter, heller enn fakta, får bestemme politikken.

> Strukturelt problem:
- De som stemmer har et dårlig eller manglende grunnlag for å ta gode valg.
- De som driver med politikk må late som de er eksperter.

Da blir det mye bullshit.

- Å gjøre seg imponerende er viktigere enn innholdet.

### Rettssaken mot Sokrates

- Rettssaken ble initiert av borgere i Athen.
  - Meletos, Anytos og Lykon anklaget Sokrates på to punkter:
    - For å forderve ungdommen.
    - For å ikke tro på byens guder (ha sine egne guder).

- Sokrates var 70 år gammel da rettssaken fant sted (399 f.Kr.).
- Juryen besto av 501 menn.
  - 280 mot 221 fant ham skyldig.
- Han ble dømt til døden (Fedon, kap. 7).

##### Bakgrunnen

- Sokrates' filosofiske praksis irriterte veldig mange av hans medborgere.
- Sokrates hadde en gruppe som beundret ham som var unge og rike.
  - Noen i Sokrates' krets var blant oligarkene (de 30 tyrannene) som erstattet demokratiet i 404 f.Kr. etter at Athen tapte krigen mot Sparta.
  - Han var også knyttet til Alkibiades, en athensk general som ble landsforræder.

- Sokrates var skeptisk til demokratisk styresett.
- Han snakket om en daimon, en slags samvittighet inni seg som holdt ham tilbake fra å gjøre ting.

- Han ble parodiert i Aristofanes' *Skyene* som en selvgod og absurd intellektuell som driver med ubrukelige knep og retoriske triks.

### Sokratisk elenchus

- Sokrates beskriver sin egen filosofiske praksis som elenchus eller dialektikk og illustrerer den i sin utspørring av Meletos.

  - Finner noen som påberoper seg visdom eksplisitt eller implisitt.
  - Stiller spørsmål som tester om de kan forsvare egen visdom.
  - Samtalepersonene klarer ikke å forsvare sine egne utsagn og ender med å motsi seg selv, si absurde ting eller bli stille.
    - Tilstanden kalles for apori (**ingen utvei**).
  - Samtalepartneren og deres venner blir ofte sure på Sokrates og legger ham for hat.

- I sin utspørring (del 1, s. 144-5) prøver Sokrates å vise at Meletos ikke vet hva han snakker om når han påstår at Sokrates forderver ungdommen.
- Sokrates' strategi er å vise hva slags etisk kunnskap som må ligge bak påstanden om at noen forderver andre.
  - Han spør Meletos om han legger "stor vekt på at de unge skal bli så gode mennesker som mulig" (s. 114).
  - Meletos er nesten tvunget til å si ja.

- De spør Sokrates hvem det er som forbedrer de unge.
  - Det burde Meletos også vite, gitt hans antatte kunnskap om fordervelse og gode mennesker.
    - Meletos tier stille.
  - Da sier han til slutt at alle dommerne, alle rådmennene og alle medlemmer av folkeforsamlingen forbedrer de unge.
    - Det faller på sin egen urimelighet.
    - I alle andre områder er det slik at de færreste ekspertene forbedrer, mens resten forderver.

- Sokrates viser at Meletos ikke vet hva han snakker om når han påstår at Sokrates forderver ungdommen.
- Når det kommer til den andre anklagen (116-117), motsier Meletos seg selv ganske fort.
  - Anklagen hevder at Sokrates tror på andre guder, mens Meletos påstår at han er en gudsfornekter.
- Sokrates har tilbakevist Meletos, men hva så? Klarer sokratisk testing å teste påstander, og ikke bare mennesker? (**Ja**)

- Utfordrer aksepterte etiske sannheter.
  - De aller fleste tenker at det å lide på grunn av urettferdig behandling (å bli banket opp, fratatt eiendom eller rettigheter) er det verste som kan skje.
    - Sokrates, i mange dialoger, tilbakeviser den påstanden.
  - Han argumenterer for at det er bedre for et menneske å bli behandlet urettferdig (å være offer) enn å behandle andre urettferdig (å være gjerningsmann).
    - I forsvarstalen påstår han at Meletos og gjengen hans er ute etter å "få en mann urettferdig dømt til døden" for å skade seg selv mer enn Sokrates.

### Sokrates' visdom

> Hva er vitsen med Sokrates' testing?
 - Samtalepartneren blir ydmyket og folk rundt ham blir irriterte på Sokrates.
 - Han utfordrer antatte sannheter, men overbeviser få eller ingen.

- For å se verden i Sokrates' testing må vi utforske hva slags visdom Sokrates påstår at han har.

Sokrates sier at han har "en slags visdom", det som kalles for "menneskelig visdom".
   - Da han fikk høre at orakelet i Delfi sa at ingen var visere enn ham, forsøkte han å motbevise orakelet.
     - Hvorfor det? Fordi "jeg vet jo selv at jeg ikke er i det minste vis."

   - Hvordan kan den som vet at han ikke er vis, være den viseste?

- Han oppsøkte folk som hadde rykte på seg for å være vise.
  - De var politikere, diktere og håndverkere.
  - Ingen av dem viste seg å være vise.
    - Mange av dem gjorde en typisk feilslutning: det å slutte at man er ualminnelig klok for å være flink i sitt yrke.
- Disse innbilte seg at de var vise, men var ikke det.
  - De hadde "selv-uvitenhet", fordi de ikke var klare over sin egen uvitenhet.

- Sokrates er klar over sin egen uvitenhet.
  - Det setter ham i en bedre epistemisk situasjon, siden sjelen hans er i harmoni med seg selv.
- Slik tolker Sokrates orakelets beskjed.
  - Tre epistemiske kategorier:
    - Guddommelig visdom (Sokrates, erkjennelse av egen uvitenhet).
    - Menneskelig visdom.
    - Menneskelig uvitenhet (alle de andres uvitenhet om egen uvitenhet).

- Hva handler guddommelig visdom om?
   > Handler om dyd, lykke, rettferdighet, mot, osv. — altså de viktige tingene.

- Det med menneskelig visdom er best egnet til å søke etter guddommelig visdom.
- Den med menneskelig uvitenhet vet ikke om guddommelig visdom, fordi han tror at han allerede besitter den.

- Hva er vitsen med sokratisk testing?
  - Sokrates forsøker å forbedre, ikke forderve, de andres sjel, selv om de blir sure.
  - Det som blir tilbakevist er gyldigheten av erfaringen.

- Sokrates "tror at aldri er en større lykke blitt dere i denne by til del enn mitt vitne for guds tjenesten" (s. 119).

- Sokrates oppfordrer sine medborgere til ikke å lære etter penger, eiendom, makt eller nytelse, men "først og fremst å sørge for seg selv, at den skal bli så god som mulig" (s. 119).
  - Henger sammen med ideen om at det er bedre å bli behandlet urettferdig enn å behandle urettferdig.

- Han beskriver seg selv som en bitende flue (hestebremse) som sitter på en træg og lat hest.

### Mot og uvitenhet om døden

- Sokrates' liv er på spill i rettssaken, men han viser seg å være modig.
  - Han sier: "Jeg bryr meg ikke... om døden; men ikke å begå urett og synd, det er målet for hele min stilling" (s. 121).
  - Hvordan henger dette sammen med søken etter visdom?
- Husk at han søker kunnskap om dyd, lykke, mot, rettferdighet.

Å søke etter guddommelig visdom er å søke å bli så god som mulig.

- Det betyr at man alltid forsøker å unngå laster, som urettferdighet, feighet, osv.
- Man kan ikke være redd for døden, selv om man fortsetter å leve.

#### Sokrates' argument
- Å flykte døden forutsetter at døden er en ulykke.
  - Vi vet ikke hvordan det er å være død.
    - det kan være for alt vi vet det støre lykke.
- "å flykte døden... er ikke noe annet enn å synes vis uten å være det" (s. 118)
