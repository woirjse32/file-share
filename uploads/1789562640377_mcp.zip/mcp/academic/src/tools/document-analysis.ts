import { McpServer } from '@modelcontextprotocol/server';
import { z } from 'zod/v4';
import { DocumentAnalyzer } from '../services/document-analyzer.js';
import { ArgumentExtractor } from '../services/argument-extractor.js';
import { log } from '../utils/logger.js';

export function registerDocumentAnalysisTools(
  server: McpServer,
  analyzer: DocumentAnalyzer,
  extractor: ArgumentExtractor
): void {
  server.registerTool(
    'analyze-document',
    {
      title: 'Analyze Document',
      description: 'Analyzes a research document by extracting introduction, conclusion, paragraphs, and arguments',
      inputSchema: z.object({
        text: z.string().describe('The full text of the document to analyze'),
      }),
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    async ({ text }) => {
      try {
        log('Starting document analysis...');

        analyzer.loadDocument(text);

        const introConclusion = analyzer.getIntroAndConclusionAnalysis();
        const paragraphs = analyzer.getParagraphs();
        const firstSentences = analyzer.getParagraphFirstSentences();
        const structure = analyzer.analyzeParagraphStructure();

        const argumentGroups = extractor.extractArguments(
          paragraphs.map(p => p.fullText)
        );
        const argumentsText = extractor.getArgumentsAsText(argumentGroups);

        const analysis = `
## Document Analysis Results

### Introduction
${introConclusion.intro}

### Conclusion
${introConclusion.conclusion}

### Paragraph Structure
- Total paragraphs: ${structure.totalParagraphs}
- Average length: ${Math.round(structure.avgLength)} characters

### Paragraph First Sentences
${structure.structure.map(s => `- ${s}`).join('\n')}

### Arguments Found
${argumentsText}

### Summary
The document contains ${structure.totalParagraphs} paragraphs with ${argumentGroups.length} distinct argument groups. The introduction establishes the topic while the conclusion synthesizes the findings.
`;

        return {
          content: [{ type: 'text', text: analysis }],
        };
      } catch (error) {
        log('Error in analyze-document:', error);
        return {
          content: [{ type: 'text', text: `Error analyzing document: ${error}` }],
          isError: true,
        };
      }
    }
  );
}
