import { McpServer } from '@modelcontextprotocol/server';
import { DocumentAnalyzer } from '../services/document-analyzer.js';
import { ArgumentExtractor } from '../services/argument-extractor.js';
import { BrowserService } from '../services/browser.js';
import { AIDetector } from '../services/ai-detector.js';
import { Humanizer } from '../services/humanizer.js';
import { AcademicWriter } from '../services/academic-writer.js';
import { registerDocumentAnalysisTools } from './document-analysis.js';
import { registerUserInteractionTools } from './user-interaction.js';
import { registerTextRewritingTools } from './text-rewriting.js';

export function registerAllTools(
  server: McpServer,
  analyzer: DocumentAnalyzer,
  extractor: ArgumentExtractor,
  browser: BrowserService,
  detector: AIDetector,
  humanizer: Humanizer,
  writer: AcademicWriter
): void {
  registerDocumentAnalysisTools(server, analyzer, extractor);
  registerUserInteractionTools(server);
  registerTextRewritingTools(server, browser, detector, humanizer, writer);
}
