import { McpServer } from '@modelcontextprotocol/server';
import { z } from 'zod/v4';
import { BrowserService } from '../services/browser.js';
import { AIDetector } from '../services/ai-detector.js';
import { Humanizer } from '../services/humanizer.js';
import { AcademicWriter } from '../services/academic-writer.js';
import { log } from '../utils/logger.js';

export function registerTextRewritingTools(
  server: McpServer,
  browser: BrowserService,
  detector: AIDetector,
  humanizer: Humanizer,
  writer: AcademicWriter
): void {
  server.registerTool(
    'rewrite-humanize',
    {
      title: 'Rewrite and Humanize',
      description: 'Rewrites text to sound more human-like and passes AI detection',
      inputSchema: z.object({
        text: z.string().describe('The text to rewrite and humanize'),
        maxIterations: z.number().int().min(1).max(5).default(3).describe('Maximum number of rewriting iterations'),
      }),
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: false,
      },
    },
    async ({ text, maxIterations }) => {
      try {
        log('Starting text humanization...');

        let currentText = text;
        let iteration = 0;
        let detectionPassed = false;

        while (iteration < maxIterations && !detectionPassed) {
          log(`Iteration ${iteration + 1}/${maxIterations}...`);

          const detectionResult = await detector.checkForAI(currentText);
          log(`Detection result: AI=${detectionResult.isAI}, confidence=${detectionResult.confidence}`);

          if (!detectionResult.isAI) {
            detectionPassed = true;
            break;
          }

          const humanized = humanizer.humanize(currentText, detectionResult.flaggedSentences);
          currentText = humanized.rewritten;
          iteration++;
        }

        const academicCheck = writer.checkAcademicStyle(currentText);

        return {
          content: [
            {
              type: 'text',
              text: `## Humanized Text

### Final Version (after ${iteration} iterations)
${currentText}

### Academic Style Check
- Score: ${academicCheck.score}/100
- Is Academic: ${academicCheck.isAcademic ? 'Yes' : 'No'}
${academicCheck.issues.length > 0 ? `\n### Issues\n${academicCheck.issues.map(i => `- ${i}`).join('\n')}` : ''}
${academicCheck.suggestions.length > 0 ? `\n### Suggestions\n${academicCheck.suggestions.map(s => `- ${s}`).join('\n')}` : ''}
`,
            },
          ],
        };
      } catch (error) {
        log('Error in rewrite-humanize:', error);
        return {
          content: [{ type: 'text', text: `Error rewriting text: ${error}` }],
          isError: true,
        };
      }
    }
  );

  server.registerTool(
    'verify-academic-style',
    {
      title: 'Verify Academic Style',
      description: 'Checks if text follows academic writing conventions',
      inputSchema: z.object({
        text: z.string().describe('The text to verify'),
      }),
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    async ({ text }) => {
      try {
        log('Verifying academic style...');

        const result = writer.checkAcademicStyle(text);
        const enforced = writer.enforceAcademicStyle(text);

        return {
          content: [
            {
              type: 'text',
              text: `## Academic Style Verification

### Current Status
- Score: ${result.score}/100
- Is Academic: ${result.isAcademic ? 'Yes' : 'No'}

${result.issues.length > 0 ? `### Issues Found\n${result.issues.map(i => `- ${i}`).join('\n')}\n\n` : ''}
${result.suggestions.length > 0 ? `### Suggestions\n${result.suggestions.map(s => `- ${s}`).join('\n')}\n\n` : ''}
### Enforced Version
${enforced}
`,
            },
          ],
        };
      } catch (error) {
        log('Error in verify-academic-style:', error);
        return {
          content: [{ type: 'text', text: `Error verifying style: ${error}` }],
          isError: true,
        };
      }
    }
  );
}
