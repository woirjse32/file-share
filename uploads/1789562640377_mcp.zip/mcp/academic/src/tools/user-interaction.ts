import { McpServer } from '@modelcontextprotocol/server';
import { z } from 'zod/v4';
import { log } from '../utils/logger.js';

export function registerUserInteractionTools(server: McpServer): void {
  server.registerTool(
    'ask-user',
    {
      title: 'Ask User Question',
      description: 'Asks the user a question to gather their perspective on the arguments found',
      inputSchema: z.object({
        question: z.string().describe('The question to ask the user'),
        context: z.string().optional().describe('Additional context about why this question is being asked'),
        options: z.array(z.string()).optional().describe('Multiple choice options if applicable'),
      }),
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: true,
      },
    },
    async ({ question, context, options }) => {
      try {
        log('Asking user question...');

        let prompt = question;
        if (context) {
          prompt = `${context}\n\n${question}`;
        }
        if (options && options.length > 0) {
          prompt += `\n\nOptions:\n${options.map((opt, i) => `${i + 1}. ${opt}`).join('\n')}`;
        }

        return {
          content: [
            {
              type: 'text',
              text: `USER_QUESTION: ${prompt}\n\nPlease respond to this question so I can incorporate your perspective into the academic text.`,
            },
          ],
        };
      } catch (error) {
        log('Error in ask-user:', error);
        return {
          content: [{ type: 'text', text: `Error asking question: ${error}` }],
          isError: true,
        };
      }
    }
  );
}
