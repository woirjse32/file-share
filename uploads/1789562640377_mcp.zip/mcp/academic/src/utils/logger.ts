export function log(message: string, ...args: unknown[]): void {
  console.error(`[Academic MCP] ${message}`, ...args);
}

export function logError(message: string, error: unknown): void {
  console.error(`[Academic MCP ERROR] ${message}`, error);
}

export function logWarning(message: string, ...args: unknown[]): void {
  console.error(`[Academic MCP WARNING] ${message}`, ...args);
}
