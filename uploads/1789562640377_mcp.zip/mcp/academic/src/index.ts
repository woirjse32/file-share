import { StdioServerTransport } from '@modelcontextprotocol/server/stdio';
import { createServer } from './server.js';
import { closeBrowserService } from './services/browser.js';
import { log, logError } from './utils/logger.js';

async function main(): Promise<void> {
  try {
    log('Starting Academic MCP Server...');

    const server = await createServer();
    const transport = new StdioServerTransport();

    await server.connect(transport);

    log('Academic MCP Server running on stdio');

    process.on('SIGINT', async () => {
      log('Shutting down...');
      await closeBrowserService();
      process.exit(0);
    });

    process.on('SIGTERM', async () => {
      log('Shutting down...');
      await closeBrowserService();
      process.exit(0);
    });

  } catch (error) {
    logError('Fatal error in main():', error);
    await closeBrowserService();
    process.exit(1);
  }
}

main();
