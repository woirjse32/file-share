import { McpServer } from '@modelcontextprotocol/server';
import { DocumentAnalyzer } from './services/document-analyzer.js';
import { ArgumentExtractor } from './services/argument-extractor.js';
import { BrowserService, getBrowserService } from './services/browser.js';
import { AIDetector } from './services/ai-detector.js';
import { Humanizer } from './services/humanizer.js';
import { AcademicWriter } from './services/academic-writer.js';
import { registerAllTools } from './tools/index.js';
import { log } from './utils/logger.js';

export async function createServer(): Promise<McpServer> {
  log('Initializing Academic MCP Server...');

  const server = new McpServer({
    name: 'academic-mcp-server',
    version: '1.0.0',
  });

  const analyzer = new DocumentAnalyzer();
  const extractor = new ArgumentExtractor();
  const browser = await getBrowserService();
  const detector = new AIDetector(browser);
  const humanizer = new Humanizer();
  const writer = new AcademicWriter();

  registerAllTools(server, analyzer, extractor, browser, detector, humanizer, writer);

  log('Academic MCP Server initialized');

  return server;
}
