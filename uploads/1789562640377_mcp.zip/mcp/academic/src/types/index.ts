export interface Paragraph {
  index: number;
  firstSentence: string;
  fullText: string;
}

export interface Argument {
  id: string;
  type: 'premise' | 'conclusion';
  text: string;
  confidence: number;
}

export interface ArgumentGroup {
  id: string;
  premises: Argument[];
  conclusion: Argument;
  strength: 'strong' | 'moderate' | 'weak';
}

export interface DocumentAnalysis {
  introduction: string;
  conclusion: string;
  paragraphs: Paragraph[];
  arguments: ArgumentGroup[];
  summary: string;
}

export interface AIDetectionResult {
  isAI: boolean;
  confidence: number;
  flaggedSentences: string[];
  rawResponse: string;
}

export interface HumanizedText {
  original: string;
  rewritten: string;
  changes: string[];
  passesDetection: boolean;
}

export interface AcademicStyleCheck {
  isAcademic: boolean;
  issues: string[];
  suggestions: string[];
  score: number;
}

export interface BrowserConfig {
  headless: boolean;
  executablePath?: string;
  userDataDir?: string;
  protocolTimeout: number;
}

export interface PageResult {
  url: string;
  content: string;
  title: string;
}
