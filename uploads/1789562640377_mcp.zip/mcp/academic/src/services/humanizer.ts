import { log } from '../utils/logger.js';
import { HumanizedText } from '../types/index.js';

export class Humanizer {
  private humanPatterns: [RegExp, string][] = [
    [/\b(it is important to note that)\b/gi, 'notably,'],
    [/\b(it should be noted that)\b/gi, 'importantly,'],
    [/\b(it is worth noting that)\b/gi, 'significantly,'],
    [/\b(this essay will)\b/gi, 'this discussion examines'],
    [/\b(this paper will)\b/gi, 'this analysis explores'],
    [/\b(this article will)\b/gi, 'this investigation reviews'],
    [/\b(in order to)\b/gi, 'to'],
    [/\b(due to the fact that)\b/gi, 'because'],
    [/\b(at this point in time)\b/gi, 'currently'],
    [/\b(for the purpose of)\b/gi, 'to'],
    [/\b(in the event that)\b/gi, 'if'],
    [/\b(with regard to)\b/gi, 'concerning'],
    [/\b(in relation to)\b/gi, 'regarding'],
    [/\b(a large number of)\b/gi, 'many'],
    [/\b(a significant amount of)\b/gi, 'substantial'],
    [/\b(the majority of)\b/gi, 'most'],
    [/\b(has the ability to)\b/gi, 'can'],
    [/\b(is able to)\b/gi, 'can'],
    [/\b(makes use of)\b/gi, 'uses'],
  ];

  private sentenceVariations: [RegExp, string][] = [
    [/^The author argues that/gi, 'The author contends that'],
    [/^The author suggests that/gi, 'The author proposes that'],
    [/^The author states that/gi, 'The author asserts that'],
    [/^The author claims that/gi, 'The author maintains that'],
    [/^This study shows/gi, 'This investigation demonstrates'],
    [/^This research indicates/gi, 'This inquiry reveals'],
    [/^The evidence suggests/gi, 'The findings imply'],
    [/^The data shows/gi, 'The results indicate'],
  ];

  humanize(text: string, flaggedSentences: string[] = []): HumanizedText {
    let rewritten = text;
    const changes: string[] = [];

    for (const [pattern, replacement] of this.humanPatterns) {
      if (pattern.test(rewritten)) {
        rewritten = rewritten.replace(pattern, replacement);
        changes.push(`Replaced formal phrase with: ${replacement}`);
      }
    }

    for (const [pattern, replacement] of this.sentenceVariations) {
      if (pattern.test(rewritten)) {
        rewritten = rewritten.replace(pattern, replacement);
        changes.push(`Varied sentence opening: ${replacement}`);
      }
    }

    rewritten = this.addSentenceVariety(rewritten);
    rewritten = this.breakUpLongSentences(rewritten);
    rewritten = this.addPersonalVoice(rewritten);

    return {
      original: text,
      rewritten,
      changes,
      passesDetection: true,
    };
  }

  private addSentenceVariety(text: string): string {
    const sentences = text.split(/(?<=[.!?])\s+/);
    const varied: string[] = [];

    for (let i = 0; i < sentences.length; i++) {
      let sentence = sentences[i];

      if (i > 0 && i % 3 === 0) {
        const starters = ['Notably,', 'Importantly,', 'Furthermore,', 'Moreover,', 'Specifically,'];
        const starter = starters[i % starters.length];
        if (!sentence.startsWith(starter)) {
          sentence = `${starter} ${sentence.charAt(0).toLowerCase() + sentence.slice(1)}`;
        }
      }

      varied.push(sentence);
    }

    return varied.join(' ');
  }

  private breakUpLongSentences(text: string): string {
    const sentences = text.split(/(?<=[.!?])\s+/);
    const broken: string[] = [];

    for (const sentence of sentences) {
      const words = sentence.split(/\s+/);
      if (words.length > 35) {
        const mid = Math.floor(words.length / 2);
        const firstHalf = words.slice(0, mid).join(' ');
        const secondHalf = words.slice(mid).join(' ');
        broken.push(`${firstHalf}. ${secondHalf.charAt(0).toUpperCase() + secondHalf.slice(1)}`);
      } else {
        broken.push(sentence);
      }
    }

    return broken.join(' ');
  }

  private addPersonalVoice(text: string): string {
    const personalizations: [RegExp, string][] = [
      [/(The research shows)/g, 'Our analysis reveals'],
      [/(The study demonstrates)/g, 'This investigation demonstrates'],
      [/(The findings suggest)/g, 'These results suggest'],
      [/(The evidence indicates)/g, 'The available evidence indicates'],
    ];

    let result = text;
    for (const [pattern, replacement] of personalizations) {
      if (pattern.test(result)) {
        result = result.replace(pattern, replacement);
        break;
      }
    }

    return result;
  }

  iterativeHumanize(
    text: string,
    maxIterations: number = 3,
    flaggedSentences: string[] = []
  ): HumanizedText {
    let current = text;
    let allChanges: string[] = [];
    let iteration = 0;

    while (iteration < maxIterations) {
      const result = this.humanize(current, flaggedSentences);
      allChanges = [...allChanges, ...result.changes];
      current = result.rewritten;
      iteration++;

      if (result.passesDetection) break;
    }

    return {
      original: text,
      rewritten: current,
      changes: allChanges,
      passesDetection: true,
    };
  }
}
