import { log, logError } from '../utils/logger.js';
import { Paragraph } from '../types/index.js';

export class DocumentAnalyzer {
  private document: string = '';
  private paragraphs: string[] = [];

  loadDocument(text: string): void {
    this.document = text;
    this.paragraphs = this.splitIntoParagraphs(text);
    log(`Document loaded: ${this.paragraphs.length} paragraphs found`);
  }

  private splitIntoParagraphs(text: string): string[] {
    return text
      .split(/\n\s*\n/)
      .map(p => p.trim())
      .filter(p => p.length > 0);
  }

  getIntroduction(): string {
    if (this.paragraphs.length === 0) {
      throw new Error('No document loaded');
    }
    return this.paragraphs[0];
  }

  getConclusion(): string {
    if (this.paragraphs.length < 2) {
      throw new Error('Document must have at least 2 paragraphs');
    }
    return this.paragraphs[this.paragraphs.length - 1];
  }

  getParagraphs(): Paragraph[] {
    return this.paragraphs.map((text, index) => ({
      index,
      firstSentence: this.extractFirstSentence(text),
      fullText: text,
    }));
  }

  private extractFirstSentence(paragraph: string): string {
    const sentenceEnd = /[.!?]\s*/;
    const match = paragraph.match(sentenceEnd);
    if (match && match.index !== undefined) {
      return paragraph.substring(0, match.index + 1).trim();
    }
    return paragraph.split('\n')[0].trim();
  }

  getIntroAndConclusionAnalysis(): { intro: string; conclusion: string } {
    return {
      intro: this.getIntroduction(),
      conclusion: this.getConclusion(),
    };
  }

  getParagraphFirstSentences(): string[] {
    return this.getParagraphs().map(p => p.firstSentence);
  }

  analyzeParagraphStructure(): {
    totalParagraphs: number;
    avgLength: number;
    structure: string[];
  } {
    const lengths = this.paragraphs.map(p => p.length);
    const avgLength = lengths.reduce((a, b) => a + b, 0) / lengths.length;

    return {
      totalParagraphs: this.paragraphs.length,
      avgLength,
      structure: this.getParagraphs().map(p => `[${p.index}] ${p.firstSentence}`),
    };
  }
}
