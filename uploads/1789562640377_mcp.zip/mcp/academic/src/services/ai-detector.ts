import { log, logError, logWarning } from '../utils/logger.js';
import { BrowserService } from './browser.js';
import { AIDetectionResult } from '../types/index.js';

export class AIDetector {
  private browser: BrowserService;
  private detectionSites = [
    'https://www.zerogpt.com',
    'https://www.gptzero.me',
  ];

  constructor(browser: BrowserService) {
    this.browser = browser;
  }

  async checkForAI(text: string): Promise<AIDetectionResult> {
    for (const site of this.detectionSites) {
      try {
        const result = await this.checkWithSite(text, site);
        if (result) return result;
      } catch (error) {
        logWarning(`Failed to check with ${site}, trying next...`);
      }
    }

    logWarning('All AI detection sites failed, using fallback analysis');
    return this.fallbackAnalysis(text);
  }

  private async checkWithSite(text: string, url: string): Promise<AIDetectionResult | null> {
    const page = await this.browser.getPage();
    try {
      log(`Navigating to ${url}...`);
      await this.browser.navigateTo(page, url, 30000);

      const textareaSelector = 'textarea, [contenteditable="true"], input[type="text"]';
      await this.browser.fillFormField(page, textareaSelector, text);

      const submitSelector = 'button[type="submit"], .submit-btn, #submit, button:has-text("Check"), button:has-text("Detect")';
      await this.browser.clickElement(page, submitSelector);

      await this.browser.waitForNavigation(page, 30000);

      await new Promise(resolve => setTimeout(resolve, 5000));

      const resultText = await this.browser.evaluateWithTimeout(
        page,
        () => document.body.innerText,
        10000
      );

      return this.parseDetectionResult(resultText, url);
    } catch (error) {
      logError(`Error checking with ${url}`, error);
      return null;
    } finally {
      await this.browser.closePage(page);
    }
  }

  private parseDetectionResult(text: string, source: string): AIDetectionResult {
    const aiPatterns = [
      /(\d+(?:\.\d+)?)\s*%\s*(?:AI|artificial intelligence|generated)/i,
      /AI\s*(?:probability|likelihood|score)[:\s]*(\d+(?:\.\d+)?)\s*%/i,
      /probability[:\s]*(\d+(?:\.\d+)?)\s*%/i,
    ];

    let confidence = 0;
    for (const pattern of aiPatterns) {
      const match = text.match(pattern);
      if (match) {
        confidence = parseFloat(match[1]) / 100;
        break;
      }
    }

    const flaggedSentences: string[] = [];
    const sentencePattern = /(?:This sentence|The following|appears to be)\s+(?:AI|generated|artificial)[^.]*\./gi;
    const matches = text.match(sentencePattern);
    if (matches) {
      flaggedSentences.push(...matches);
    }

    return {
      isAI: confidence > 0.5,
      confidence,
      flaggedSentences,
      rawResponse: text,
    };
  }

  private fallbackAnalysis(text: string): AIDetectionResult {
    const aiIndicators = [
      /\b(furthermore|moreover|additionally|consequently|therefore)\b/gi,
      /\b(it is important to note|it is worth noting|it should be noted)\b/gi,
      /\b(in conclusion|to summarize|in summary)\b/gi,
      /\b(this essay|this paper|this article)\b/gi,
    ];

    let indicatorCount = 0;
    for (const pattern of aiIndicators) {
      const matches = text.match(pattern);
      if (matches) indicatorCount += matches.length;
    }

    const wordCount = text.split(/\s+/).length;
    const density = indicatorCount / (wordCount / 100);

    return {
      isAI: density > 2,
      confidence: Math.min(density / 5, 1),
      flaggedSentences: [],
      rawResponse: `Fallback analysis: ${indicatorCount} AI indicators found in ${wordCount} words`,
    };
  }
}
