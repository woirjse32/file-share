import { log } from '../utils/logger.js';
import { Argument, ArgumentGroup } from '../types/index.js';

export class ArgumentExtractor {
  private premisePatterns = [
    /because/i,
    /since/i,
    /given that/i,
    /as shown by/i,
    /according to/i,
    /evidence suggests/i,
    /research indicates/i,
    /studies show/i,
    /it is known that/i,
    /due to/i,
    /considering/i,
    /in light of/i,
    /based on/i,
  ];

  private conclusionPatterns = [
    /therefore/i,
    /thus/i,
    /consequently/i,
    /hence/i,
    /it follows that/i,
    /we can conclude/i,
    /this suggests/i,
    /this implies/i,
    /as a result/i,
    /accordingly/i,
    /in conclusion/i,
    /to summarize/i,
  ];

  extractArguments(paragraphs: string[]): ArgumentGroup[] {
    const groups: ArgumentGroup[] = [];
    let groupId = 1;

    for (const paragraph of paragraphs) {
      const sentences = this.splitIntoSentences(paragraph);
      const premises: Argument[] = [];
      const conclusions: Argument[] = [];

      for (const sentence of sentences) {
        const arg = this.classifySentence(sentence, `arg-${groupId}-${premises.length + conclusions.length + 1}`);
        if (arg.type === 'premise') {
          premises.push(arg);
        } else if (arg.type === 'conclusion') {
          conclusions.push(arg);
        }
      }

      if (premises.length > 0 && conclusions.length > 0) {
        for (const conclusion of conclusions) {
          groups.push({
            id: `group-${groupId}`,
            premises,
            conclusion,
            strength: this.evaluateStrength(premises, conclusion),
          });
          groupId++;
        }
      }
    }

    log(`Extracted ${groups.length} argument groups`);
    return groups;
  }

  private splitIntoSentences(text: string): string[] {
    const sentenceEnd = /(?<=[.!?])\s+/;
    return text
      .split(sentenceEnd)
      .map(s => s.trim())
      .filter(s => s.length > 10);
  }

  private classifySentence(sentence: string, id: string): Argument {
    const premiseScore = this.premisePatterns.reduce(
      (score, pattern) => (pattern.test(sentence) ? score + 1 : score),
      0
    );

    const conclusionScore = this.conclusionPatterns.reduce(
      (score, pattern) => (pattern.test(sentence) ? score + 1 : score),
      0
    );

    if (conclusionScore > premiseScore) {
      return {
        id,
        type: 'conclusion',
        text: sentence,
        confidence: Math.min(conclusionScore / 3, 1),
      };
    } else if (premiseScore > 0) {
      return {
        id,
        type: 'premise',
        text: sentence,
        confidence: Math.min(premiseScore / 3, 1),
      };
    }

    return {
      id,
      type: 'premise',
      text: sentence,
      confidence: 0.3,
    };
  }

  private evaluateStrength(premises: Argument[], conclusion: Argument): 'strong' | 'moderate' | 'weak' {
    const avgConfidence =
      premises.reduce((sum, p) => sum + p.confidence, 0) / premises.length;

    if (avgConfidence > 0.7 && premises.length >= 2) {
      return 'strong';
    } else if (avgConfidence > 0.4 || premises.length >= 2) {
      return 'moderate';
    }
    return 'weak';
  }

  getArgumentsAsText(groups: ArgumentGroup[]): string {
    return groups
      .map((group, i) => {
        const premisesText = group.premises.map(p => `  - ${p.text}`).join('\n');
        return `Argument ${i + 1} (${group.strength}):\nPremises:\n${premisesText}\nConclusion: ${group.conclusion.text}`;
      })
      .join('\n\n');
  }
}
