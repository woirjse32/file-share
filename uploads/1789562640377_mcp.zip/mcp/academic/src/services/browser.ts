import puppeteer, { Browser, Page } from 'puppeteer-core';
import { log, logError, logWarning } from '../utils/logger.js';
import { BrowserConfig, PageResult } from '../types/index.js';

const DEFAULT_CONFIG: BrowserConfig = {
  headless: true,
  protocolTimeout: 600000,
};

export class BrowserService {
  private browser: Browser | null = null;
  private config: BrowserConfig;
  private reconnectionAttempts = 0;
  private maxReconnectionAttempts = 3;

  constructor(config: Partial<BrowserConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  async launch(): Promise<void> {
    try {
      log('Launching browser...');
      this.browser = await puppeteer.launch({
        headless: this.config.headless,
        executablePath: this.config.executablePath,
        userDataDir: this.config.userDataDir,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--no-first-run',
          '--no-zygote',
          '--disable-gpu',
        ],
      });
      this.browser.on('disconnected', () => this.handleDisconnect());
      log('Browser launched successfully');
    } catch (error) {
      logError('Failed to launch browser', error);
      throw error;
    }
  }

  async ensureBrowser(): Promise<Browser> {
    if (!this.browser || !this.browser.connected) {
      if (this.reconnectionAttempts < this.maxReconnectionAttempts) {
        this.reconnectionAttempts++;
        log(`Attempting reconnection (${this.reconnectionAttempts}/${this.maxReconnectionAttempts})...`);
        await this.launch();
      } else {
        throw new Error('Failed to reconnect to browser after maximum attempts');
      }
    }
    this.reconnectionAttempts = 0;
    return this.browser!;
  }

  async getPage(): Promise<Page> {
    const browser = await this.ensureBrowser();
    const page = await browser.newPage();

    page.setDefaultTimeout(30000);
    page.setDefaultNavigationTimeout(60000);

    await page.setViewport({ width: 1920, height: 1080 });

    return page;
  }

  async navigateTo(page: Page, url: string, timeout = 60000): Promise<void> {
    try {
      await page.goto(url, {
        waitUntil: 'networkidle2',
        timeout,
      });
    } catch (error) {
      logError(`Navigation failed for ${url}`, error);
      throw error;
    }
  }

  async getPageContent(page: Page): Promise<PageResult> {
    try {
      const url = page.url();
      const title = await page.title();
      const content = await page.evaluate(() => document.body.innerText);
      return { url, content, title };
    } catch (error) {
      logError('Failed to get page content', error);
      throw error;
    }
  }

  async fillFormField(page: Page, selector: string, value: string): Promise<void> {
    try {
      await page.waitForSelector(selector, { visible: true });
      await page.type(selector, value);
    } catch (error) {
      logError(`Failed to fill form field: ${selector}`, error);
      throw error;
    }
  }

  async clickElement(page: Page, selector: string): Promise<void> {
    try {
      await page.waitForSelector(selector, { visible: true });
      await page.click(selector);
    } catch (error) {
      logError(`Failed to click element: ${selector}`, error);
      throw error;
    }
  }

  async waitForNavigation(page: Page, timeout = 30000): Promise<void> {
    try {
      await page.waitForNavigation({
        waitUntil: 'networkidle2',
        timeout,
      });
    } catch (error) {
      logWarning('Navigation wait timed out, continuing...');
    }
  }

  async evaluateWithTimeout<T>(
    page: Page,
    fn: () => T,
    timeout = 30000
  ): Promise<T> {
    return Promise.race([
      page.evaluate(fn),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('Evaluation timeout')), timeout)
      ),
    ]);
  }

  async closePage(page: Page): Promise<void> {
    try {
      if (page && !page.isClosed()) {
        await page.close();
      }
    } catch (error) {
      logWarning('Failed to close page', error);
    }
  }

  async close(): Promise<void> {
    try {
      if (this.browser) {
        await this.browser.close();
        this.browser = null;
        log('Browser closed');
      }
    } catch (error) {
      logWarning('Failed to close browser', error);
    }
  }

  private async handleDisconnect(): Promise<void> {
    logWarning('Browser disconnected');
    this.browser = null;
  }
}

let browserInstance: BrowserService | null = null;

export async function getBrowserService(): Promise<BrowserService> {
  if (!browserInstance) {
    browserInstance = new BrowserService();
    await browserInstance.launch();
  }
  return browserInstance;
}

export async function closeBrowserService(): Promise<void> {
  if (browserInstance) {
    await browserInstance.close();
    browserInstance = null;
  }
}
