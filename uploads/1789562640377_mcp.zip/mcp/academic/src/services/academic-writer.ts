import { log } from '../utils/logger.js';
import { AcademicStyleCheck } from '../types/index.js';

export class AcademicWriter {
  private formalTransitions = [
    'furthermore',
    'moreover',
    'additionally',
    'consequently',
    'therefore',
    'however',
    'nevertheless',
    'nonetheless',
    'in contrast',
    'similarly',
    'likewise',
    'conversely',
    'specifically',
    'particularly',
    'notably',
    'significantly',
  ];

  private informalPatterns = [
    /\b(gonna|wanna|gotta|kinda|sorta)\b/i,
    /\b(stuff|things|a lot)\b/i,
    /\b(very|really|totally|absolutely)\b/i,
    /\b(I think|I believe|in my opinion)\b/i,
    /\b(you know|like|basically|actually)\b/i,
    /[!]{2,}/,
    /\.{4,}/,
  ];

  checkAcademicStyle(text: string): AcademicStyleCheck {
    const issues: string[] = [];
    const suggestions: string[] = [];
    let score = 100;

    for (const pattern of this.informalPatterns) {
      if (pattern.test(text)) {
        issues.push(`Found informal language: ${pattern.source}`);
        score -= 10;
      }
    }

    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const avgSentenceLength = sentences.reduce((sum, s) => sum + s.split(/\s+/).length, 0) / sentences.length;

    if (avgSentenceLength < 15) {
      suggestions.push('Consider longer, more complex sentences for academic writing');
      score -= 5;
    }

    if (avgSentenceLength > 40) {
      suggestions.push('Some sentences may be too long; consider breaking them up');
      score -= 5;
    }

    const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim().length > 0);
    if (paragraphs.length < 3) {
      suggestions.push('Academic writing typically has more paragraphs');
      score -= 5;
    }

    const hasCitations = /\([\w\s,]+(?:\d{4})\)/.test(text);
    if (!hasCitations) {
      suggestions.push('Consider adding academic citations');
      score -= 10;
    }

    const hasTransitionWords = this.formalTransitions.some(t => 
      text.toLowerCase().includes(t)
    );
    if (!hasTransitionWords) {
      suggestions.push('Add more transition words for better flow');
      score -= 5;
    }

    return {
      isAcademic: score >= 70,
      issues,
      suggestions,
      score: Math.max(0, score),
    };
  }

  enforceAcademicStyle(text: string): string {
    let enforced = text;

    enforced = this.replaceInformalLanguage(enforced);
    enforced = this.addTransitionWords(enforced);
    enforced = this.formalizeStructure(enforced);

    return enforced;
  }

  private replaceInformalLanguage(text: string): string {
    const replacements: [RegExp, string][] = [
      [/\b(gonna)\b/gi, 'going to'],
      [/\b(wanna)\b/gi, 'want to'],
      [/\b(gotta)\b/gi, 'must'],
      [/\b(kinda)\b/gi, 'somewhat'],
      [/\b(sorta)\b/gi, 'rather'],
      [/\b(stuff)\b/gi, 'elements'],
      [/\b(things)\b/gi, 'factors'],
      [/\b(a lot)\b/gi, 'significantly'],
      [/\b(very)\b/gi, 'considerably'],
      [/\b(really)\b/gi, 'truly'],
      [/\b(totally)\b/gi, 'entirely'],
      [/\b(absolutely)\b/gi, 'completely'],
      [/\b(I think)\b/gi, 'it is suggested that'],
      [/\b(I believe)\b/gi, 'it is argued that'],
      [/\b(in my opinion)\b/gi, 'it is proposed that'],
      [/\b(you know)\b/gi, ''],
      [/\b(basically)\b/gi, 'fundamentally'],
      [/\b(actually)\b/gi, 'in fact'],
    ];

    let result = text;
    for (const [pattern, replacement] of replacements) {
      result = result.replace(pattern, replacement);
    }
    return result;
  }

  private addTransitionWords(text: string): string {
    const paragraphs = text.split(/\n\s*\n/);
    if (paragraphs.length < 2) return text;

    const enhanced = [paragraphs[0]];
    for (let i = 1; i < paragraphs.length; i++) {
      const transition = this.formalTransitions[i % this.formalTransitions.length];
      enhanced.push(`${transition.charAt(0).toUpperCase() + transition.slice(1)}, ${paragraphs[i].toLowerCase()}`);
    }
    return enhanced.join('\n\n');
  }

  private formalizeStructure(text: string): string {
    let result = text;
    result = result.replace(/\n{3,}/g, '\n\n');
    result = result.replace(/\s+/g, ' ');
    return result.trim();
  }

  generateAcademicOutput(
    analysis: string,
    arguments_: string,
    userPerspective: string
  ): string {
    return `Based on the analysis of the introduction and conclusion, the following key points emerge:

${analysis}

The argument structure reveals:

${arguments_}

Incorporating the perspective that ${userPerspective}, the text demonstrates a cohesive academic approach that synthesizes these elements into a unified scholarly discourse.

The analysis confirms that the arguments presented maintain logical consistency while supporting the central thesis. Each premise contributes substantively to the overall conclusion, establishing a robust framework for academic inquiry.`;
  }
}
