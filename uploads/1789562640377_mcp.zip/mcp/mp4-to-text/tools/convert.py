import os
import subprocess
import shutil
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


def _find_ffmpeg() -> str:
    """Find ffmpeg binary path."""
    custom_path = os.getenv("FFMPEG_PATH", "")
    if custom_path and os.path.isfile(custom_path):
        return custom_path

    found = shutil.which("ffmpeg")
    if found:
        return found

    raise FileNotFoundError(
        "ffmpeg not found. Install it with: winget install ffmpeg\n"
        "Or set FFMPEG_PATH in .env to the full path of ffmpeg.exe"
    )


def convert_mp4_to_mp3(mp4_path: str, output_path: str | None = None) -> str:
    """Convert an MP4 file to MP3 by extracting the audio stream.

    Args:
        mp4_path: Path to the input MP4 file.
        output_path: Optional path for the output MP3 file.
            If not provided, creates an MP3 with the same name in the output directory.

    Returns:
        Path to the created MP3 file.
    """
    mp4_file = Path(mp4_path)
    if not mp4_file.exists():
        raise FileNotFoundError(f"MP4 file not found: {mp4_path}")
    if not mp4_file.suffix.lower() in (".mp4", ".mkv", ".avi", ".mov", ".webm"):
        raise ValueError(f"Not a supported video format: {mp4_file.suffix}")

    ffmpeg = _find_ffmpeg()

    if output_path is None:
        output_dir = Path(os.getenv("OUTPUT_DIR", "./output"))
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(output_dir / mp4_file.with_suffix(".mp3").name)

    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        ffmpeg,
        "-i", str(mp4_file),
        "-vn",
        "-acodec", "libmp3lame",
        "-ab", "192k",
        "-ar", "44100",
        "-y",
        str(output_file),
    ]

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=300,
    )

    if result.returncode != 0:
        raise RuntimeError(f"ffmpeg failed:\n{result.stderr}")

    if not output_file.exists():
        raise RuntimeError("Conversion completed but output file was not created")

    return str(output_file.resolve())
