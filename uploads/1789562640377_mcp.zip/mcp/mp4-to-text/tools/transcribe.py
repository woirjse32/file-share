import os
from pathlib import Path
from faster_whisper import WhisperModel
from dotenv import load_dotenv

load_dotenv()

_model: WhisperModel | None = None


def _get_model() -> WhisperModel:
    """Load or return cached Whisper model."""
    global _model
    if _model is None:
        model_name = os.getenv("WHISPER_MODEL", "large-v3")
        device = os.getenv("WHISPER_DEVICE", "cuda")
        compute_type = os.getenv("WHISPER_COMPUTE_TYPE", "int8")

        _model = WhisperModel(
            model_name,
            device=device,
            compute_type=compute_type,
            download_root=str(Path("./models").resolve()),
        )
    return _model


def transcribe_audio(
    file_path: str,
    language: str | None = None,
    beam_size: int = 5,
) -> dict:
    """Transcribe an audio file to text.

    Supports MP3, WAV, FLAC, OGG, M4A, AAC, WMA.
    For video files (MP4, MKV, etc.), convert to MP3 first using tools.convert.

    Args:
        file_path: Path to the audio or video file.
        language: Optional language code (e.g. 'en', 'es', 'fr').
            If not specified, auto-detects.
        beam_size: Beam size for decoding (higher = more accurate, slower).
            Default 5 for maximum accuracy.

    Returns:
        Dictionary with 'text', 'segments', and 'language'.
    """
    input_file = Path(file_path)
    if not input_file.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    supported_audio = {".mp3", ".wav", ".flac", ".ogg", ".m4a", ".aac", ".wma"}
    supported_video = {".mp4", ".mkv", ".avi", ".mov", ".webm"}
    all_supported = supported_audio | supported_video

    if input_file.suffix.lower() not in all_supported:
        raise ValueError(
            f"Unsupported format: {input_file.suffix}. "
            f"Supported: {', '.join(sorted(all_supported))}"
        )

    model = _get_model()

    segments_iter, info = model.transcribe(
        str(input_file),
        language=language,
        beam_size=beam_size,
        vad_filter=True,
        vad_parameters=dict(
            min_silence_duration_ms=500,
            speech_pad_ms=200,
        ),
    )

    segments = []
    full_text_parts = []
    for segment in segments_iter:
        segments.append({
            "start": round(segment.start, 2),
            "end": round(segment.end, 2),
            "text": segment.text.strip(),
        })
        full_text_parts.append(segment.text.strip())

    return {
        "text": " ".join(full_text_parts),
        "segments": segments,
        "language": info.language,
        "language_probability": round(info.language_probability, 4),
        "duration": round(info.duration, 2),
        "file": str(input_file.resolve()),
    }
