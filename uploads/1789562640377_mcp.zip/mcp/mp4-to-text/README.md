# mp4-to-text

MCP server that converts MP4/MP3 files to text using local speech-to-text models. Designed to be used as an MCP tool by AI agents (e.g., opencode).

## Requirements

- Python 3.10+
- NVIDIA GPU with CUDA support (required for `large-v3` model)
- ffmpeg (for MP4 to MP3 conversion)
- ~10 GB VRAM for `large-v3` model (or ~3 GB with INT8 quantization)

## Setup

### 1. Install ffmpeg

```powershell
winget install ffmpeg
```

Or download from https://ffmpeg.org/download.html and add to PATH.

### 2. Install Python dependencies

```powershell
cd C:\Users\aleks\Downloads\mcp\mp4-to-text
pip install -e .
```

Or run the setup script:

```powershell
.\setup.ps1
```

### 3. Configure (optional)

Edit `.env` to change settings:

```env
WHISPER_MODEL=large-v3      # Model size (tiny/base/small/medium/large-v3/large-v3-turbo)
WHISPER_DEVICE=cuda         # Device (cuda/cpu)
WHISPER_COMPUTE_TYPE=int8   # Quantization (int8/float16/float32)
FFMPEG_PATH=                # Leave empty to auto-detect
OUTPUT_DIR=./output         # Where converted MP3s are saved
```

### 4. First run

```powershell
python server.py
```

On first run, the Whisper model (~3 GB for large-v3) will be downloaded to `./models/`. Subsequent runs use the cached copy.

## MCP Tools

| Tool | Description |
|------|-------------|
| `transcribe(file_path, language?, beam_size?)` | Transcribe MP3 or MP4 to text |
| `convert(mp4_path, output_path?)` | Convert MP4 to MP3 audio extraction |
| `list_models()` | List available Whisper model sizes |

### Usage examples

**Transcribe an MP3:**
```json
{
  "file_path": "C:/path/to/audio.mp3"
}
```

**Transcribe an MP4 (auto-converts to MP3 first):**
```json
{
  "file_path": "C:/path/to/video.mp4"
}
```

**Transcribe in a specific language:**
```json
{
  "file_path": "C:/path/to/audio.mp3",
  "language": "es"
}
```

**Convert MP4 to MP3:**
```json
{
  "mp4_path": "C:/path/to/video.mp4"
}
```

## opencode Integration

Add to `.opencode/opencode.json`:

```json
{
  "mcpServers": {
    "mp4-to-text": {
      "command": "python",
      "args": ["C:\\Users\\aleks\\Downloads\\mcp\\mp4-to-text\\server.py"]
    }
  }
}
```

## Model Options

| Model | Parameters | WER | Speed | Notes |
|-------|-----------|-----|-------|-------|
| tiny | 39M | ~15% | Very fast | Poor accuracy |
| base | 74M | ~10% | Fast | Decent accuracy |
| small | 244M | ~8% | Moderate | Good balance |
| medium | 769M | ~6% | Slow | High accuracy |
| **large-v3** | **1.55B** | **~7.4%** | **Slowest** | **Maximum accuracy (default)** |
| large-v3-turbo | 809M | ~7.75% | 2x faster | Near-max accuracy |
| distil-large-v3 | 756M | ~7.4% | 5-6x faster | English-only |

Change model by editing `WHISPER_MODEL` in `.env`.

## Supported Formats

**Audio:** MP3, WAV, FLAC, OGG, M4A, AAC, WMA

**Video:** MP4, MKV, AVI, MOV, WEBM (audio extracted automatically)

## Project Structure

```
mp4-to-text/
├── .env                  # Configuration
├── pyproject.toml        # Dependencies
├── server.py             # MCP server entry point
├── setup.ps1             # Windows setup script
├── models/               # Whisper models (auto-downloaded)
├── output/               # Converted MP3 files
└── tools/
    ├── __init__.py
    ├── convert.py        # MP4 -> MP3 (ffmpeg)
    └── transcribe.py     # Audio -> Text (faster-whisper)
```
