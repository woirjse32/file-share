# mp4-to-text Setup Script
# Run this script to install dependencies and verify the environment.

Write-Host "=== mp4-to-text Setup ===" -ForegroundColor Cyan
Write-Host ""

# Check Python
Write-Host "[1/4] Checking Python..." -ForegroundColor Yellow
try {
    $pyVer = python --version 2>&1
    Write-Host "  OK: $pyVer" -ForegroundColor Green
} catch {
    Write-Host "  FAIL: Python not found. Install Python 3.10+ first." -ForegroundColor Red
    exit 1
}

# Check ffmpeg
Write-Host "[2/4] Checking ffmpeg..." -ForegroundColor Yellow
try {
    $ffVer = ffmpeg -version 2>&1 | Select-Object -First 1
    Write-Host "  OK: $ffVer" -ForegroundColor Green
} catch {
    Write-Host "  WARNING: ffmpeg not found in PATH." -ForegroundColor Yellow
    Write-Host "  Install with: winget install ffmpeg" -ForegroundColor Yellow
    Write-Host "  Or download from: https://ffmpeg.org/download.html" -ForegroundColor Yellow
}

# Install Python dependencies
Write-Host "[3/4] Installing Python dependencies..." -ForegroundColor Yellow
pip install -e . 2>&1 | Out-Null
if ($LASTEXITCODE -eq 0) {
    Write-Host "  OK: Dependencies installed" -ForegroundColor Green
} else {
    Write-Host "  FAIL: pip install failed. Check error above." -ForegroundColor Red
}

# Verify imports
Write-Host "[4/4] Verifying imports..." -ForegroundColor Yellow
python -c "from faster_whisper import WhisperModel; from mcp.server.fastmcp import FastMCP; print('All imports OK')" 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "  OK: All imports working" -ForegroundColor Green
} else {
    Write-Host "  WARNING: Some imports failed. Check error above." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "=== Setup Complete ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor White
Write-Host "  1. Install ffmpeg if not already: winget install ffmpeg" -ForegroundColor White
Write-Host "  2. Edit .env to set your preferred model (default: large-v3)" -ForegroundColor White
Write-Host "  3. Test the server: python server.py" -ForegroundColor White
Write-Host "  4. Add to opencode config as MCP server" -ForegroundColor White
Write-Host ""
Write-Host "opencode MCP config (add to .opencode/opencode.json):" -ForegroundColor White
Write-Host '  "mcpServers": { "mp4-to-text": { "command": "python", "args": ["' + (Resolve-Path .).Path + '\server.py"] } }' -ForegroundColor DarkGray
