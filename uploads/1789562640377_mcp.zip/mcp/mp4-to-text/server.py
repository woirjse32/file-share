from mcp.server.fastmcp import FastMCP

from tools.convert import convert_mp4_to_mp3
from tools.transcribe import transcribe_audio

mcp = FastMCP("mp4-to-text")


@mcp.tool()
def transcribe(
    file_path: str,
    language: str | None = None,
    beam_size: int = 5,
) -> str:
    """Transcribe an MP3 or MP4 file to text.

    Accepts both audio (MP3, WAV, FLAC, etc.) and video (MP4, MKV, etc.) files.
    For video files, the audio stream is automatically extracted before transcription.
    Uses faster-whisper with the large-v3 model for maximum accuracy.

    Args:
        file_path: Full path to the MP3 or MP4 file.
        language: Optional language code (e.g. 'en', 'es', 'fr'). Auto-detects if not set.
        beam_size: Beam size for decoding. Higher = more accurate. Default 5.

    Returns:
        Full transcript text with timestamps and metadata.
    """
    from pathlib import Path

    input_file = Path(file_path)
    if not input_file.exists():
        return f"Error: File not found: {file_path}"

    video_exts = {".mp4", ".mkv", ".avi", ".mov", ".webm"}
    if input_file.suffix.lower() in video_exts:
        mp3_path = convert_mp4_to_mp3(file_path)
        result = transcribe_audio(mp3_path, language=language, beam_size=beam_size)
        result["converted_from"] = file_path
    else:
        result = transcribe_audio(file_path, language=language, beam_size=beam_size)

    lines = []
    lines.append(f"Transcript ({result['language']}, {result['duration']}s):")
    lines.append("")
    for seg in result["segments"]:
        lines.append(f"[{seg['start']:.1f}s - {seg['end']:.1f}s] {seg['text']}")
    lines.append("")
    lines.append(f"Full text: {result['text']}")

    if result.get("converted_from"):
        lines.insert(0, f"Source video: {result['converted_from']}")

    return "\n".join(lines)


@mcp.tool()
def convert(mp4_path: str, output_path: str | None = None) -> str:
    """Convert an MP4 file to MP3 by extracting the audio track.

    Uses ffmpeg to extract audio at 192kbps MP3 quality.
    Supports MP4, MKV, AVI, MOV, and WEBM input formats.

    Args:
        mp4_path: Full path to the video file.
        output_path: Optional output path for the MP3 file.
            If not provided, creates an MP3 in the ./output directory.

    Returns:
        Path to the created MP3 file.
    """
    try:
        result = convert_mp4_to_mp3(mp4_path, output_path)
        return f"Converted successfully:\n{mp4_path} -> {result}"
    except (FileNotFoundError, ValueError, RuntimeError) as e:
        return f"Error: {e}"


@mcp.tool()
def list_models() -> str:
    """List available Whisper model sizes and their accuracy/speed tradeoffs.

    Returns information about model sizes, parameters, and recommended use cases.
    """
    models = """Available Whisper models (smaller = faster, larger = more accurate):

  tiny   - 39M params  - ~15% WER - Very fast, poor accuracy
  base   - 74M params  - ~10% WER - Fast, decent accuracy
  small  - 244M params - ~8% WER  - Good balance
  medium - 769M params - ~6% WER  - Slow, high accuracy
  large-v3      - 1.55B params - ~7.4% WER - Maximum accuracy (current: active)
  large-v3-turbo - 809M params - ~7.75% WER - Fast, near-max accuracy
  distil-large-v3 - 756M params - ~7.4% WER - 5-6x faster, English-only

Current model: large-v3 (configured in .env)
Change by editing WHISPER_MODEL in .env"""
    return models


@mcp.resource("config://whisper")
def get_config() -> str:
    """Get current Whisper configuration."""
    import os
    from dotenv import load_dotenv

    load_dotenv()
    return (
        f"Model: {os.getenv('WHISPER_MODEL', 'large-v3')}\n"
        f"Device: {os.getenv('WHISPER_DEVICE', 'cuda')}\n"
        f"Compute: {os.getenv('WHISPER_COMPUTE_TYPE', 'int8')}\n"
        f"FFmpeg: {os.getenv('FFMPEG_PATH', '(auto-detect)')}\n"
        f"Output: {os.getenv('OUTPUT_DIR', './output')}"
    )


if __name__ == "__main__":
    mcp.run()
